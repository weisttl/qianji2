// --- File processing ---

pub const QIANJI_TIMESTAMP_SEPARATOR: &str = "_qianji_";
pub const QIANJI_FILES_MARKER: &str = "[[QIANJI_FILES]]";

// --- Cross-session messaging ---

/// Sender-side block appended to a user message that referenced other
/// conversations with `@@`. Carries name + id + workspace per target so the
/// agent knows whether relative paths are meaningful to the recipient.
pub const QIANJI_SESSIONS_MARKER: &str = "[[QIANJI_SESSIONS]]";
pub const QIANJI_SESSIONS_END_MARKER: &str = "[[/QIANJI_SESSIONS]]";

/// Recipient-side block prepended to a cross-session delivery. Tells the
/// receiving agent who sent it, whether the sender's workspace matches, and
/// the reply address.
pub const QIANJI_SESSION_MESSAGE_MARKER: &str = "[[QIANJI_SESSION_MESSAGE]]";
pub const QIANJI_SESSION_MESSAGE_END_MARKER: &str = "[[/QIANJI_SESSION_MESSAGE]]";

// --- WebSocket ---

pub const HEARTBEAT_INTERVAL_MS: u64 = 30_000;
pub const HEARTBEAT_TIMEOUT_MS: u64 = 60_000;
pub const WS_CLOSE_NORMAL: u16 = 1000;
pub const WS_CLOSE_POLICY_VIOLATION: u16 = 1008;

// --- Authentication ---

/// Human-readable session lifetime label. Currently unused; kept consistent
/// with the real JWT/cookie lifetime (30 days).
pub const SESSION_EXPIRY: &str = "30d";
pub const COOKIE_NAME: &str = "qianji-session";
pub const COOKIE_MAX_AGE_DAYS: u32 = 30;
pub const CSRF_COOKIE_NAME: &str = "qianji-csrf-token";
pub const CSRF_HEADER_NAME: &str = "x-csrf-token";

/// Cookie carrying the refresh token.
///
/// Distinct from the access-token session cookie so the two credential roles
/// never share a container.
pub const REFRESH_COOKIE_NAME: &str = "qianji-refresh";
/// Path the refresh cookie is scoped to. The browser attaches it only when
/// calling the refresh endpoint, keeping the long-lived credential off every
/// ordinary API/WebSocket request.
pub const REFRESH_COOKIE_PATH: &str = "/api/auth/refresh";
/// Refresh-token / refresh-cookie lifetime in days. This is the window in which
/// a session can be renewed without re-authenticating.
pub const REFRESH_COOKIE_MAX_AGE_DAYS: u32 = 30;

// --- Server ---

pub const DEFAULT_HOST: &str = "127.0.0.1";
pub const REMOTE_HOST: &str = "0.0.0.0";
pub const DEFAULT_PORT: u16 = 25808;
/// Request body size limit (10 MB).
pub const BODY_LIMIT: usize = 10 * 1024 * 1024;
/// File upload size limit (30 MB).
pub const UPLOAD_MAX_SIZE: usize = 30 * 1024 * 1024;

// --- Team mode ---

/// Runtime backend that supports Team MCP without ACP capability metadata.
pub const QIANJIRS_RUNTIME_BACKEND: &str = "qianjirs";

/// Determine if an agent supports team mode through MCP or CLI fallback.
pub fn is_team_capable(backend: &str, agent_capabilities: Option<&serde_json::Value>) -> bool {
    if backend.trim().is_empty() {
        return false;
    }
    supports_team_mcp(backend, agent_capabilities) || supports_team_cli_fallback(agent_capabilities)
}

/// Determine if an agent supports Team MCP injection.
pub fn supports_team_mcp(backend: &str, agent_capabilities: Option<&serde_json::Value>) -> bool {
    if backend == QIANJIRS_RUNTIME_BACKEND {
        return true;
    }
    has_enabled_team_mcp_transport(agent_capabilities)
}

/// Determine if an agent is eligible for shell/CLI fallback.
pub fn supports_team_cli_fallback(agent_capabilities: Option<&serde_json::Value>) -> bool {
    let Some(caps) = agent_capabilities else {
        return true;
    };
    !explicit_false(caps, &["shell"])
        && !explicit_false(caps, &["cli"])
        && !explicit_false(caps, &["supports_shell"])
        && !explicit_false(caps, &["supportsShell"])
        && !explicit_false(caps, &["supports_cli"])
        && !explicit_false(caps, &["supportsCli"])
        && !explicit_false(caps, &["execution", "shell"])
        && !explicit_false(caps, &["execution", "cli"])
}

fn explicit_false(value: &serde_json::Value, path: &[&str]) -> bool {
    let mut cursor = value;
    for key in path {
        let Some(next) = cursor.get(*key) else {
            return false;
        };
        cursor = next;
    }
    cursor.as_bool() == Some(false)
}

/// Check whether `agent_capabilities` JSON declares MCP capability metadata.
pub fn has_mcp_capability(agent_capabilities: Option<&serde_json::Value>) -> bool {
    mcp_capability_object(agent_capabilities).is_some()
}

/// Whether the agent actually implements MCP, judged from the transports it
/// advertises in `mcpCapabilities`.
///
/// ACP declares stdio mandatory and therefore has no `stdio` flag to read — but
/// LIVE evidence shows the declaration is not honoured uniformly: `omp`
/// (`http:true,sse:true`) loads a stdio MCP server, while `pi`
/// (`http:false,sse:false`) does not, both probed with the same stdio-launched
/// Sentry MCP server. So an agent that advertises NO optional transport is
/// treated as not implementing MCP at all, and Team falls back to the CLI
/// transport for it.
fn has_enabled_team_mcp_transport(agent_capabilities: Option<&serde_json::Value>) -> bool {
    let Some(caps) = mcp_capability_object(agent_capabilities) else {
        return false;
    };
    bool_field(caps, "http") || bool_field(caps, "sse")
}

fn mcp_capability_object(agent_capabilities: Option<&serde_json::Value>) -> Option<&serde_json::Value> {
    let caps = agent_capabilities?;
    caps.get("mcp_capabilities")
        .or_else(|| caps.get("mcpCapabilities"))
        .or_else(|| caps.get("mcp"))
}

fn bool_field(value: &serde_json::Value, key: &str) -> bool {
    value.get(key).and_then(serde_json::Value::as_bool) == Some(true)
}

// --- Image processing ---

pub const SUPPORTED_IMAGE_EXTENSIONS: &[&str] = &[".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".tiff", ".svg"];
/// Remote image download size limit (5 MB).
pub const REMOTE_IMAGE_MAX_SIZE: usize = 5 * 1024 * 1024;
pub const REMOTE_IMAGE_MAX_REDIRECTS: u32 = 5;

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    #[test]
    fn has_mcp_capability_requires_mcp_capability_field() {
        assert!(!has_mcp_capability(None));
        assert!(!has_mcp_capability(Some(&json!({}))));

        assert!(has_mcp_capability(Some(&json!({
            "mcp_capabilities": { "http": false, "sse": false }
        }))));
        assert!(has_mcp_capability(Some(&json!({
            "mcp_capabilities": {}
        }))));

        assert!(has_mcp_capability(Some(&json!({
            "mcp_capabilities": { "stdio": true }
        }))));
        assert!(has_mcp_capability(Some(&json!({
            "mcpCapabilities": { "http": true, "sse": false }
        }))));
        assert!(has_mcp_capability(Some(&json!({
            "mcp": { "http": false, "sse": true }
        }))));
    }

    #[test]
    fn team_mcp_builtin_backend_does_not_require_capability_metadata() {
        assert!(supports_team_mcp("qianjirs", None));
        assert!(supports_team_mcp("qianjirs", Some(&json!({}))));
    }

    /// LIVE-probed contract (2026-07-30, same stdio-launched Sentry MCP server on
    /// both): `omp` advertises `http:true,sse:true` and loads the server; `pi`
    /// advertises `http:false,sse:false` and does not. So an advertised optional
    /// transport — EITHER one — is the signal that the agent implements MCP at
    /// all, and advertising neither means Team must not route MCP to it. ACP has
    /// no `stdio` flag (the transport is mandatory in the spec and therefore never
    /// declared), so reading one only ever matched non-ACP payloads.
    #[test]
    fn acp_backends_require_an_advertised_mcp_transport_for_team_mcp() {
        assert!(supports_team_mcp(
            "codex",
            Some(&json!({ "mcp_capabilities": { "http": true, "sse": false } }))
        ));
        assert!(supports_team_mcp(
            "gemini",
            Some(&json!({ "mcp_capabilities": { "http": false, "sse": true } }))
        ));

        assert!(!supports_team_mcp(
            "codebuddy",
            Some(&json!({ "mcp_capabilities": { "http": false, "sse": false } }))
        ));
        // A spec-mandatory transport is never advertised, so it can never be the
        // evidence: claiming `stdio` must not by itself unlock Team MCP.
        assert!(!supports_team_mcp(
            "claude",
            Some(&json!({ "mcp_capabilities": { "stdio": true } }))
        ));
        assert!(!supports_team_mcp("acp", None));
        assert!(!supports_team_mcp("claude", Some(&json!({ "mcp_capabilities": {} }))));
    }

    #[test]
    fn cli_fallback_is_default_unless_capabilities_disable_shell_or_cli() {
        assert!(supports_team_cli_fallback(None));
        assert!(supports_team_cli_fallback(Some(&json!({}))));
        assert!(!supports_team_cli_fallback(Some(&json!({"shell": false}))));
        assert!(!supports_team_cli_fallback(Some(&json!({"execution": {"cli": false}}))));
    }
}
