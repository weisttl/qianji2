use std::sync::Arc;
use std::{future::Future, pin::Pin};

use axum::extract::WebSocketUpgrade;
use axum::extract::ws::{CloseFrame, Message, WebSocket};
use axum::http::HeaderMap;
use axum::response::IntoResponse;
use futures_util::{SinkExt, StreamExt};
use qianji_api_types::WebSocketMessage;
use serde_json::{Value, json};
use tokio::sync::mpsc;
use tracing::{debug, info};

use crate::manager::{TokenValidator, WebSocketManager};
use crate::router::MessageRouter;
use crate::types::{ConnectionId, PER_CONNECTION_BUFFER, RealtimeError, WebSocketCloseCode, WsOutbound};

/// Extracts a JWT token from WebSocket upgrade request headers.
///
/// Injected by `qianji-app` — wraps `qianji_auth::extract_token_from_ws_headers`
/// so that `qianji-realtime` does not depend on `qianji-auth` directly.
pub type TokenExtractor = Arc<dyn Fn(&HeaderMap) -> Option<String> + Send + Sync>;

/// Resolves a verified JWT token to the active internal user ID it represents.
pub type TokenUserResolver = Arc<dyn Fn(String) -> Pin<Box<dyn Future<Output = Option<String>> + Send>> + Send + Sync>;

/// Shared state required by the WebSocket upgrade handler.
#[derive(Clone)]
pub struct WsHandlerState {
    pub manager: Arc<WebSocketManager>,
    pub router: Arc<dyn MessageRouter>,
    pub token_validator: TokenValidator,
    pub token_user_resolver: TokenUserResolver,
    pub token_extractor: TokenExtractor,
}

/// Axum handler for HTTP → WebSocket upgrade.
///
/// Extracts a JWT token from the request headers, validates it,
/// and upgrades the connection to WebSocket on success.
/// On authentication failure, sends `realtime.error` and closes with 1008.
///
/// When the token is carried via `Sec-WebSocket-Protocol`, the server
/// echoes the protocol header back so the client handshake succeeds.
pub async fn ws_upgrade_handler(
    ws: WebSocketUpgrade,
    headers: HeaderMap,
    axum::extract::State(state): axum::extract::State<WsHandlerState>,
) -> impl IntoResponse {
    let token = (state.token_extractor)(&headers);

    // Echo Sec-WebSocket-Protocol so clients using it for auth
    // receive a valid subprotocol negotiation response.
    let ws = if let Some(protocol) = headers
        .get("sec-websocket-protocol")
        .and_then(|v| v.to_str().ok())
        .map(|s| s.to_owned())
    {
        ws.protocols([protocol])
    } else {
        ws
    };

    ws.on_upgrade(move |socket| async move {
        handle_socket(socket, token, state).await;
    })
}

/// Post-upgrade connection handler.
///
/// Validates the token, registers the client, spawns send/recv loops.
async fn handle_socket(socket: WebSocket, token: Option<String>, state: WsHandlerState) {
    let Some(token) = token else {
        send_realtime_error_and_close(socket, RealtimeError::AuthMissing, "authentication required").await;
        return;
    };

    if !(state.token_validator)(&token) {
        send_realtime_error_and_close(socket, RealtimeError::AuthExpired, "authentication failed").await;
        return;
    }

    let Some(user_id) = (state.token_user_resolver)(token.clone()).await else {
        send_realtime_error_and_close(socket, RealtimeError::AuthExpired, "authentication failed").await;
        return;
    };

    let (tx, rx) = mpsc::channel::<WsOutbound>(PER_CONNECTION_BUFFER);
    let conn_id = state.manager.add_client_for_user(user_id.clone(), token, tx);

    info!(%conn_id, user_id = %user_id, "websocket connection established");

    let (ws_sender, ws_receiver) = socket.split();

    let send_handle = tokio::spawn(send_loop(conn_id, rx, ws_sender));
    recv_loop(conn_id, &user_id, ws_receiver, &state).await;

    // Recv loop exited — client disconnected or errored.
    send_handle.abort();
    state.manager.remove_client(conn_id);
    // Let stateful routers release per-connection state (e.g. fs subscriptions).
    state.router.on_disconnect(conn_id);
    info!(%conn_id, user_id = %user_id, "websocket connection closed");
}

/// Send a realtime boundary error event, then close with 1008.
async fn send_realtime_error_and_close(mut socket: WebSocket, error: RealtimeError, reason: &str) {
    if let Ok(text) = serde_json::to_string(&error.into_event()) {
        let _ = socket.send(Message::Text(text.into())).await;
    }
    let close = Message::Close(Some(CloseFrame {
        code: WebSocketCloseCode::PolicyViolation.as_u16(),
        reason: reason.into(),
    }));
    let _ = socket.send(close).await;
}

// -------------------------------------------------------------------
// Send loop
// -------------------------------------------------------------------

/// Reads `WsOutbound` from the per-connection channel and forwards
/// them to the WebSocket sink.
async fn send_loop(
    conn_id: ConnectionId,
    mut rx: mpsc::Receiver<WsOutbound>,
    mut sender: futures_util::stream::SplitSink<WebSocket, Message>,
) {
    while let Some(outbound) = rx.recv().await {
        let msg = match outbound {
            WsOutbound::Text(text) => Message::Text(text.into()),
            WsOutbound::Close(code, reason) => Message::Close(Some(CloseFrame {
                code: code.as_u16(),
                reason: reason.into(),
            })),
            WsOutbound::TextThenClose(text, code, reason) => {
                if sender.send(Message::Text(text.into())).await.is_err() {
                    debug!(%conn_id, "send loop: socket write failed, exiting");
                    break;
                }
                Message::Close(Some(CloseFrame {
                    code: code.as_u16(),
                    reason: reason.into(),
                }))
            }
        };
        if sender.send(msg).await.is_err() {
            debug!(%conn_id, "send loop: socket write failed, exiting");
            break;
        }
    }
}

// -------------------------------------------------------------------
// Receive loop
// -------------------------------------------------------------------

/// Reads messages from the WebSocket stream, parses JSON, routes.
async fn recv_loop(
    conn_id: ConnectionId,
    user_id: &str,
    mut receiver: futures_util::stream::SplitStream<WebSocket>,
    state: &WsHandlerState,
) {
    while let Some(result) = receiver.next().await {
        let msg = match result {
            Ok(m) => m,
            Err(e) => {
                debug!(%conn_id, error = %e, "recv error, closing");
                break;
            }
        };

        match msg {
            Message::Text(text) => {
                handle_text_message(conn_id, user_id, &text, state);
            }
            Message::Close(_) => {
                debug!(%conn_id, "received close frame");
                break;
            }
            // Ping/Pong at the WebSocket protocol level are handled
            // automatically by axum/tungstenite. Binary frames are ignored.
            _ => {}
        }
    }
}

/// Process a text message: parse JSON, dispatch to built-in or router.
fn handle_text_message(conn_id: ConnectionId, user_id: &str, text: &str, state: &WsHandlerState) {
    let parsed: Result<WebSocketMessage<Value>, _> = serde_json::from_str(text);

    let msg = match parsed {
        Ok(m) => m,
        Err(_) => {
            send_error_response(state, conn_id);
            return;
        }
    };

    if msg.name.trim().is_empty() {
        send_error_response(state, conn_id);
        return;
    }

    match msg.name.as_str() {
        "pong" => {
            state.manager.update_last_ping(conn_id);
        }
        "subscribe-show-open" => {
            handle_subscribe_show_open(state, conn_id, msg.data);
        }
        name => {
            if !state.router.route(conn_id, user_id, name, msg.data) {
                send_realtime_error(state, conn_id, RealtimeError::UnsupportedMessage);
            }
        }
    }
}

/// Send an error response for invalid message format.
fn send_error_response(state: &WsHandlerState, conn_id: ConnectionId) {
    send_realtime_error(state, conn_id, RealtimeError::InvalidMessage);
}

fn send_realtime_error(state: &WsHandlerState, conn_id: ConnectionId, error: RealtimeError) {
    state.manager.send_to(conn_id, error.into_event());
}

/// Handle `subscribe-show-open`: reply with `show-open-request`.
///
/// The inbound `data` is the @office-ai/platform bridge envelope
/// `{ id, data: <user-params> }`. The renderer awaits a callback whose event
/// name embeds `id` (`subscribe.callback-show-open<id>`), so we must echo it
/// back; without it, the frontend's `useDirectorySelection` hook builds the
/// wrong callback name and the original `invoke()` Promise never resolves.
///
/// `isFileMode` is `true` when `properties` contains `openFile`
/// but NOT `openDirectory`.
fn handle_subscribe_show_open(state: &WsHandlerState, conn_id: ConnectionId, data: Value) {
    let id = data.get("id").and_then(|v| v.as_str()).unwrap_or("").to_owned();
    let inner = data.get("data").unwrap_or(&Value::Null);

    let properties = inner
        .get("properties")
        .and_then(|v| v.as_array())
        .cloned()
        .unwrap_or_default();

    let has_open_file = properties.iter().any(|v| v.as_str() == Some("openFile"));
    let has_open_directory = properties.iter().any(|v| v.as_str() == Some("openDirectory"));

    let is_file_mode = has_open_file && !has_open_directory;

    let response = WebSocketMessage::new(
        "show-open-request",
        json!({
            "id": id,
            "properties": properties,
            "isFileMode": is_file_mode,
        }),
    );

    state.manager.send_to(conn_id, response);
}

#[cfg(test)]
mod tests {
    use super::*;

    fn test_state(manager: Arc<WebSocketManager>) -> WsHandlerState {
        WsHandlerState {
            manager,
            router: Arc::new(crate::router::NoopMessageRouter),
            token_validator: Arc::new(|_| true),
            token_user_resolver: Arc::new(|_| Box::pin(async { Some("system_default_user".into()) })),
            token_extractor: Arc::new(|_| None),
        }
    }

    fn assert_invalid_message_error(text: &str) {
        let parsed: Value = serde_json::from_str(text).unwrap();
        assert_eq!(parsed["name"], "realtime.error");
        assert_eq!(parsed["data"]["code"], "REALTIME_INVALID_MESSAGE");
        assert!(parsed["data"]["message"].is_string());
        assert_eq!(parsed["data"]["recoverable"], true);
        assert_eq!(
            parsed["data"]["details"]["expected"],
            r#"{ "name": "event-name", "data": {...} }"#
        );
    }

    fn assert_unsupported_message_error(text: &str) {
        let parsed: Value = serde_json::from_str(text).unwrap();
        assert_eq!(parsed["name"], "realtime.error");
        assert_eq!(parsed["data"]["code"], "REALTIME_UNSUPPORTED_MESSAGE");
        assert_eq!(parsed["data"]["recoverable"], true);
        assert!(parsed["data"]["message"].is_string());
        assert!(parsed["data"]["details"].is_object());
    }

    #[test]
    fn subscribe_show_open_file_mode() {
        let manager = Arc::new(WebSocketManager::new());
        let (tx, mut rx) = mpsc::channel(PER_CONNECTION_BUFFER);
        let conn_id = manager.add_client("tok".into(), tx);
        let state = test_state(manager);

        let data = json!({"id": "abc123", "data": {"properties": ["openFile"]}});
        handle_subscribe_show_open(&state, conn_id, data);

        let msg = rx.try_recv().unwrap();
        match msg {
            WsOutbound::Text(text) => {
                let parsed: Value = serde_json::from_str(&text).unwrap();
                assert_eq!(parsed["name"], "show-open-request");
                assert_eq!(parsed["data"]["id"], "abc123");
                assert_eq!(parsed["data"]["isFileMode"], true);
                assert_eq!(parsed["data"]["properties"], json!(["openFile"]));
            }
            _ => panic!("expected Text"),
        }
    }

    #[test]
    fn subscribe_show_open_directory_mode() {
        let manager = Arc::new(WebSocketManager::new());
        let (tx, mut rx) = mpsc::channel(PER_CONNECTION_BUFFER);
        let conn_id = manager.add_client("tok".into(), tx);
        let state = test_state(manager);

        let data = json!({"id": "dir1", "data": {"properties": ["openDirectory"]}});
        handle_subscribe_show_open(&state, conn_id, data);

        let msg = rx.try_recv().unwrap();
        match msg {
            WsOutbound::Text(text) => {
                let parsed: Value = serde_json::from_str(&text).unwrap();
                assert_eq!(parsed["data"]["id"], "dir1");
                assert_eq!(parsed["data"]["isFileMode"], false);
            }
            _ => panic!("expected Text"),
        }
    }

    #[test]
    fn subscribe_show_open_mixed_mode() {
        let manager = Arc::new(WebSocketManager::new());
        let (tx, mut rx) = mpsc::channel(PER_CONNECTION_BUFFER);
        let conn_id = manager.add_client("tok".into(), tx);
        let state = test_state(manager);

        let data = json!({"id": "mixed", "data": {"properties": ["openFile", "openDirectory"]}});
        handle_subscribe_show_open(&state, conn_id, data);

        let msg = rx.try_recv().unwrap();
        match msg {
            WsOutbound::Text(text) => {
                let parsed: Value = serde_json::from_str(&text).unwrap();
                assert_eq!(parsed["data"]["id"], "mixed");
                assert_eq!(parsed["data"]["isFileMode"], false);
            }
            _ => panic!("expected Text"),
        }
    }

    #[test]
    fn subscribe_show_open_empty_properties() {
        let manager = Arc::new(WebSocketManager::new());
        let (tx, mut rx) = mpsc::channel(PER_CONNECTION_BUFFER);
        let conn_id = manager.add_client("tok".into(), tx);
        let state = test_state(manager);

        let data = json!({"id": "empty", "data": {"properties": []}});
        handle_subscribe_show_open(&state, conn_id, data);

        let msg = rx.try_recv().unwrap();
        match msg {
            WsOutbound::Text(text) => {
                let parsed: Value = serde_json::from_str(&text).unwrap();
                assert_eq!(parsed["data"]["id"], "empty");
                assert_eq!(parsed["data"]["isFileMode"], false);
            }
            _ => panic!("expected Text"),
        }
    }

    #[test]
    fn subscribe_show_open_missing_properties() {
        let manager = Arc::new(WebSocketManager::new());
        let (tx, mut rx) = mpsc::channel(PER_CONNECTION_BUFFER);
        let conn_id = manager.add_client("tok".into(), tx);
        let state = test_state(manager);

        handle_subscribe_show_open(&state, conn_id, json!({"id": "noprops", "data": {}}));

        let msg = rx.try_recv().unwrap();
        match msg {
            WsOutbound::Text(text) => {
                let parsed: Value = serde_json::from_str(&text).unwrap();
                assert_eq!(parsed["data"]["id"], "noprops");
                assert_eq!(parsed["data"]["isFileMode"], false);
                assert_eq!(parsed["data"]["properties"], json!([]));
            }
            _ => panic!("expected Text"),
        }
    }

    #[test]
    fn subscribe_show_open_missing_id_falls_back_to_empty_string() {
        let manager = Arc::new(WebSocketManager::new());
        let (tx, mut rx) = mpsc::channel(PER_CONNECTION_BUFFER);
        let conn_id = manager.add_client("tok".into(), tx);
        let state = test_state(manager);

        handle_subscribe_show_open(&state, conn_id, json!({}));

        let msg = rx.try_recv().unwrap();
        match msg {
            WsOutbound::Text(text) => {
                let parsed: Value = serde_json::from_str(&text).unwrap();
                assert_eq!(parsed["data"]["id"], "");
                assert_eq!(parsed["data"]["isFileMode"], false);
                assert_eq!(parsed["data"]["properties"], json!([]));
            }
            _ => panic!("expected Text"),
        }
    }

    #[test]
    fn text_message_pong_updates_last_ping() {
        let manager = Arc::new(WebSocketManager::new());
        let (tx, _rx) = mpsc::channel(PER_CONNECTION_BUFFER);
        let conn_id = manager.add_client("tok".into(), tx);
        let state = test_state(manager);

        std::thread::sleep(std::time::Duration::from_millis(5));

        handle_text_message(conn_id, "user-1", r#"{"name":"pong","data":{}}"#, &state);
        // No panic = success (update_last_ping was called)
    }

    #[test]
    fn text_message_invalid_json_sends_error() {
        let manager = Arc::new(WebSocketManager::new());
        let (tx, mut rx) = mpsc::channel(PER_CONNECTION_BUFFER);
        let conn_id = manager.add_client("tok".into(), tx);
        let state = test_state(manager);

        handle_text_message(conn_id, "user-1", "not json", &state);

        let msg = rx.try_recv().unwrap();
        match msg {
            WsOutbound::Text(text) => {
                assert_invalid_message_error(&text);
            }
            _ => panic!("expected error text"),
        }
    }

    #[test]
    fn text_message_missing_fields_sends_error() {
        let manager = Arc::new(WebSocketManager::new());
        let (tx, mut rx) = mpsc::channel(PER_CONNECTION_BUFFER);
        let conn_id = manager.add_client("tok".into(), tx);
        let state = test_state(manager);

        handle_text_message(conn_id, "user-1", r#"{"foo":"bar"}"#, &state);

        let msg = rx.try_recv().unwrap();
        match msg {
            WsOutbound::Text(text) => {
                assert_invalid_message_error(&text);
            }
            _ => panic!("expected error text"),
        }
    }

    #[test]
    fn text_message_empty_name_sends_error() {
        let manager = Arc::new(WebSocketManager::new());
        let (tx, mut rx) = mpsc::channel(PER_CONNECTION_BUFFER);
        let conn_id = manager.add_client("tok".into(), tx);
        let state = test_state(manager);

        handle_text_message(conn_id, "user-1", r#"{"name":"","data":{}}"#, &state);

        let msg = rx.try_recv().unwrap();
        match msg {
            WsOutbound::Text(text) => {
                assert_invalid_message_error(&text);
            }
            _ => panic!("expected error text"),
        }
    }

    #[test]
    fn text_message_routes_unknown_to_router() {
        use std::sync::atomic::{AtomicBool, Ordering};

        struct TestRouter {
            called: AtomicBool,
        }
        impl MessageRouter for TestRouter {
            fn route(&self, _conn_id: ConnectionId, _user_id: &str, _name: &str, _data: Value) -> bool {
                self.called.store(true, Ordering::Relaxed);
                true
            }
        }

        let manager = Arc::new(WebSocketManager::new());
        let (tx, _rx) = mpsc::channel(PER_CONNECTION_BUFFER);
        let conn_id = manager.add_client("tok".into(), tx);

        let router = Arc::new(TestRouter {
            called: AtomicBool::new(false),
        });
        let state = WsHandlerState {
            manager,
            router: router.clone(),
            token_validator: Arc::new(|_| true),
            token_user_resolver: Arc::new(|_| Box::pin(async { Some("system_default_user".into()) })),
            token_extractor: Arc::new(|_| None),
        };

        handle_text_message(
            conn_id,
            "user-1",
            r#"{"name":"conversation.send-message","data":{"text":"hi"}}"#,
            &state,
        );

        assert!(router.called.load(Ordering::Relaxed));
    }

    #[test]
    fn text_message_unhandled_by_router_sends_unsupported_error() {
        let manager = Arc::new(WebSocketManager::new());
        let (tx, mut rx) = mpsc::channel(PER_CONNECTION_BUFFER);
        let conn_id = manager.add_client("tok".into(), tx);
        let state = test_state(manager);

        handle_text_message(
            conn_id,
            "user-1",
            r#"{"name":"conversation.send-message","data":{"text":"hi"}}"#,
            &state,
        );

        let msg = rx.try_recv().unwrap();
        match msg {
            WsOutbound::Text(text) => {
                assert_unsupported_message_error(&text);
            }
            _ => panic!("expected unsupported message error"),
        }
    }

    #[test]
    fn error_response_to_disconnected_client_is_noop() {
        let manager = Arc::new(WebSocketManager::new());
        let (tx, rx) = mpsc::channel(PER_CONNECTION_BUFFER);
        let conn_id = manager.add_client("tok".into(), tx);
        drop(rx); // close channel

        let state = test_state(manager.clone());

        // Should not panic — client will be removed
        send_error_response(&state, conn_id);
        assert_eq!(manager.client_count(), 0);
    }
}
