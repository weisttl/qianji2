use std::collections::HashMap;

use serde::{Deserialize, Serialize};
use serde_json::Value;

/// Response for `GET /api/settings`.
///
/// Returns all backend system settings with their current values.
/// When no settings exist in the database, the service layer returns defaults.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct SystemSettingsResponse {
    pub language: String,
    pub notification_enabled: bool,
    pub cron_notification_enabled: bool,
    pub command_queue_enabled: bool,
    pub save_upload_to_workspace: bool,
    /// Cross-session messaging master switch. Positive wording, default on
    /// (spec §5.7): the UI switch reads "allow", never "disable".
    ///
    /// `default = "enabled_by_default"` rather than a bare `#[serde(default)]`:
    /// the latter yields `false`, which would silently DISABLE the feature for
    /// any payload written before this field existed — the opposite of the
    /// schema's `NOT NULL DEFAULT 1`.
    #[serde(default = "enabled_by_default")]
    pub cross_session_message_enabled: bool,
}

fn enabled_by_default() -> bool {
    true
}

impl Default for SystemSettingsResponse {
    fn default() -> Self {
        Self {
            language: "en-US".to_owned(),
            notification_enabled: true,
            cron_notification_enabled: false,
            command_queue_enabled: false,
            save_upload_to_workspace: false,
            cross_session_message_enabled: true,
        }
    }
}

/// Request body for `PATCH /api/settings`.
///
/// All fields are optional — only the fields present in the request body
/// are updated. Unknown fields are silently ignored by serde.
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct UpdateSettingsRequest {
    pub language: Option<String>,
    pub notification_enabled: Option<bool>,
    pub cron_notification_enabled: Option<bool>,
    pub command_queue_enabled: Option<bool>,
    pub save_upload_to_workspace: Option<bool>,
    pub cross_session_message_enabled: Option<bool>,
}

impl UpdateSettingsRequest {
    /// Returns `true` if all fields are `None` (no-op update).
    pub fn is_empty(&self) -> bool {
        self.language.is_none()
            && self.notification_enabled.is_none()
            && self.cron_notification_enabled.is_none()
            && self.command_queue_enabled.is_none()
            && self.save_upload_to_workspace.is_none()
            && self.cross_session_message_enabled.is_none()
    }
}

/// Response for `GET /api/system/current-user`.
///
/// Answers "which user id does the backend attribute my requests to". Needed
/// because `GET /api/auth/user` cannot: the auth router runs its own
/// `AuthState` whose identity mode is never `Local`, so in local mode it
/// returns 401 even though every ordinary route is serving an injected default
/// user. A client comparing a broadcast payload's `user_id` against "me" needs
/// the id the ORDINARY middleware produced.
///
/// Deliberately only `id` + `username`: this is an identity echo, not a user
/// profile endpoint.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct CurrentUserResponse {
    pub id: String,
    pub username: String,
}

/// Response for `GET /api/settings/client`.
///
/// A flat key-value map where values can be any JSON type (string,
/// number, boolean). The service layer deserializes stored JSON strings
/// back to their original types.
pub type ClientPreferencesResponse = HashMap<String, Value>;

/// Request body for `PUT /api/settings/client`.
///
/// A flat key-value map for batch updates. A `null` value means
/// the key should be deleted. Non-null values are persisted as-is.
pub type UpdateClientPreferencesRequest = HashMap<String, Value>;

/// Query parameters for `GET /api/system/diagnostics/feedback-report`.
///
/// The UI sends only routing and explicit context. qianjiCore owns profile
/// resolution, SQL selection, and redaction.
#[derive(Debug, Clone, Default, Serialize, Deserialize, PartialEq, Eq)]
pub struct FeedbackDiagnosticsQuery {
    pub route_at_open: Option<String>,
    pub route_at_submit: Option<String>,
    pub selected_module: Option<String>,
    /// Optional comma-separated kebab-case profile names.
    pub profiles: Option<String>,
    pub conversation_id: Option<String>,
    pub provider_id: Option<String>,
    pub agent_id: Option<String>,
    pub team_id: Option<String>,
    pub mcp_server_id: Option<String>,
}

/// Response for `GET /api/system/diagnostics/feedback-report`.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct FeedbackDiagnosticsResponse {
    pub schema_version: String,
    pub context: FeedbackDiagnosticsContextResponse,
    pub profiles: Vec<FeedbackDiagnosticsProfileResponse>,
    pub privacy: FeedbackDiagnosticsPrivacyResponse,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize, PartialEq, Eq)]
pub struct FeedbackDiagnosticsContextResponse {
    pub route_at_open: Option<String>,
    pub route_at_submit: Option<String>,
    pub selected_module: Option<String>,
    pub conversation_id: Option<String>,
    pub provider_id: Option<String>,
    pub agent_id: Option<String>,
    pub team_id: Option<String>,
    pub mcp_server_id: Option<String>,
    pub selected_profiles: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct FeedbackDiagnosticsProfileResponse {
    pub name: String,
    pub mode: String,
    pub data: Value,
    pub warnings: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct FeedbackDiagnosticsPrivacyResponse {
    pub redaction: String,
    pub raw_content_included: bool,
    pub api_keys_included: bool,
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    // -- SystemSettingsResponse --

    #[test]
    fn test_settings_response_default() {
        let resp = SystemSettingsResponse::default();
        assert_eq!(resp.language, "en-US");
        assert!(resp.notification_enabled);
        assert!(!resp.cron_notification_enabled);
        assert!(!resp.command_queue_enabled);
        assert!(!resp.save_upload_to_workspace);
    }

    #[test]
    fn test_settings_response_serialization_snake_case() {
        let resp = SystemSettingsResponse::default();
        let json = serde_json::to_value(&resp).unwrap();
        assert_eq!(json["language"], "en-US");
        assert_eq!(json["notification_enabled"], true);
        assert_eq!(json["cron_notification_enabled"], false);
        assert_eq!(json["command_queue_enabled"], false);
        assert_eq!(json["save_upload_to_workspace"], false);
        // Verify snake_case, not camelCase
        assert!(json.get("notificationEnabled").is_none());
        assert!(json.get("cronNotificationEnabled").is_none());
    }

    #[test]
    fn test_settings_response_deserialization_snake_case() {
        let raw = json!({
            "language": "zh-CN",
            "notification_enabled": false,
            "cron_notification_enabled": true,
            "command_queue_enabled": true,
            "save_upload_to_workspace": true
        });
        let resp: SystemSettingsResponse = serde_json::from_value(raw).unwrap();
        assert_eq!(resp.language, "zh-CN");
        assert!(!resp.notification_enabled);
        assert!(resp.cron_notification_enabled);
        assert!(resp.command_queue_enabled);
        assert!(resp.save_upload_to_workspace);
        assert!(
            resp.cross_session_message_enabled,
            "a payload predating the field must read as ENABLED, matching the schema default"
        );
    }

    #[test]
    fn test_settings_response_roundtrip() {
        let original = SystemSettingsResponse {
            language: "ja-JP".to_owned(),
            notification_enabled: false,
            cron_notification_enabled: true,
            command_queue_enabled: true,
            save_upload_to_workspace: true,
            cross_session_message_enabled: false,
        };
        let json = serde_json::to_string(&original).unwrap();
        let parsed: SystemSettingsResponse = serde_json::from_str(&json).unwrap();
        assert_eq!(parsed, original);
    }

    // -- UpdateSettingsRequest --

    #[test]
    fn test_update_request_partial_fields() {
        let raw = r#"{"language":"zh-CN"}"#;
        let req: UpdateSettingsRequest = serde_json::from_str(raw).unwrap();
        assert_eq!(req.language.as_deref(), Some("zh-CN"));
        assert!(req.notification_enabled.is_none());
        assert!(req.cron_notification_enabled.is_none());
        assert!(req.command_queue_enabled.is_none());
        assert!(req.save_upload_to_workspace.is_none());
    }

    #[test]
    fn test_update_request_empty_body() {
        let raw = r#"{}"#;
        let req: UpdateSettingsRequest = serde_json::from_str(raw).unwrap();
        assert!(req.is_empty());
    }

    #[test]
    fn test_update_request_multiple_fields() {
        let raw = json!({
            "notification_enabled": false,
            "command_queue_enabled": true
        });
        let req: UpdateSettingsRequest = serde_json::from_value(raw).unwrap();
        assert!(req.language.is_none());
        assert_eq!(req.notification_enabled, Some(false));
        assert_eq!(req.command_queue_enabled, Some(true));
        assert!(!req.is_empty());
    }

    #[test]
    fn test_update_request_camel_case_ignored() {
        // camelCase keys are treated as unknown fields and silently ignored
        let raw = r#"{"notificationEnabled":true}"#;
        let req: UpdateSettingsRequest = serde_json::from_str(raw).unwrap();
        assert!(req.notification_enabled.is_none());
        assert!(req.is_empty());
    }

    #[test]
    fn test_update_request_unknown_field_ignored() {
        let raw = r#"{"unknownField":123}"#;
        let req: UpdateSettingsRequest = serde_json::from_str(raw).unwrap();
        assert!(req.is_empty());
    }

    // -- ClientPreferencesResponse / UpdateClientPreferencesRequest --

    #[test]
    fn test_client_preferences_response_empty() {
        let resp: ClientPreferencesResponse = HashMap::new();
        let json = serde_json::to_value(&resp).unwrap();
        assert_eq!(json, json!({}));
    }

    #[test]
    fn test_client_preferences_response_mixed_types() {
        let mut resp: ClientPreferencesResponse = HashMap::new();
        resp.insert("system.closeToTray".into(), json!(false));
        resp.insert("pet.size".into(), json!(280));
        resp.insert("theme".into(), json!("dark"));
        resp.insert("ui.zoomFactor".into(), json!(1.0));

        let json = serde_json::to_value(&resp).unwrap();
        assert_eq!(json["system.closeToTray"], false);
        assert_eq!(json["pet.size"], 280);
        assert_eq!(json["theme"], "dark");
        assert_eq!(json["ui.zoomFactor"], 1.0);
    }

    #[test]
    fn test_update_client_preferences_with_null_delete() {
        let raw = json!({
            "theme": null,
            "pet.size": 360
        });
        let req: UpdateClientPreferencesRequest = serde_json::from_value(raw).unwrap();
        assert!(req["theme"].is_null());
        assert_eq!(req["pet.size"], 360);
    }
}
