//! Shared runtime state for all agent managers.
//!
//! Each `*AgentManager` composes a single `AgentRuntime` to hold its
//! identity (`conversation_id`, `workspace`), status, last-activity
//! timestamp, and the event broadcast channel. This collapses five
//! fields that were repeated across every manager into one value
//! object, and makes the invariant `emit_finish` = (status ← Finished
//! AND broadcast Finish) enforceable in a single place.
//!
//! See target.md §6.1 / §6.4 SM1. Stage 7 of the refactor plan.

use std::sync::atomic::{AtomicI64, Ordering};
use std::sync::{Arc, RwLock};

use tokio::sync::broadcast;

use qianji_api_types::AgentStreamErrorData;
use qianji_common::{ConversationStatus, TimestampMs, now_ms};

use crate::protocol::events::{AgentStreamEvent, ErrorEventData, FinishEventData};

#[derive(Clone)]
pub struct AgentRuntime {
    conversation_id: Arc<str>,
    workspace: Arc<str>,
    status: Arc<RwLock<Option<ConversationStatus>>>,
    last_activity: Arc<AtomicI64>,
    event_tx: broadcast::Sender<AgentStreamEvent>,
}

impl AgentRuntime {
    /// Construct a new runtime.
    ///
    /// `channel_capacity` is the broadcast buffer size for `event_tx`.
    /// Recommended: 256 (see target.md §17 D2). Callers that need a
    /// different value may pass it explicitly.
    pub fn new(conversation_id: impl Into<String>, workspace: impl Into<String>, channel_capacity: usize) -> Self {
        let (event_tx, _) = broadcast::channel(channel_capacity);
        Self {
            conversation_id: Arc::from(conversation_id.into()),
            workspace: Arc::from(workspace.into()),
            status: Arc::new(RwLock::new(None)),
            last_activity: Arc::new(AtomicI64::new(now_ms())),
            event_tx,
        }
    }

    // ── Read ────────────────────────────────────────────────────────────

    pub fn conversation_id(&self) -> &str {
        &self.conversation_id
    }

    pub fn workspace(&self) -> &str {
        &self.workspace
    }

    pub fn status(&self) -> Option<ConversationStatus> {
        *self.status.read().unwrap_or_else(|e| e.into_inner())
    }

    pub fn last_activity_at(&self) -> TimestampMs {
        self.last_activity.load(Ordering::Relaxed)
    }

    pub fn subscribe(&self) -> broadcast::Receiver<AgentStreamEvent> {
        self.event_tx.subscribe()
    }

    /// Crate-private accessor for the broadcast sender, exposed so
    /// managers can clone it where a `broadcast::Sender<..>` clone is
    /// needed directly (e.g. passing into an SDK builder). Prefer
    /// `emit` / `emit_finish` / `emit_error` for event emission.
    #[allow(dead_code)]
    pub(crate) fn event_sender(&self) -> broadcast::Sender<AgentStreamEvent> {
        self.event_tx.clone()
    }

    // ── Write (see target §6.4 SM1 "single-writer" invariant) ───────────

    pub fn bump_activity(&self) {
        self.last_activity.store(now_ms(), Ordering::Relaxed);
    }

    /// Transition to `status`. Finished is absorbing — subsequent
    /// transitions from Finished to anything else are no-ops (including
    /// Finished → Finished, which is idempotent).
    pub fn transition_to(&self, status: ConversationStatus) {
        let mut guard = self.status.write().unwrap_or_else(|e| e.into_inner());
        if matches!(*guard, Some(ConversationStatus::Finished)) {
            // Finished is the absorbing state; ignore further writes.
            return;
        }
        *guard = Some(status);
    }

    /// Force-reset the status so a new turn can emit Finish again.
    /// Only intended for multi-turn agents (e.g. qianjirs) where the same
    /// runtime instance handles successive user messages.
    pub fn reset_for_new_turn(&self, status: ConversationStatus) {
        let mut guard = self.status.write().unwrap_or_else(|e| e.into_inner());
        *guard = Some(status);
    }

    pub fn emit(&self, event: AgentStreamEvent) {
        let _ = self.event_tx.send(event);
    }

    /// Atomic: set status ← Finished AND broadcast `Finish(session_id)`.
    /// Idempotent in the Finished absorbing state (no-op).
    pub fn emit_finish(&self, session_id: Option<String>) {
        let already_finished = {
            let mut guard = self.status.write().unwrap_or_else(|e| e.into_inner());
            let was_finished = matches!(*guard, Some(ConversationStatus::Finished));
            if !was_finished {
                *guard = Some(ConversationStatus::Finished);
            }
            was_finished
        };
        if already_finished {
            return;
        }
        let _ = self
            .event_tx
            .send(AgentStreamEvent::Finish(FinishEventData { session_id }));
    }

    /// Atomic: set status ← Finished AND broadcast `Error { message }`.
    /// Idempotent in the Finished absorbing state (no-op).
    pub fn emit_error(&self, message: impl Into<String>) {
        self.emit_error_data(ErrorEventData::legacy(message, None));
    }

    /// Atomic: set status ← Finished AND broadcast the structured error payload.
    /// Idempotent in the Finished absorbing state (no-op).
    pub fn emit_error_data(&self, data: AgentStreamErrorData) {
        let already_finished = {
            let mut guard = self.status.write().unwrap_or_else(|e| e.into_inner());
            let was_finished = matches!(*guard, Some(ConversationStatus::Finished));
            if !was_finished {
                *guard = Some(ConversationStatus::Finished);
            }
            was_finished
        };
        if already_finished {
            return;
        }
        let _ = self.event_tx.send(AgentStreamEvent::Error(data));
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn runtime() -> AgentRuntime {
        AgentRuntime::new("conv-1", "/tmp/workspace", 8)
    }

    #[tokio::test]
    async fn new_has_no_status_and_current_last_activity() {
        let rt = runtime();
        assert_eq!(rt.conversation_id(), "conv-1");
        assert_eq!(rt.workspace(), "/tmp/workspace");
        assert_eq!(rt.status(), None);
        // last_activity_at should be close to `now_ms()` (within a second).
        let diff = now_ms() - rt.last_activity_at();
        assert!(diff.abs() < 1000);
    }

    #[tokio::test]
    async fn bump_activity_monotonic() {
        let rt = runtime();
        let before = rt.last_activity_at();
        std::thread::sleep(std::time::Duration::from_millis(2));
        rt.bump_activity();
        let after = rt.last_activity_at();
        assert!(after >= before);
    }

    #[tokio::test]
    async fn emit_finish_transitions_and_broadcasts() {
        let rt = runtime();
        let mut rx = rt.subscribe();
        rt.emit_finish(Some("sess-1".into()));
        assert_eq!(rt.status(), Some(ConversationStatus::Finished));
        let ev = rx.recv().await.expect("finish event");
        match ev {
            AgentStreamEvent::Finish(data) => {
                assert_eq!(data.session_id.as_deref(), Some("sess-1"));
            }
            other => panic!("expected Finish, got {other:?}"),
        }
    }

    #[tokio::test]
    async fn emit_error_transitions_and_broadcasts() {
        let rt = runtime();
        let mut rx = rt.subscribe();
        rt.emit_error("boom");
        assert_eq!(rt.status(), Some(ConversationStatus::Finished));
        let ev = rx.recv().await.expect("error event");
        match ev {
            AgentStreamEvent::Error(data) => {
                assert_eq!(data.message, "boom");
            }
            other => panic!("expected Error, got {other:?}"),
        }
    }

    #[tokio::test]
    async fn emit_finish_is_idempotent_in_finished_state() {
        let rt = runtime();
        let mut rx = rt.subscribe();

        rt.emit_finish(None);
        // Drain the first event.
        let _ = rx.recv().await.unwrap();

        // Second call should be a no-op: status stays Finished, no new
        // broadcast.
        rt.emit_finish(Some("ignored".into()));
        assert_eq!(rt.status(), Some(ConversationStatus::Finished));

        // Nothing else should have landed on the receiver.
        let res = tokio::time::timeout(std::time::Duration::from_millis(50), rx.recv()).await;
        assert!(res.is_err(), "expected no additional broadcast, got {res:?}");
    }

    #[tokio::test]
    async fn emit_error_after_finish_is_noop() {
        let rt = runtime();
        let mut rx = rt.subscribe();

        rt.emit_finish(None);
        let _ = rx.recv().await.unwrap();

        rt.emit_error("late error — should be ignored");
        assert_eq!(rt.status(), Some(ConversationStatus::Finished));

        let res = tokio::time::timeout(std::time::Duration::from_millis(50), rx.recv()).await;
        assert!(res.is_err());
    }

    #[tokio::test]
    async fn reset_for_new_turn_overrides_finished() {
        let rt = runtime();
        rt.emit_finish(None);
        assert_eq!(rt.status(), Some(ConversationStatus::Finished));

        rt.reset_for_new_turn(ConversationStatus::Running);
        assert_eq!(rt.status(), Some(ConversationStatus::Running));
    }

    #[tokio::test]
    async fn reset_for_new_turn_then_emit_finish_sends_event() {
        let rt = runtime();
        rt.emit_finish(None);
        assert_eq!(rt.status(), Some(ConversationStatus::Finished));

        rt.reset_for_new_turn(ConversationStatus::Running);
        let mut rx = rt.subscribe();
        rt.emit_finish(Some("sess-2".into()));
        assert_eq!(rt.status(), Some(ConversationStatus::Finished));

        let ev = rx.recv().await.expect("finish event after reset");
        match ev {
            AgentStreamEvent::Finish(data) => {
                assert_eq!(data.session_id.as_deref(), Some("sess-2"));
            }
            other => panic!("expected Finish, got {other:?}"),
        }
    }
}
