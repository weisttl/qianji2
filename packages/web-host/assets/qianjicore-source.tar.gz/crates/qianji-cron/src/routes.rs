#![allow(clippy::disallowed_types)]

use axum::Router;
use axum::extract::rejection::JsonRejection;
use axum::extract::{Extension, Json, Path, Query, State};
use axum::http::{HeaderMap, StatusCode};
use axum::routing::{get, post, put};

use qianji_api_types::{
    ApiResponse, ConversationResponse, CreateConversationCronRequest, CreateConversationCronResponse,
    CreateCronJobRequest, CronJobResponse, HasSkillResponse, ListCronJobsQuery, RunNowResponse, SaveCronSkillRequest,
    UpdateConversationCronRequest, UpdateCronJobRequest,
};
use qianji_auth::CurrentUser;
use qianji_common::ApiError;
use qianji_db::DbError;

use crate::error::CronError;
use crate::service::CronService;
use crate::state::CronRouterState;

fn db_error_to_api_error(err: DbError) -> ApiError {
    match err {
        DbError::NotFound(msg) => ApiError::NotFound(msg),
        DbError::Conflict(msg) => ApiError::Conflict(msg),
        DbError::Query(e) => ApiError::Internal(format!("Database error: {e}")),
        DbError::Migration(e) => ApiError::Internal(format!("Migration error: {e}")),
        DbError::Init(msg) => ApiError::Internal(format!("Database init error: {msg}")),
    }
}

impl From<CronError> for ApiError {
    fn from(err: CronError) -> Self {
        match err {
            CronError::JobNotFound(msg) => ApiError::NotFound(msg),
            CronError::InvalidSchedule(msg) => ApiError::BadRequest(msg),
            CronError::InvalidCronExpression(msg) => ApiError::BadRequest(msg),
            CronError::InvalidExecutionMode(msg) => ApiError::BadRequest(msg),
            CronError::InvalidCreatedBy(msg) => ApiError::BadRequest(msg),
            CronError::InvalidJobStatus(msg) => ApiError::BadRequest(msg),
            CronError::InvalidTimezone(msg) => ApiError::BadRequest(msg),
            CronError::InvalidSkillContent(msg) => ApiError::BadRequest(msg),
            CronError::InvalidAgentConfig(msg) => ApiError::BadRequest(msg),
            CronError::CrossAccountReference(msg) => {
                ApiError::coded(StatusCode::CONFLICT, "CROSS_ACCOUNT_REFERENCE", msg, None)
            }
            CronError::Scheduler(msg) => ApiError::Internal(msg),
            CronError::WorkspacePathUnavailable(path) => ApiError::WorkspacePathUnavailable(path),
            CronError::WorkspacePathRuntimeUnavailable(path) => ApiError::WorkspacePathRuntimeUnavailable(path),
            CronError::Conversation(conversation_err) => ApiError::from(conversation_err),
            CronError::Database(db_err) => db_error_to_api_error(db_err),
            CronError::Json(e) => ApiError::Internal(format!("JSON error: {e}")),
        }
    }
}

pub fn cron_routes(state: CronRouterState) -> Router {
    Router::new()
        .route("/api/cron/jobs", get(list_jobs).post(create_job))
        .route("/api/cron/jobs/{id}", get(get_job).put(update_job).delete(delete_job))
        .route("/api/cron/jobs/{id}/run", post(run_now))
        .route("/api/internal/conversation-cron/create", post(create_conversation_cron))
        .route("/api/internal/conversation-cron/list", get(list_conversation_cron))
        .route(
            "/api/internal/conversation-cron/jobs/{id}",
            put(update_conversation_cron),
        )
        .route("/api/cron/internal/system-resume", post(system_resume))
        .route("/api/cron/jobs/{id}/conversations", get(list_conversations_by_cron_job))
        .route(
            "/api/cron/jobs/{id}/skill",
            get(has_skill).post(save_skill).delete(delete_skill),
        )
        .with_state(state)
}

async fn create_job(
    State(state): State<CronRouterState>,
    Extension(user): Extension<CurrentUser>,
    body: Result<Json<CreateCronJobRequest>, JsonRejection>,
) -> Result<(StatusCode, Json<ApiResponse<CronJobResponse>>), ApiError> {
    let Json(req) = body.map_err(ApiError::from)?;
    let job = state.cron_service.add_job(&user.id, req).await?;
    let resp = CronService::to_response(&job);
    Ok((StatusCode::CREATED, Json(ApiResponse::ok(resp))))
}

async fn list_jobs(
    State(state): State<CronRouterState>,
    Extension(user): Extension<CurrentUser>,
    Query(query): Query<ListCronJobsQuery>,
) -> Result<Json<ApiResponse<Vec<CronJobResponse>>>, ApiError> {
    let jobs = state.cron_service.list_jobs(&user.id, &query).await?;
    let items: Vec<CronJobResponse> = jobs.iter().map(CronService::to_response).collect();
    Ok(Json(ApiResponse::ok(items)))
}

async fn get_job(
    State(state): State<CronRouterState>,
    Extension(user): Extension<CurrentUser>,
    Path(id): Path<String>,
) -> Result<Json<ApiResponse<CronJobResponse>>, ApiError> {
    let job = state.cron_service.get_job(&user.id, &id).await?;
    Ok(Json(ApiResponse::ok(CronService::to_response(&job))))
}

async fn update_job(
    State(state): State<CronRouterState>,
    Extension(user): Extension<CurrentUser>,
    Path(id): Path<String>,
    body: Result<Json<UpdateCronJobRequest>, JsonRejection>,
) -> Result<Json<ApiResponse<CronJobResponse>>, ApiError> {
    let Json(req) = body.map_err(ApiError::from)?;
    let job = state.cron_service.update_job(&user.id, &id, req).await?;
    Ok(Json(ApiResponse::ok(CronService::to_response(&job))))
}

async fn delete_job(
    State(state): State<CronRouterState>,
    Extension(user): Extension<CurrentUser>,
    Path(id): Path<String>,
) -> Result<Json<ApiResponse<()>>, ApiError> {
    state.cron_service.remove_job(&user.id, &id).await?;
    Ok(Json(ApiResponse::success()))
}

async fn run_now(
    State(state): State<CronRouterState>,
    Extension(user): Extension<CurrentUser>,
    Path(id): Path<String>,
) -> Result<Json<ApiResponse<RunNowResponse>>, ApiError> {
    let resp = state.cron_service.run_now(&user.id, &id).await?;
    Ok(Json(ApiResponse::ok(resp)))
}

async fn system_resume(
    State(state): State<CronRouterState>,
    headers: HeaderMap,
) -> Result<Json<ApiResponse<()>>, ApiError> {
    let is_internal = headers.get("x-qianji-internal").and_then(|value| value.to_str().ok()) == Some("1");
    if !is_internal {
        return Err(ApiError::Forbidden("internal route".into()));
    }

    state.cron_service.handle_system_resume().await;
    Ok(Json(ApiResponse::success()))
}

async fn create_conversation_cron(
    State(state): State<CronRouterState>,
    Extension(current_user): Extension<CurrentUser>,
    headers: HeaderMap,
    body: Result<Json<CreateConversationCronRequest>, JsonRejection>,
) -> Result<Json<ApiResponse<CreateConversationCronResponse>>, ApiError> {
    let user_id = trusted_header_user_id(&headers, &current_user)?;
    let conversation_id = header_value(&headers, "x-qianji-conversation-id")?;
    let Json(req) = body.map_err(ApiError::from)?;
    let resp = state
        .cron_service
        .create_for_conversation_helper(&user_id, &conversation_id, req)
        .await?;
    Ok(Json(ApiResponse::ok(resp)))
}

async fn list_conversation_cron(
    State(state): State<CronRouterState>,
    Extension(current_user): Extension<CurrentUser>,
    headers: HeaderMap,
) -> Result<Json<ApiResponse<Vec<CronJobResponse>>>, ApiError> {
    let user_id = trusted_header_user_id(&headers, &current_user)?;
    let conversation_id = header_value(&headers, "x-qianji-conversation-id")?;
    let jobs = state
        .cron_service
        .list_for_conversation_helper(&user_id, &conversation_id)
        .await?;
    let items = jobs.iter().map(CronService::to_response).collect();
    Ok(Json(ApiResponse::ok(items)))
}

async fn update_conversation_cron(
    State(state): State<CronRouterState>,
    Extension(current_user): Extension<CurrentUser>,
    headers: HeaderMap,
    Path(id): Path<String>,
    body: Result<Json<UpdateConversationCronRequest>, JsonRejection>,
) -> Result<Json<ApiResponse<CronJobResponse>>, ApiError> {
    let user_id = trusted_header_user_id(&headers, &current_user)?;
    let conversation_id = header_value(&headers, "x-qianji-conversation-id")?;
    let Json(req) = body.map_err(ApiError::from)?;
    let job = state
        .cron_service
        .update_for_conversation_helper(&user_id, &conversation_id, &id, req)
        .await?;
    Ok(Json(ApiResponse::ok(CronService::to_response(&job))))
}

fn header_value(headers: &HeaderMap, name: &'static str) -> Result<String, ApiError> {
    headers
        .get(name)
        .and_then(|value| value.to_str().ok())
        .map(str::trim)
        .filter(|value| !value.is_empty())
        .map(str::to_owned)
        .ok_or_else(|| ApiError::BadRequest(format!("missing required header: {name}")))
}

fn trusted_header_user_id(headers: &HeaderMap, current_user: &CurrentUser) -> Result<String, ApiError> {
    let header_user_id = header_value(headers, "x-qianji-user-id")?;
    if header_user_id != current_user.id {
        return Err(ApiError::coded(
            StatusCode::FORBIDDEN,
            "CRON_HELPER_USER_MISMATCH",
            "Authenticated user does not match cron helper user header.",
            None,
        ));
    }
    Ok(header_user_id)
}

async fn save_skill(
    State(state): State<CronRouterState>,
    Extension(user): Extension<CurrentUser>,
    Path(id): Path<String>,
    body: Result<Json<SaveCronSkillRequest>, JsonRejection>,
) -> Result<Json<ApiResponse<()>>, ApiError> {
    let Json(req) = body.map_err(ApiError::from)?;
    state.cron_service.save_skill(&user.id, &id, req).await?;
    Ok(Json(ApiResponse::success()))
}

async fn list_conversations_by_cron_job(
    State(state): State<CronRouterState>,
    Extension(user): Extension<CurrentUser>,
    Path(id): Path<String>,
) -> Result<Json<ApiResponse<Vec<ConversationResponse>>>, ApiError> {
    let items = state.conversation_service.list_by_cron_job(&user.id, &id).await?;
    Ok(Json(ApiResponse::ok(items)))
}

async fn has_skill(
    State(state): State<CronRouterState>,
    Extension(user): Extension<CurrentUser>,
    Path(id): Path<String>,
) -> Result<Json<ApiResponse<HasSkillResponse>>, ApiError> {
    let resp = state.cron_service.has_skill(&user.id, &id).await?;
    Ok(Json(ApiResponse::ok(resp)))
}

async fn delete_skill(
    State(state): State<CronRouterState>,
    Extension(user): Extension<CurrentUser>,
    Path(id): Path<String>,
) -> Result<Json<ApiResponse<()>>, ApiError> {
    state.cron_service.delete_skill(&user.id, &id).await?;
    Ok(Json(ApiResponse::success()))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn header_value_rejects_missing_or_blank_required_header() {
        let mut headers = HeaderMap::new();

        assert!(matches!(
            header_value(&headers, "x-qianji-user-id"),
            Err(ApiError::BadRequest(message)) if message.contains("x-qianji-user-id")
        ));

        headers.insert("x-qianji-user-id", "   ".parse().unwrap());

        assert!(matches!(
            header_value(&headers, "x-qianji-user-id"),
            Err(ApiError::BadRequest(message)) if message.contains("x-qianji-user-id")
        ));
    }

    #[test]
    fn header_value_trims_required_header() {
        let mut headers = HeaderMap::new();
        headers.insert("x-qianji-user-id", " user_1 ".parse().unwrap());

        assert_eq!(header_value(&headers, "x-qianji-user-id").unwrap(), "user_1");
    }

    #[test]
    fn trusted_header_user_id_rejects_user_mismatch() {
        let mut headers = HeaderMap::new();
        headers.insert("x-qianji-user-id", "user_b".parse().unwrap());
        let current_user = CurrentUser {
            id: "user_a".to_owned(),
            username: "alice".to_owned(),
            user_type: qianji_db::UserType::Qianjipro,
            status: qianji_db::UserStatus::Active,
        };

        assert!(matches!(
            trusted_header_user_id(&headers, &current_user),
            Err(ApiError::Coded {
                code: "CRON_HELPER_USER_MISMATCH",
                ..
            })
        ));
    }

    #[test]
    fn trusted_header_user_id_accepts_authenticated_user() {
        let mut headers = HeaderMap::new();
        headers.insert("x-qianji-user-id", "user_a".parse().unwrap());
        let current_user = CurrentUser {
            id: "user_a".to_owned(),
            username: "alice".to_owned(),
            user_type: qianji_db::UserType::Qianjipro,
            status: qianji_db::UserStatus::Active,
        };

        assert_eq!(trusted_header_user_id(&headers, &current_user).unwrap(), "user_a");
    }

    #[test]
    fn job_not_found_maps_to_not_found() {
        let err: ApiError = CronError::JobNotFound("cron_abc".into()).into();
        assert!(matches!(err, ApiError::NotFound(msg) if msg == "cron_abc"));
    }

    #[test]
    fn invalid_schedule_maps_to_bad_request() {
        let err: ApiError = CronError::InvalidSchedule("missing kind".into()).into();
        assert!(matches!(err, ApiError::BadRequest(_)));
    }

    #[test]
    fn invalid_cron_expression_maps_to_bad_request() {
        let err: ApiError = CronError::InvalidCronExpression("bad expr".into()).into();
        assert!(matches!(err, ApiError::BadRequest(_)));
    }

    #[test]
    fn invalid_execution_mode_maps_to_bad_request() {
        let err: ApiError = CronError::InvalidExecutionMode("unknown".into()).into();
        assert!(matches!(err, ApiError::BadRequest(_)));
    }

    #[test]
    fn invalid_created_by_maps_to_bad_request() {
        let err: ApiError = CronError::InvalidCreatedBy("robot".into()).into();
        assert!(matches!(err, ApiError::BadRequest(_)));
    }

    #[test]
    fn invalid_job_status_maps_to_bad_request() {
        let err: ApiError = CronError::InvalidJobStatus("unknown".into()).into();
        assert!(matches!(err, ApiError::BadRequest(_)));
    }

    #[test]
    fn invalid_timezone_maps_to_bad_request() {
        let err: ApiError = CronError::InvalidTimezone("Mars/Olympus".into()).into();
        assert!(matches!(err, ApiError::BadRequest(_)));
    }

    #[test]
    fn invalid_skill_content_maps_to_bad_request() {
        let err: ApiError = CronError::InvalidSkillContent("empty".into()).into();
        assert!(matches!(err, ApiError::BadRequest(_)));
    }

    #[test]
    fn invalid_agent_config_maps_to_bad_request() {
        let err: ApiError = CronError::InvalidAgentConfig("missing backend".into()).into();
        assert!(matches!(err, ApiError::BadRequest(_)));
    }

    #[test]
    fn cross_account_reference_maps_to_stable_conflict_code() {
        let err: ApiError = CronError::CrossAccountReference("cross account".into()).into();
        assert_eq!(err.status_code(), StatusCode::CONFLICT);
        assert_eq!(err.error_code(), "CROSS_ACCOUNT_REFERENCE");
    }

    #[test]
    fn scheduler_error_maps_to_internal() {
        let err: ApiError = CronError::Scheduler("timer failed".into()).into();
        assert!(matches!(err, ApiError::Internal(_)));
    }

    #[test]
    fn workspace_error_preserves_code() {
        let err: ApiError = CronError::WorkspacePathUnavailable("/tmp/a b".into()).into();
        assert!(matches!(err, ApiError::WorkspacePathUnavailable(msg) if msg == "/tmp/a b"));
    }

    #[test]
    fn conversation_error_maps_through_boundary_mapper() {
        let err: ApiError =
            CronError::Conversation(qianji_conversation::ConversationError::NotFound { id: "conv-1".into() }).into();
        assert!(matches!(err, ApiError::NotFound(msg) if msg == "Conversation conv-1 not found"));
    }

    #[test]
    fn runtime_workspace_error_preserves_code() {
        let err: ApiError = CronError::WorkspacePathRuntimeUnavailable("/tmp/a b".into()).into();
        assert!(matches!(
            err,
            ApiError::WorkspacePathRuntimeUnavailable(msg) if msg == "/tmp/a b"
        ));
    }

    #[test]
    fn json_error_maps_to_internal() {
        let json_err = serde_json::from_str::<serde_json::Value>("invalid").unwrap_err();
        let err: ApiError = CronError::Json(json_err).into();
        assert!(matches!(err, ApiError::Internal(_)));
    }
}
