use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::{Arc, Mutex};
use std::time::Duration;

use qianji_common::now_ms;
use qianji_db::IConversationRepository;
use qianji_realtime::EventBroadcaster;
use tokio::fs;
use tokio::time::sleep;
use tracing::{debug, warn};

use crate::artifacts::{broadcast_artifact, build_skill_suggest_artifact};
use crate::error::CronError;
use crate::prompt::SKILL_SUGGEST_FILENAME;
use crate::skill_file::{content_hash, has_skill_file, validate_skill_content};

const RETRY_DELAYS_MS: [u64; 3] = [1000, 2000, 3000];

#[derive(Clone)]
pub struct SkillSuggestDetector {
    broadcaster: Arc<dyn EventBroadcaster>,
    conversation_repo: Arc<dyn IConversationRepository>,
    data_dir: PathBuf,
    last_hash_by_target: Arc<Mutex<HashMap<String, String>>>,
}

impl SkillSuggestDetector {
    pub fn new(
        broadcaster: Arc<dyn EventBroadcaster>,
        conversation_repo: Arc<dyn IConversationRepository>,
        data_dir: PathBuf,
    ) -> Self {
        Self {
            broadcaster,
            conversation_repo,
            data_dir,
            last_hash_by_target: Arc::new(Mutex::new(HashMap::new())),
        }
    }

    pub fn schedule_check(&self, user_id: String, conversation_id: String, job_id: String, workspace: String) {
        let detector = self.clone();
        tokio::spawn(async move {
            detector
                .check_with_retry(&user_id, &conversation_id, &job_id, &workspace)
                .await;
        });
    }

    async fn check_with_retry(&self, user_id: &str, conversation_id: &str, job_id: &str, workspace: &str) {
        for delay_ms in RETRY_DELAYS_MS {
            sleep(Duration::from_millis(delay_ms)).await;
            match self.check_and_emit(user_id, conversation_id, job_id, workspace).await {
                Ok(true) => return,
                Ok(false) => continue,
                Err(err) => {
                    warn!(
                        conversation_id,
                        job_id,
                        error = %err,
                        "Failed checking SKILL_SUGGEST.md"
                    );
                }
            }
        }
    }

    async fn check_and_emit(
        &self,
        user_id: &str,
        conversation_id: &str,
        job_id: &str,
        workspace: &str,
    ) -> Result<bool, CronError> {
        if workspace.trim().is_empty() {
            return Ok(false);
        }

        if has_skill_file(&self.data_dir, job_id).await? {
            self.clear_last_hash(job_id);
            return Ok(true);
        }

        let file_path = Path::new(workspace).join(SKILL_SUGGEST_FILENAME);
        let content = match fs::read_to_string(&file_path).await {
            Ok(content) => content,
            Err(err) if err.kind() == std::io::ErrorKind::NotFound => return Ok(false),
            Err(err) => {
                return Err(CronError::InvalidSkillContent(err.to_string()));
            }
        };

        if content.trim().is_empty() {
            return Ok(false);
        }

        let validated = match validate_skill_content(&content) {
            Ok(validated) => validated,
            Err(_) => return Ok(false),
        };

        let hash = content_hash(&content);
        if self.last_hash(conversation_id, job_id).as_deref() == Some(hash.as_str()) {
            return Ok(true);
        }

        self.set_last_hash(conversation_id, job_id, hash);
        self.emit(
            user_id,
            conversation_id,
            job_id,
            &validated.name,
            &validated.description,
            &content,
        )
        .await;
        Ok(true)
    }

    async fn emit(
        &self,
        user_id: &str,
        conversation_id: &str,
        job_id: &str,
        name: &str,
        description: &str,
        skill_content: &str,
    ) {
        self.persist_and_broadcast(user_id, conversation_id, job_id, name, description, skill_content)
            .await;
    }

    async fn persist_and_broadcast(
        &self,
        user_id: &str,
        conversation_id: &str,
        job_id: &str,
        name: &str,
        description: &str,
        skill_content: &str,
    ) {
        let row = build_skill_suggest_artifact(conversation_id, job_id, name, description, skill_content, now_ms());

        let row = match self.conversation_repo.upsert_artifact(user_id, &row).await {
            Ok(row) => row,
            Err(err) => {
                warn!(
                    conversation_id,
                    job_id,
                    error = %err,
                    "Failed persisting cron skill suggestion artifact"
                );
                return;
            }
        };

        if let Err(err) = broadcast_artifact(&self.broadcaster, user_id, &row) {
            warn!(
                conversation_id,
                job_id,
                error = %err,
                "Failed broadcasting cron skill suggestion artifact"
            );
            return;
        }
        debug!(conversation_id, job_id, "Broadcasted cron skill suggestion artifact");
    }

    fn last_hash(&self, conversation_id: &str, job_id: &str) -> Option<String> {
        let key = last_hash_key(conversation_id, job_id);
        self.last_hash_by_target
            .lock()
            .ok()
            .and_then(|hashes| hashes.get(&key).cloned())
    }

    fn set_last_hash(&self, conversation_id: &str, job_id: &str, hash: String) {
        if let Ok(mut hashes) = self.last_hash_by_target.lock() {
            hashes.insert(last_hash_key(conversation_id, job_id), hash);
        }
    }

    fn clear_last_hash(&self, job_id: &str) {
        if let Ok(mut hashes) = self.last_hash_by_target.lock() {
            let prefix = format!("{job_id}:");
            hashes.retain(|key, _| !key.starts_with(&prefix));
        }
    }
}

fn last_hash_key(conversation_id: &str, job_id: &str) -> String {
    format!("{job_id}:{conversation_id}")
}

#[cfg(test)]
mod tests {
    use super::*;
    use qianji_db::models::ConversationRow;
    use qianji_db::{SqliteConversationRepository, init_database_memory};
    use qianji_realtime::BroadcastEventBus;
    use tempfile::tempdir;

    fn make_conversation(id: &str) -> ConversationRow {
        ConversationRow {
            id: id.into(),
            user_id: "system_default_user".into(),
            name: "Cron Conversation".into(),
            r#type: "acp".into(),
            extra: "{}".into(),
            model: None,
            status: Some("finished".into()),
            source: Some("qianji".into()),
            channel_chat_id: None,
            pinned: false,
            pinned_at: None,
            created_at: now_ms(),
            updated_at: now_ms(),
            project_id: None,
            folder_id: None,
            name_source: None,
        }
    }

    #[tokio::test]
    async fn emits_skill_suggest_when_file_is_valid() {
        let temp = tempdir().unwrap();
        let workspace = temp.path().join("workspace");
        tokio::fs::create_dir_all(&workspace).await.unwrap();
        tokio::fs::write(
            workspace.join(SKILL_SUGGEST_FILENAME),
            "---\nname: daily-report\ndescription: Daily report\n---\n\nCheck sources.\n",
        )
        .await
        .unwrap();

        let db = init_database_memory().await.unwrap();
        let repo: Arc<dyn IConversationRepository> = Arc::new(SqliteConversationRepository::new(db.pool().clone()));
        repo.create(&make_conversation("conv-1")).await.unwrap();

        let bus = Arc::new(BroadcastEventBus::new(16));
        let detector = SkillSuggestDetector::new(bus.clone(), repo.clone(), temp.path().to_path_buf());
        let mut rx = bus.subscribe();

        let emitted = detector
            .check_and_emit("system_default_user", "conv-1", "cron-1", &workspace.to_string_lossy())
            .await
            .unwrap();

        assert!(emitted);
        let msg = rx.try_recv().unwrap();
        assert_eq!(msg.name, "conversation.artifact");
        assert_eq!(msg.data["kind"], "skill_suggest");
        assert_eq!(msg.data["status"], "pending");
        assert_eq!(msg.data["payload"]["cron_job_id"], "cron-1");
        assert_eq!(msg.data["payload"]["name"], "daily-report");

        let rows = repo.list_artifacts("system_default_user", "conv-1").await.unwrap();
        assert_eq!(rows.len(), 1);
        assert_eq!(rows[0].kind, "skill_suggest");
        assert_eq!(rows[0].status, "pending");
        assert!(rows[0].payload.contains("\"skillContent\""));
    }

    #[tokio::test]
    async fn emits_same_skill_suggest_content_for_each_conversation() {
        let temp = tempdir().unwrap();
        let workspace = temp.path().join("workspace");
        tokio::fs::create_dir_all(&workspace).await.unwrap();
        tokio::fs::write(
            workspace.join(SKILL_SUGGEST_FILENAME),
            "---\nname: daily-report\ndescription: Daily report\n---\n\nCheck sources.\n",
        )
        .await
        .unwrap();

        let db = init_database_memory().await.unwrap();
        let repo: Arc<dyn IConversationRepository> = Arc::new(SqliteConversationRepository::new(db.pool().clone()));
        repo.create(&make_conversation("conv-1")).await.unwrap();
        repo.create(&make_conversation("conv-2")).await.unwrap();

        let bus = Arc::new(BroadcastEventBus::new(16));
        let detector = SkillSuggestDetector::new(bus.clone(), repo, temp.path().to_path_buf());
        let mut rx = bus.subscribe();

        assert!(
            detector
                .check_and_emit("system_default_user", "conv-1", "cron-1", &workspace.to_string_lossy(),)
                .await
                .unwrap()
        );
        assert!(rx.try_recv().is_ok());

        assert!(
            detector
                .check_and_emit("system_default_user", "conv-2", "cron-1", &workspace.to_string_lossy(),)
                .await
                .unwrap()
        );
        let msg = rx.try_recv().unwrap();
        assert_eq!(msg.name, "conversation.artifact");
        assert_eq!(msg.data["conversation_id"], "conv-2");
        assert_eq!(msg.data["kind"], "skill_suggest");
    }

    #[tokio::test]
    async fn suppresses_duplicate_skill_suggest_content_for_same_conversation() {
        let temp = tempdir().unwrap();
        let workspace = temp.path().join("workspace");
        tokio::fs::create_dir_all(&workspace).await.unwrap();
        tokio::fs::write(
            workspace.join(SKILL_SUGGEST_FILENAME),
            "---\nname: daily-report\ndescription: Daily report\n---\n\nCheck sources.\n",
        )
        .await
        .unwrap();

        let db = init_database_memory().await.unwrap();
        let repo: Arc<dyn IConversationRepository> = Arc::new(SqliteConversationRepository::new(db.pool().clone()));
        repo.create(&make_conversation("conv-1")).await.unwrap();

        let bus = Arc::new(BroadcastEventBus::new(16));
        let detector = SkillSuggestDetector::new(bus.clone(), repo, temp.path().to_path_buf());
        let mut rx = bus.subscribe();

        assert!(
            detector
                .check_and_emit("system_default_user", "conv-1", "cron-1", &workspace.to_string_lossy(),)
                .await
                .unwrap()
        );
        assert!(rx.try_recv().is_ok());

        assert!(
            detector
                .check_and_emit("system_default_user", "conv-1", "cron-1", &workspace.to_string_lossy(),)
                .await
                .unwrap()
        );
        assert!(rx.try_recv().is_err());
    }

    #[tokio::test]
    async fn suppresses_skill_suggest_when_saved_skill_exists() {
        let temp = tempdir().unwrap();
        let workspace = temp.path().join("workspace");
        tokio::fs::create_dir_all(&workspace).await.unwrap();
        tokio::fs::write(
            workspace.join(SKILL_SUGGEST_FILENAME),
            "---\nname: daily-report\ndescription: Daily report\n---\n\nCheck sources.\n",
        )
        .await
        .unwrap();
        let skill_dir = temp.path().join("cron/skills/cron-cron-1");
        tokio::fs::create_dir_all(&skill_dir).await.unwrap();
        tokio::fs::write(
            skill_dir.join("SKILL.md"),
            "---\nname: saved-skill\ndescription: Saved skill\n---\n\nDo the task.\n",
        )
        .await
        .unwrap();

        let db = init_database_memory().await.unwrap();
        let repo: Arc<dyn IConversationRepository> = Arc::new(SqliteConversationRepository::new(db.pool().clone()));
        repo.create(&make_conversation("conv-1")).await.unwrap();

        let bus = Arc::new(BroadcastEventBus::new(16));
        let detector = SkillSuggestDetector::new(bus.clone(), repo, temp.path().to_path_buf());
        let mut rx = bus.subscribe();

        let emitted = detector
            .check_and_emit("system_default_user", "conv-1", "cron-1", &workspace.to_string_lossy())
            .await
            .unwrap();

        assert!(emitted);
        assert!(rx.try_recv().is_err());
    }
}
