use qianji_db::{IAgentMetadataRepository, SqliteAgentMetadataRepository, init_database_memory};

/// Migration 038: the builtin qianjirs agent (Qianji CLI, seed id `632f31d2`)
/// carries a constructed at-turn fork capability — the same shape 036 wrote
/// for codex (turn anchors are stamped by the qianjirs manager + engine).
#[tokio::test]
async fn qianjirs_builtin_agent_declares_at_turn_fork_capability() {
    let db = init_database_memory().await.unwrap();
    let repo = SqliteAgentMetadataRepository::new(db.pool().clone());

    let qianjirs = repo.get("632f31d2").await.unwrap().expect("seeded Qianji CLI row");
    assert_eq!(qianjirs.agent_type, "qianjirs");
    assert_eq!(qianjirs.backend, None, "qianjirs resolves by agent_type, not backend");

    let capabilities: serde_json::Value = serde_json::from_str(
        qianjirs
            .agent_capabilities
            .as_deref()
            .expect("constructed capabilities"),
    )
    .unwrap();
    assert_eq!(
        capabilities["session_capabilities"]["fork"],
        serde_json::json!({"at_turn": true}),
        "at-turn fork: anchors are stamped on qianjirs rows and session messages"
    );
}
