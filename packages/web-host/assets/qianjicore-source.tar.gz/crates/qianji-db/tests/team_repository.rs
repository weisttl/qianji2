//! Black-box integration tests for `ITeamRepository`.
//!
//! Tests exercise the repository trait interface without knowledge of
//! the underlying SQLite implementation details.
//!
//! Covers test-plan items from Phase 11 test-plan:
//! - Section 1 (Team CRUD): TC-1..TC-7, TL-1..TL-3, TG-1..TG-2, TD-1..TD-6, TR-1..TR-4
//! - Section 4 (Mailbox): MW-1..MW-3, MR-1..MR-4, MH-1..MH-3, MD-1..MD-2
//! - Section 5 (Task Board): TK-1..TK-3, TU-1..TU-5, CU-1..CU-4, TT-1..TT-3, TKD-1..TKD-2
//! - Section 10 (Data Consistency): DC-1, DC-4

use std::sync::Arc;

use qianji_common::now_ms;
use qianji_db::models::{MailboxMessageRow, TeamRow, TeamTaskRow};
use qianji_db::{
    ActivityCursor, DbError, ITeamRepository, PageDirection, SqliteTeamRepository, UpdateTaskParams, UpdateTeamParams,
    init_database_memory,
};

const DEFAULT_USER_ID: &str = "system_default_user";

async fn repo() -> (Arc<dyn ITeamRepository>, qianji_db::Database) {
    let db = init_database_memory().await.unwrap();
    let r = Arc::new(SqliteTeamRepository::new(db.pool().clone()));
    (r as Arc<dyn ITeamRepository>, db)
}

fn make_team(id: &str, name: &str) -> TeamRow {
    make_team_for_user(id, DEFAULT_USER_ID, name)
}

fn make_team_for_user(id: &str, user_id: &str, name: &str) -> TeamRow {
    let now = now_ms();
    TeamRow {
        id: id.into(),
        user_id: user_id.into(),
        name: name.into(),
        workspace: String::new(),
        workspace_mode: "shared".into(),
        agents:
            r#"[{"slot_id":"a1","name":"Lead","role":"lead","conversation_id":"conv-1","backend":"claude","model":""}]"#
                .into(),
        lead_agent_id: Some("a1".into()),
        session_mode: None,
        agents_version: "1.0.1".into(),
        created_at: now,
        updated_at: now,
        project_id: None,
        folder_id: None,
    }
}

fn make_mailbox_msg(id: &str, team_id: &str, to: &str, from: &str, msg_type: &str) -> MailboxMessageRow {
    MailboxMessageRow {
        id: id.into(),
        team_id: team_id.into(),
        to_agent_id: to.into(),
        from_agent_id: from.into(),
        msg_type: msg_type.into(),
        content: format!("content-{id}"),
        summary: None,
        files: None,
        read: false,
        created_at: now_ms(),
    }
}

fn make_task(id: &str, team_id: &str, subject: &str) -> TeamTaskRow {
    let now = now_ms();
    TeamTaskRow {
        id: id.into(),
        team_id: team_id.into(),
        subject: subject.into(),
        description: None,
        status: "pending".into(),
        owner: None,
        blocked_by: "[]".into(),
        blocks: "[]".into(),
        metadata: None,
        created_at: now,
        updated_at: now,
    }
}

// ── Team CRUD Tests ──────────────────────────────────────────────────

#[tokio::test]
async fn create_and_get_team() {
    let (repo, _db) = repo().await;
    let team = make_team("t1", "Team Alpha");
    repo.create_team(&team).await.unwrap();

    let fetched = repo
        .get_team("system_default_user", "t1")
        .await
        .unwrap()
        .expect("team exists");
    assert_eq!(fetched.id, "t1");
    assert_eq!(fetched.name, "Team Alpha");
    assert_eq!(fetched.lead_agent_id, Some("a1".into()));
}

#[tokio::test]
async fn get_nonexistent_team_returns_none() {
    let (repo, _db) = repo().await;
    let result = repo.get_team("system_default_user", "nonexistent").await.unwrap();
    assert!(result.is_none());
}

#[tokio::test]
async fn list_teams_empty() {
    let (repo, _db) = repo().await;
    let teams = repo.list_teams_for_restore().await.unwrap();
    assert!(teams.is_empty());
}

#[tokio::test]
async fn list_teams_multiple() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team("t1", "Alpha")).await.unwrap();
    repo.create_team(&make_team("t2", "Beta")).await.unwrap();

    let teams = repo.list_teams_for_restore().await.unwrap();
    assert_eq!(teams.len(), 2);
    assert_eq!(teams[0].id, "t1");
    assert_eq!(teams[1].id, "t2");
}

#[tokio::test]
async fn list_teams_by_user_filters_to_owner() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team_for_user("t1", "user-a", "Alpha"))
        .await
        .unwrap();
    repo.create_team(&make_team_for_user("t2", "user-b", "Beta"))
        .await
        .unwrap();
    repo.create_team(&make_team_for_user("t3", "user-a", "Gamma"))
        .await
        .unwrap();

    let teams = repo.list_teams_by_user("user-a").await.unwrap();

    assert_eq!(teams.len(), 2);
    assert_eq!(teams[0].id, "t1");
    assert_eq!(teams[1].id, "t3");
    assert!(teams.iter().all(|team| team.user_id == "user-a"));
}

#[tokio::test]
async fn list_teams_by_user_excludes_archived() {
    let (repo, db) = repo().await;
    repo.create_team(&make_team_for_user("t1", "user-a", "Active"))
        .await
        .unwrap();
    repo.create_team(&make_team_for_user("t2", "user-a", "Archived"))
        .await
        .unwrap();
    sqlx::query("UPDATE teams SET archived_at = ? WHERE id = ?")
        .bind(1_700_000_000_000_i64)
        .bind("t2")
        .execute(db.pool())
        .await
        .unwrap();

    // The active list hides the archived team...
    let active = repo.list_teams_by_user("user-a").await.unwrap();
    assert_eq!(active.len(), 1);
    assert_eq!(active[0].id, "t1");

    // ...but the restore path is unaffected and still sees it.
    let all = repo.list_teams_for_restore().await.unwrap();
    assert_eq!(all.len(), 2);
}

#[tokio::test]
async fn scoped_team_crud_rejects_wrong_user() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team_for_user("t1", "user-a", "Alpha"))
        .await
        .unwrap();

    assert!(repo.get_team("user-b", "t1").await.unwrap().is_none());

    let update = repo
        .update_team(
            "user-b",
            "t1",
            &UpdateTeamParams {
                name: Some("Leaked".into()),
                ..Default::default()
            },
        )
        .await;
    assert!(matches!(update, Err(DbError::NotFound(_))));

    let delete = repo.delete_team("user-b", "t1").await;
    assert!(matches!(delete, Err(DbError::NotFound(_))));

    let team = repo.get_team("user-a", "t1").await.unwrap().unwrap();
    assert_eq!(team.name, "Alpha");
}

#[tokio::test]
async fn update_team_name() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team("t1", "Old Name")).await.unwrap();

    repo.update_team(
        "system_default_user",
        "t1",
        &UpdateTeamParams {
            name: Some("New Name".into()),
            ..Default::default()
        },
    )
    .await
    .unwrap();

    let team = repo.get_team("system_default_user", "t1").await.unwrap().unwrap();
    assert_eq!(team.name, "New Name");
}

#[tokio::test]
async fn update_team_agents_json() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team("t1", "Team")).await.unwrap();

    let new_agents = r#"[{"slotId":"a1"},{"slotId":"a2"}]"#;
    repo.update_team(
        "system_default_user",
        "t1",
        &UpdateTeamParams {
            agents: Some(new_agents.into()),
            ..Default::default()
        },
    )
    .await
    .unwrap();

    let team = repo.get_team("system_default_user", "t1").await.unwrap().unwrap();
    assert_eq!(team.agents, new_agents);
}

#[tokio::test]
async fn update_team_can_patch_workspace() {
    let db = init_database_memory().await.unwrap();
    let repo = SqliteTeamRepository::new(db.pool().clone());
    repo.create_team(&make_team("t1", "Team")).await.unwrap();

    repo.update_team(
        "system_default_user",
        "t1",
        &UpdateTeamParams {
            workspace: Some("/tmp/qianji-team-shared-workspace".into()),
            ..Default::default()
        },
    )
    .await
    .unwrap();

    let updated = repo.get_team("system_default_user", "t1").await.unwrap().unwrap();
    assert_eq!(updated.workspace, "/tmp/qianji-team-shared-workspace");
}

#[tokio::test]
async fn update_team_can_patch_session_mode() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team("t1", "Team")).await.unwrap();

    repo.update_team(
        "system_default_user",
        "t1",
        &UpdateTeamParams {
            session_mode: Some("full_auto".into()),
            ..Default::default()
        },
    )
    .await
    .unwrap();

    let updated = repo.get_team("system_default_user", "t1").await.unwrap().unwrap();
    assert_eq!(updated.session_mode.as_deref(), Some("full_auto"));
}

#[tokio::test]
async fn update_nonexistent_team_returns_not_found() {
    let (repo, _db) = repo().await;
    let result = repo
        .update_team(
            "system_default_user",
            "nonexistent",
            &UpdateTeamParams {
                name: Some("X".into()),
                ..Default::default()
            },
        )
        .await;
    assert!(matches!(result, Err(DbError::NotFound(_))));
}

#[tokio::test]
async fn delete_team() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team("t1", "Team")).await.unwrap();
    repo.delete_team("system_default_user", "t1").await.unwrap();

    let result = repo.get_team("system_default_user", "t1").await.unwrap();
    assert!(result.is_none());
}

#[tokio::test]
async fn delete_nonexistent_team_returns_not_found() {
    let (repo, _db) = repo().await;
    let result = repo.delete_team("system_default_user", "nonexistent").await;
    assert!(matches!(result, Err(DbError::NotFound(_))));
}

// ── Mailbox Tests ────────────────────────────────────────────────────

#[tokio::test]
async fn write_and_read_unread_messages() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team("t1", "Team")).await.unwrap();

    // Write 3 messages to agent a1
    for i in 1..=3 {
        let msg = make_mailbox_msg(&format!("m{i}"), "t1", "a1", "a2", "message");
        repo.write_message(DEFAULT_USER_ID, &msg).await.unwrap();
    }

    // Read unread: should return 3
    let unread = repo.read_unread_and_mark(DEFAULT_USER_ID, "t1", "a1").await.unwrap();
    assert_eq!(unread.len(), 3);
    assert!(!unread[0].read); // returned rows reflect pre-mark state
    assert_eq!(unread[0].msg_type, "message");

    // Read again: should return 0 (all marked read)
    let unread2 = repo.read_unread_and_mark(DEFAULT_USER_ID, "t1", "a1").await.unwrap();
    assert!(unread2.is_empty());
}

#[tokio::test]
async fn read_unread_no_messages() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team("t1", "Team")).await.unwrap();

    let unread = repo.read_unread_and_mark(DEFAULT_USER_ID, "t1", "a1").await.unwrap();
    assert!(unread.is_empty());
}

#[tokio::test]
async fn write_idle_notification_with_summary() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team("t1", "Team")).await.unwrap();

    let mut msg = make_mailbox_msg("m1", "t1", "a1", "a2", "idle_notification");
    msg.summary = Some("Task completed".into());
    repo.write_message(DEFAULT_USER_ID, &msg).await.unwrap();

    let history = repo.get_history(DEFAULT_USER_ID, "t1", "a1", None).await.unwrap();
    assert_eq!(history.len(), 1);
    assert_eq!(history[0].msg_type, "idle_notification");
    assert_eq!(history[0].summary.as_deref(), Some("Task completed"));
}

#[tokio::test]
async fn write_shutdown_request() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team("t1", "Team")).await.unwrap();

    let msg = make_mailbox_msg("m1", "t1", "a1", "a2", "shutdown_request");
    repo.write_message(DEFAULT_USER_ID, &msg).await.unwrap();

    let history = repo.get_history(DEFAULT_USER_ID, "t1", "a1", None).await.unwrap();
    assert_eq!(history.len(), 1);
    assert_eq!(history[0].msg_type, "shutdown_request");
}

#[tokio::test]
async fn get_history_with_limit() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team("t1", "Team")).await.unwrap();

    for i in 1..=10 {
        let msg = make_mailbox_msg(&format!("m{i}"), "t1", "a1", "a2", "message");
        repo.write_message(DEFAULT_USER_ID, &msg).await.unwrap();
    }

    let history = repo.get_history(DEFAULT_USER_ID, "t1", "a1", Some(5)).await.unwrap();
    assert_eq!(history.len(), 5);
}

#[tokio::test]
async fn get_history_no_limit() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team("t1", "Team")).await.unwrap();

    for i in 1..=3 {
        let msg = make_mailbox_msg(&format!("m{i}"), "t1", "a1", "a2", "message");
        repo.write_message(DEFAULT_USER_ID, &msg).await.unwrap();
    }

    let history = repo.get_history(DEFAULT_USER_ID, "t1", "a1", None).await.unwrap();
    assert_eq!(history.len(), 3);
}

#[tokio::test]
async fn get_history_empty() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team("t1", "Team")).await.unwrap();

    let history = repo.get_history(DEFAULT_USER_ID, "t1", "a1", None).await.unwrap();
    assert!(history.is_empty());
}

#[tokio::test]
async fn get_history_includes_read_messages() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team("t1", "Team")).await.unwrap();

    let msg = make_mailbox_msg("m1", "t1", "a1", "a2", "message");
    repo.write_message(DEFAULT_USER_ID, &msg).await.unwrap();

    // Read and mark
    repo.read_unread_and_mark(DEFAULT_USER_ID, "t1", "a1").await.unwrap();

    // History should still return the message
    let history = repo.get_history(DEFAULT_USER_ID, "t1", "a1", None).await.unwrap();
    assert_eq!(history.len(), 1);
    assert!(history[0].read);
}

#[tokio::test]
async fn delete_mailbox_by_team() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team("t1", "Team1")).await.unwrap();
    repo.create_team(&make_team("t2", "Team2")).await.unwrap();

    // Write messages to both teams
    let msg1 = make_mailbox_msg("m1", "t1", "a1", "a2", "message");
    let msg2 = make_mailbox_msg("m2", "t2", "a1", "a2", "message");
    repo.write_message(DEFAULT_USER_ID, &msg1).await.unwrap();
    repo.write_message(DEFAULT_USER_ID, &msg2).await.unwrap();

    // Delete team1 mailbox
    repo.delete_mailbox_by_team("system_default_user", "t1").await.unwrap();

    // Team1 mailbox empty
    let h1 = repo.get_history(DEFAULT_USER_ID, "t1", "a1", None).await.unwrap();
    assert!(h1.is_empty());

    // Team2 mailbox intact
    let h2 = repo.get_history(DEFAULT_USER_ID, "t2", "a1", None).await.unwrap();
    assert_eq!(h2.len(), 1);
}

#[tokio::test]
async fn list_messages_by_team_orders_desc_and_clamps_limit() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team("t1", "Team")).await.unwrap();

    // Distinct created_at so DESC ordering is deterministic.
    for i in 1..=5 {
        let mut msg = make_mailbox_msg(&format!("m{i}"), "t1", &format!("a{i}"), "lead", "message");
        msg.created_at = i as i64 * 1000;
        repo.write_message(DEFAULT_USER_ID, &msg).await.unwrap();
    }

    // limit smaller than total keeps the newest ones, newest first.
    let latest = repo.list_messages_by_team("t1", 3).await.unwrap();
    assert_eq!(latest.len(), 3);
    assert_eq!(latest[0].id, "m5");
    assert_eq!(latest[1].id, "m4");
    assert_eq!(latest[2].id, "m3");

    // limit above total returns everything (whole team, not a single mailbox).
    let all = repo.list_messages_by_team("t1", 1000).await.unwrap();
    assert_eq!(all.len(), 5);
    assert_eq!(all.first().unwrap().id, "m5");
}

#[tokio::test]
async fn list_messages_by_team_limit_one() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team("t1", "Team")).await.unwrap();
    for i in 1..=3 {
        let mut msg = make_mailbox_msg(&format!("m{i}"), "t1", "a1", "lead", "message");
        msg.created_at = i as i64 * 1000;
        repo.write_message(DEFAULT_USER_ID, &msg).await.unwrap();
    }

    let one = repo.list_messages_by_team("t1", 1).await.unwrap();
    assert_eq!(one.len(), 1);
    assert_eq!(one[0].id, "m3");
}

#[tokio::test]
async fn list_messages_by_team_empty() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team("t1", "Team")).await.unwrap();

    let msgs = repo.list_messages_by_team("t1", 500).await.unwrap();
    assert!(msgs.is_empty());
}

#[tokio::test]
async fn list_messages_by_ids_hits_empty_and_partial() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team("t1", "Team")).await.unwrap();
    for i in 1..=3 {
        let mut msg = make_mailbox_msg(&format!("m{i}"), "t1", "a1", "lead", "message");
        msg.created_at = i as i64 * 1000;
        repo.write_message(DEFAULT_USER_ID, &msg).await.unwrap();
    }

    // Empty ids -> empty result without touching the DB.
    let none = repo.list_messages_by_ids(&[]).await.unwrap();
    assert!(none.is_empty());

    // Mix of existing and missing ids returns only the hits, newest first.
    let hits = repo
        .list_messages_by_ids(&["m1".to_string(), "m3".to_string(), "missing".to_string()])
        .await
        .unwrap();
    assert_eq!(hits.len(), 2);
    assert_eq!(hits[0].id, "m3");
    assert_eq!(hits[1].id, "m1");
}

#[tokio::test]
async fn scoped_mailbox_delete_and_mark_read_do_not_cross_team_owner() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team_for_user("t1", "user-a", "Team A"))
        .await
        .unwrap();
    repo.create_team(&make_team_for_user("t2", "user-b", "Team B"))
        .await
        .unwrap();
    repo.write_message("user-a", &make_mailbox_msg("m1", "t1", "a1", "a2", "message"))
        .await
        .unwrap();
    repo.write_message("user-b", &make_mailbox_msg("m2", "t2", "a1", "a2", "message"))
        .await
        .unwrap();

    repo.mark_read_batch("user-a", "t1", &["m2".to_owned()]).await.unwrap();
    assert!(!repo.get_history("user-b", "t2", "a1", None).await.unwrap()[0].read);

    repo.delete_mailbox_by_team("user-b", "t1").await.unwrap();
    assert_eq!(repo.get_history("user-a", "t1", "a1", None).await.unwrap().len(), 1);
}

#[tokio::test]
async fn mailbox_child_methods_do_not_cross_team_owner() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team_for_user("t1", "user-a", "Team A"))
        .await
        .unwrap();
    let msg = make_mailbox_msg("m1", "t1", "a1", "a2", "message");
    repo.write_message("user-a", &msg).await.unwrap();

    assert!(repo.get_history("user-b", "t1", "a1", None).await.unwrap().is_empty());
    assert!(repo.peek_unread("user-b", "t1", "a1").await.unwrap().is_empty());
    assert!(
        repo.read_unread_and_mark("user-b", "t1", "a1")
            .await
            .unwrap()
            .is_empty()
    );

    repo.mark_read_batch("user-b", "t1", &["m1".to_owned()]).await.unwrap();
    assert!(!repo.get_history("user-a", "t1", "a1", None).await.unwrap()[0].read);

    let wrong_user_write = repo
        .write_message("user-b", &make_mailbox_msg("m2", "t1", "a1", "a2", "message"))
        .await;
    assert!(matches!(wrong_user_write, Err(DbError::NotFound(_))));
}

// ── Task Board Tests ─────────────────────────────────────────────────

#[tokio::test]
async fn create_and_list_tasks() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team("t1", "Team")).await.unwrap();

    let task = make_task("tk1", "t1", "Implement feature");
    repo.create_task(DEFAULT_USER_ID, &task).await.unwrap();

    let tasks = repo.list_tasks(DEFAULT_USER_ID, "t1").await.unwrap();
    assert_eq!(tasks.len(), 1);
    assert_eq!(tasks[0].subject, "Implement feature");
    assert_eq!(tasks[0].status, "pending");
}

#[tokio::test]
async fn list_tasks_empty() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team("t1", "Team")).await.unwrap();

    let tasks = repo.list_tasks(DEFAULT_USER_ID, "t1").await.unwrap();
    assert!(tasks.is_empty());
}

#[tokio::test]
async fn find_task_by_id() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team("t1", "Team")).await.unwrap();

    let task = make_task("tk1", "t1", "Task");
    repo.create_task(DEFAULT_USER_ID, &task).await.unwrap();

    let found = repo.find_task_by_id(DEFAULT_USER_ID, "t1", "tk1").await.unwrap();
    assert!(found.is_some());
    assert_eq!(found.unwrap().id, "tk1");
}

#[tokio::test]
async fn find_task_by_id_not_found() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team("t1", "Team")).await.unwrap();

    let found = repo
        .find_task_by_id(DEFAULT_USER_ID, "t1", "nonexistent")
        .await
        .unwrap();
    assert!(found.is_none());
}

#[tokio::test]
async fn update_task_status() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team("t1", "Team")).await.unwrap();

    let task = make_task("tk1", "t1", "Task");
    repo.create_task(DEFAULT_USER_ID, &task).await.unwrap();

    repo.update_task(
        DEFAULT_USER_ID,
        "t1",
        "tk1",
        &UpdateTaskParams {
            status: Some("in_progress".into()),
            ..Default::default()
        },
    )
    .await
    .unwrap();

    let updated = repo
        .find_task_by_id(DEFAULT_USER_ID, "t1", "tk1")
        .await
        .unwrap()
        .unwrap();
    assert_eq!(updated.status, "in_progress");
}

#[tokio::test]
async fn update_task_description_and_owner() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team("t1", "Team")).await.unwrap();

    let task = make_task("tk1", "t1", "Task");
    repo.create_task(DEFAULT_USER_ID, &task).await.unwrap();

    repo.update_task(
        DEFAULT_USER_ID,
        "t1",
        "tk1",
        &UpdateTaskParams {
            description: Some("New description".into()),
            owner: Some("agent-2".into()),
            ..Default::default()
        },
    )
    .await
    .unwrap();

    let updated = repo
        .find_task_by_id(DEFAULT_USER_ID, "t1", "tk1")
        .await
        .unwrap()
        .unwrap();
    assert_eq!(updated.description.as_deref(), Some("New description"));
    assert_eq!(updated.owner.as_deref(), Some("agent-2"));
}

#[tokio::test]
async fn update_nonexistent_task_returns_not_found() {
    let (repo, _db) = repo().await;
    let result = repo
        .update_task(
            DEFAULT_USER_ID,
            "t1",
            "nonexistent",
            &UpdateTaskParams {
                status: Some("completed".into()),
                ..Default::default()
            },
        )
        .await;
    assert!(matches!(result, Err(DbError::NotFound(_))));
}

#[tokio::test]
async fn append_to_blocks_and_remove_from_blocked_by() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team("t1", "Team")).await.unwrap();

    // Create taskA and taskB
    let task_a = make_task("tkA", "t1", "Task A");
    let mut task_b = make_task("tkB", "t1", "Task B");
    task_b.blocked_by = r#"["tkA"]"#.into();
    repo.create_task(DEFAULT_USER_ID, &task_a).await.unwrap();
    repo.create_task(DEFAULT_USER_ID, &task_b).await.unwrap();

    // Append tkB to taskA's blocks
    repo.append_to_blocks(DEFAULT_USER_ID, "t1", "tkA", "tkB")
        .await
        .unwrap();

    let a = repo
        .find_task_by_id(DEFAULT_USER_ID, "t1", "tkA")
        .await
        .unwrap()
        .unwrap();
    let blocks: Vec<String> = serde_json::from_str(&a.blocks).unwrap();
    assert!(blocks.contains(&"tkB".to_string()));

    // Now complete taskA: remove tkA from taskB's blocked_by
    repo.remove_from_blocked_by(DEFAULT_USER_ID, "t1", "tkB", "tkA")
        .await
        .unwrap();

    let b = repo
        .find_task_by_id(DEFAULT_USER_ID, "t1", "tkB")
        .await
        .unwrap()
        .unwrap();
    let blocked_by: Vec<String> = serde_json::from_str(&b.blocked_by).unwrap();
    assert!(!blocked_by.contains(&"tkA".to_string()));
}

#[tokio::test]
async fn append_to_blocks_idempotent() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team("t1", "Team")).await.unwrap();

    let task = make_task("tkA", "t1", "Task A");
    repo.create_task(DEFAULT_USER_ID, &task).await.unwrap();

    repo.append_to_blocks(DEFAULT_USER_ID, "t1", "tkA", "tkB")
        .await
        .unwrap();
    repo.append_to_blocks(DEFAULT_USER_ID, "t1", "tkA", "tkB")
        .await
        .unwrap();

    let a = repo
        .find_task_by_id(DEFAULT_USER_ID, "t1", "tkA")
        .await
        .unwrap()
        .unwrap();
    let blocks: Vec<String> = serde_json::from_str(&a.blocks).unwrap();
    assert_eq!(blocks.len(), 1); // no duplicates
}

#[tokio::test]
async fn multi_dependency_unblock() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team("t1", "Team")).await.unwrap();

    // taskA blocks taskB and taskC
    let task_a = make_task("tkA", "t1", "A");
    let mut task_b = make_task("tkB", "t1", "B");
    task_b.blocked_by = r#"["tkA"]"#.into();
    let mut task_c = make_task("tkC", "t1", "C");
    task_c.blocked_by = r#"["tkA"]"#.into();

    repo.create_task(DEFAULT_USER_ID, &task_a).await.unwrap();
    repo.create_task(DEFAULT_USER_ID, &task_b).await.unwrap();
    repo.create_task(DEFAULT_USER_ID, &task_c).await.unwrap();

    repo.append_to_blocks(DEFAULT_USER_ID, "t1", "tkA", "tkB")
        .await
        .unwrap();
    repo.append_to_blocks(DEFAULT_USER_ID, "t1", "tkA", "tkC")
        .await
        .unwrap();

    // Complete A: unblock both B and C
    repo.remove_from_blocked_by(DEFAULT_USER_ID, "t1", "tkB", "tkA")
        .await
        .unwrap();
    repo.remove_from_blocked_by(DEFAULT_USER_ID, "t1", "tkC", "tkA")
        .await
        .unwrap();

    let b = repo
        .find_task_by_id(DEFAULT_USER_ID, "t1", "tkB")
        .await
        .unwrap()
        .unwrap();
    let c = repo
        .find_task_by_id(DEFAULT_USER_ID, "t1", "tkC")
        .await
        .unwrap()
        .unwrap();
    let b_blocked: Vec<String> = serde_json::from_str(&b.blocked_by).unwrap();
    let c_blocked: Vec<String> = serde_json::from_str(&c.blocked_by).unwrap();
    assert!(b_blocked.is_empty());
    assert!(c_blocked.is_empty());
}

#[tokio::test]
async fn partial_unblock_preserves_other_blockers() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team("t1", "Team")).await.unwrap();

    // taskB is blocked by both tkA and tkX
    let task_a = make_task("tkA", "t1", "A");
    let mut task_b = make_task("tkB", "t1", "B");
    task_b.blocked_by = r#"["tkA","tkX"]"#.into();

    repo.create_task(DEFAULT_USER_ID, &task_a).await.unwrap();
    repo.create_task(DEFAULT_USER_ID, &task_b).await.unwrap();

    // Complete A only
    repo.remove_from_blocked_by(DEFAULT_USER_ID, "t1", "tkB", "tkA")
        .await
        .unwrap();

    let b = repo
        .find_task_by_id(DEFAULT_USER_ID, "t1", "tkB")
        .await
        .unwrap()
        .unwrap();
    let blocked_by: Vec<String> = serde_json::from_str(&b.blocked_by).unwrap();
    assert_eq!(blocked_by, vec!["tkX"]);
}

#[tokio::test]
async fn no_blocks_task_completes_cleanly() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team("t1", "Team")).await.unwrap();

    let task = make_task("tkA", "t1", "A");
    repo.create_task(DEFAULT_USER_ID, &task).await.unwrap();

    // Complete without any blocks to unblock
    repo.update_task(
        DEFAULT_USER_ID,
        "t1",
        "tkA",
        &UpdateTaskParams {
            status: Some("completed".into()),
            ..Default::default()
        },
    )
    .await
    .unwrap();

    let a = repo
        .find_task_by_id(DEFAULT_USER_ID, "t1", "tkA")
        .await
        .unwrap()
        .unwrap();
    assert_eq!(a.status, "completed");
    let blocks: Vec<String> = serde_json::from_str(&a.blocks).unwrap();
    assert!(blocks.is_empty());
}

#[tokio::test]
async fn delete_tasks_by_team() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team("t1", "Team1")).await.unwrap();
    repo.create_team(&make_team("t2", "Team2")).await.unwrap();

    repo.create_task(DEFAULT_USER_ID, &make_task("tk1", "t1", "T1 Task"))
        .await
        .unwrap();
    repo.create_task(DEFAULT_USER_ID, &make_task("tk2", "t2", "T2 Task"))
        .await
        .unwrap();

    repo.delete_tasks_by_team("system_default_user", "t1").await.unwrap();

    let t1_tasks = repo.list_tasks(DEFAULT_USER_ID, "t1").await.unwrap();
    assert!(t1_tasks.is_empty());

    let t2_tasks = repo.list_tasks(DEFAULT_USER_ID, "t2").await.unwrap();
    assert_eq!(t2_tasks.len(), 1);
}

#[tokio::test]
async fn scoped_task_updates_and_deletes_stay_within_team_owner() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team_for_user("t1", "user-a", "Team A"))
        .await
        .unwrap();
    repo.create_team(&make_team_for_user("t2", "user-b", "Team B"))
        .await
        .unwrap();
    repo.create_task("user-a", &make_task("tk1", "t1", "A Task"))
        .await
        .unwrap();
    repo.create_task("user-b", &make_task("tk2", "t2", "B Task"))
        .await
        .unwrap();

    let update = repo
        .update_task(
            "user-b",
            "t1",
            "tk1",
            &UpdateTaskParams {
                status: Some("completed".into()),
                ..Default::default()
            },
        )
        .await;
    assert!(matches!(update, Err(DbError::NotFound(_))));

    repo.delete_tasks_by_team("user-b", "t1").await.unwrap();
    assert_eq!(repo.list_tasks("user-a", "t1").await.unwrap().len(), 1);
    assert_eq!(repo.list_tasks("user-b", "t2").await.unwrap().len(), 1);
}

#[tokio::test]
async fn task_child_methods_do_not_cross_team_owner() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team_for_user("t1", "user-a", "Team A"))
        .await
        .unwrap();
    repo.create_task("user-a", &make_task("tk1", "t1", "A Task"))
        .await
        .unwrap();
    repo.create_task("user-a", &make_task("tk2", "t1", "B Task"))
        .await
        .unwrap();

    assert!(repo.list_tasks("user-b", "t1").await.unwrap().is_empty());
    assert!(repo.find_task_by_id("user-b", "t1", "tk1").await.unwrap().is_none());

    let wrong_update = repo
        .update_task(
            "user-b",
            "t1",
            "tk1",
            &UpdateTaskParams {
                status: Some("completed".into()),
                ..Default::default()
            },
        )
        .await;
    assert!(matches!(wrong_update, Err(DbError::NotFound(_))));

    let wrong_append = repo.append_to_blocks("user-b", "t1", "tk1", "tk2").await;
    assert!(matches!(wrong_append, Err(DbError::NotFound(_))));

    let wrong_remove = repo.remove_from_blocked_by("user-b", "t1", "tk2", "tk1").await;
    assert!(matches!(wrong_remove, Err(DbError::NotFound(_))));

    let wrong_create = repo
        .create_task("user-b", &make_task("tk3", "t1", "Wrong User Task"))
        .await;
    assert!(matches!(wrong_create, Err(DbError::NotFound(_))));
}

#[tokio::test]
async fn tasks_contain_dependency_info() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team("t1", "Team")).await.unwrap();

    let task_a = make_task("tkA", "t1", "A");
    let mut task_b = make_task("tkB", "t1", "B");
    task_b.blocked_by = r#"["tkA"]"#.into();

    repo.create_task(DEFAULT_USER_ID, &task_a).await.unwrap();
    repo.create_task(DEFAULT_USER_ID, &task_b).await.unwrap();
    repo.append_to_blocks(DEFAULT_USER_ID, "t1", "tkA", "tkB")
        .await
        .unwrap();

    let tasks = repo.list_tasks(DEFAULT_USER_ID, "t1").await.unwrap();
    assert_eq!(tasks.len(), 2);

    let a = tasks.iter().find(|t| t.id == "tkA").unwrap();
    let b = tasks.iter().find(|t| t.id == "tkB").unwrap();

    let a_blocks: Vec<String> = serde_json::from_str(&a.blocks).unwrap();
    assert!(a_blocks.contains(&"tkB".to_string()));

    let b_blocked_by: Vec<String> = serde_json::from_str(&b.blocked_by).unwrap();
    assert!(b_blocked_by.contains(&"tkA".to_string()));
}

// ── Data Consistency Tests ───────────────────────────────────────────

#[tokio::test]
async fn delete_team_cascades_mailbox_and_tasks() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team("t1", "Team")).await.unwrap();

    // Add mailbox messages and tasks
    let msg = make_mailbox_msg("m1", "t1", "a1", "a2", "message");
    repo.write_message(DEFAULT_USER_ID, &msg).await.unwrap();
    let task = make_task("tk1", "t1", "Task");
    repo.create_task(DEFAULT_USER_ID, &task).await.unwrap();

    // Delete team, then manually clean up related data (as service layer would)
    repo.delete_mailbox_by_team("system_default_user", "t1").await.unwrap();
    repo.delete_tasks_by_team("system_default_user", "t1").await.unwrap();
    repo.delete_team("system_default_user", "t1").await.unwrap();

    // Verify all cleaned up
    let team = repo.get_team("system_default_user", "t1").await.unwrap();
    assert!(team.is_none());
    let mail = repo.get_history(DEFAULT_USER_ID, "t1", "a1", None).await.unwrap();
    assert!(mail.is_empty());
    let tasks = repo.list_tasks(DEFAULT_USER_ID, "t1").await.unwrap();
    assert!(tasks.is_empty());
}

#[tokio::test]
async fn task_blocked_by_blocks_bidirectional_consistency() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team("t1", "Team")).await.unwrap();

    let task_a = make_task("tkA", "t1", "A");
    let mut task_b = make_task("tkB", "t1", "B");
    task_b.blocked_by = r#"["tkA"]"#.into();

    repo.create_task(DEFAULT_USER_ID, &task_a).await.unwrap();
    repo.create_task(DEFAULT_USER_ID, &task_b).await.unwrap();
    repo.append_to_blocks(DEFAULT_USER_ID, "t1", "tkA", "tkB")
        .await
        .unwrap();

    // Verify bidirectional link
    let a = repo
        .find_task_by_id(DEFAULT_USER_ID, "t1", "tkA")
        .await
        .unwrap()
        .unwrap();
    let b = repo
        .find_task_by_id(DEFAULT_USER_ID, "t1", "tkB")
        .await
        .unwrap()
        .unwrap();

    let a_blocks: Vec<String> = serde_json::from_str(&a.blocks).unwrap();
    let b_blocked_by: Vec<String> = serde_json::from_str(&b.blocked_by).unwrap();

    assert!(a_blocks.contains(&"tkB".to_string()), "A.blocks should contain B");
    assert!(
        b_blocked_by.contains(&"tkA".to_string()),
        "B.blockedBy should contain A"
    );
}

// ── Activity feed keyset pagination (messages) ───────────────────────

#[tokio::test]
async fn paged_messages_desc_walks_older_with_stable_tiebreak() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team("t1", "Team")).await.unwrap();
    // 5 messages, incl. a pair sharing created_at to verify the id tiebreak.
    for (id, ts) in [("m1", 1000), ("m2", 2000), ("m3", 3000), ("m4", 3000), ("m5", 4000)] {
        let mut msg = make_mailbox_msg(id, "t1", "a1", "lead", "message");
        msg.created_at = ts;
        repo.write_message(DEFAULT_USER_ID, &msg).await.unwrap();
    }

    // First page desc, limit 2 -> newest two: m5(4000), m4(3000,id"m4").
    let page1 = repo
        .list_messages_by_team_paged("t1", None, PageDirection::Desc, 2)
        .await
        .unwrap();
    assert_eq!(page1.iter().map(|r| r.id.as_str()).collect::<Vec<_>>(), ["m5", "m4"]);

    // Next-page cursor = m4(3000,"m4"); same created_at m3 is caught via id<"m4".
    let cursor = ActivityCursor {
        created_at: 3000,
        id: "m4".into(),
    };
    let page2 = repo
        .list_messages_by_team_paged("t1", Some(cursor), PageDirection::Desc, 2)
        .await
        .unwrap();
    assert_eq!(page2.iter().map(|r| r.id.as_str()).collect::<Vec<_>>(), ["m3", "m2"]);
}

#[tokio::test]
async fn paged_messages_asc_walks_newer_from_oldest() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team("t1", "Team")).await.unwrap();
    for (id, ts) in [("m1", 1000), ("m2", 2000), ("m3", 3000)] {
        let mut msg = make_mailbox_msg(id, "t1", "a1", "lead", "message");
        msg.created_at = ts;
        repo.write_message(DEFAULT_USER_ID, &msg).await.unwrap();
    }
    let page1 = repo
        .list_messages_by_team_paged("t1", None, PageDirection::Asc, 2)
        .await
        .unwrap();
    assert_eq!(page1.iter().map(|r| r.id.as_str()).collect::<Vec<_>>(), ["m1", "m2"]);

    let cursor = ActivityCursor {
        created_at: 2000,
        id: "m2".into(),
    };
    let page2 = repo
        .list_messages_by_team_paged("t1", Some(cursor), PageDirection::Asc, 2)
        .await
        .unwrap();
    assert_eq!(page2.iter().map(|r| r.id.as_str()).collect::<Vec<_>>(), ["m3"]);
}

// ── Activity feed keyset pagination (tasks) ──────────────────────────

#[tokio::test]
async fn paged_tasks_desc_and_cursor() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team("t1", "Team")).await.unwrap();
    for (id, ts) in [("k1", 1000), ("k2", 2000), ("k3", 3000)] {
        let mut task = make_task(id, "t1", "subject");
        task.created_at = ts;
        repo.create_task(DEFAULT_USER_ID, &task).await.unwrap();
    }
    let page1 = repo
        .list_tasks_paged(DEFAULT_USER_ID, "t1", None, PageDirection::Desc, 2)
        .await
        .unwrap();
    assert_eq!(page1.iter().map(|r| r.id.as_str()).collect::<Vec<_>>(), ["k3", "k2"]);

    let cursor = ActivityCursor {
        created_at: 2000,
        id: "k2".into(),
    };
    let page2 = repo
        .list_tasks_paged(DEFAULT_USER_ID, "t1", Some(cursor), PageDirection::Desc, 2)
        .await
        .unwrap();
    assert_eq!(page2.iter().map(|r| r.id.as_str()).collect::<Vec<_>>(), ["k1"]);
}

#[tokio::test]
async fn paged_tasks_rejects_cross_user() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team_for_user("t1", "user-a", "Team A"))
        .await
        .unwrap();
    let mut task = make_task("k1", "t1", "subject");
    task.created_at = 1000;
    repo.create_task("user-a", &task).await.unwrap();
    // Another user cannot see it.
    let rows = repo
        .list_tasks_paged("user-b", "t1", None, PageDirection::Desc, 10)
        .await
        .unwrap();
    assert!(rows.is_empty());
}

// ── list_tasks_by_ids ────────────────────────────────────────────────

#[tokio::test]
async fn list_tasks_by_ids_returns_only_requested() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team("t1", "Team")).await.unwrap();
    repo.create_task(DEFAULT_USER_ID, &make_task("k1", "t1", "A"))
        .await
        .unwrap();
    repo.create_task(DEFAULT_USER_ID, &make_task("k2", "t1", "B"))
        .await
        .unwrap();
    repo.create_task(DEFAULT_USER_ID, &make_task("k3", "t1", "C"))
        .await
        .unwrap();

    let rows = repo
        .list_tasks_by_ids(DEFAULT_USER_ID, "t1", &["k1".into(), "k3".into()])
        .await
        .unwrap();

    let mut got: Vec<String> = rows.iter().map(|r| r.id.clone()).collect();
    got.sort();
    assert_eq!(got, vec!["k1".to_string(), "k3".to_string()]);
}

#[tokio::test]
async fn list_tasks_by_ids_empty_and_unknown_return_empty() {
    let (repo, _db) = repo().await;
    repo.create_team(&make_team("t1", "Team")).await.unwrap();
    repo.create_task(DEFAULT_USER_ID, &make_task("k1", "t1", "A"))
        .await
        .unwrap();

    // Empty slice must not query and yields nothing.
    assert!(
        repo.list_tasks_by_ids(DEFAULT_USER_ID, "t1", &[])
            .await
            .unwrap()
            .is_empty()
    );
    // Unknown ids are silently ignored, not an error.
    let rows = repo
        .list_tasks_by_ids(DEFAULT_USER_ID, "t1", &["nope".into()])
        .await
        .unwrap();
    assert!(rows.is_empty());
}

#[tokio::test]
async fn list_tasks_by_ids_enforces_owner_isolation() {
    let (repo, _db) = repo().await;
    // Team owned by user A, with a task.
    repo.create_team(&make_team_for_user("t1", "user-a", "A team"))
        .await
        .unwrap();
    repo.create_task("user-a", &make_task("k1", "t1", "secret"))
        .await
        .unwrap();

    // User B asks for the same team/id -> nothing leaks.
    let rows = repo.list_tasks_by_ids("user-b", "t1", &["k1".into()]).await.unwrap();
    assert!(rows.is_empty());
}
