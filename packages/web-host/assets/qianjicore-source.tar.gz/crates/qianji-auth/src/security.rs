use axum::extract::Request;
use axum::http::header::{
    CONTENT_SECURITY_POLICY, HeaderValue, REFERRER_POLICY, X_CONTENT_TYPE_OPTIONS, X_FRAME_OPTIONS, X_XSS_PROTECTION,
};
use axum::middleware::Next;
use axum::response::Response;

fn allows_embedding(path: &str) -> bool {
    let mut segments = path.trim_start_matches('/').split('/');
    matches!(
        (segments.next(), segments.next(), segments.next(), segments.next(),),
        (Some("api"), Some("extensions"), Some(_extension_name), Some("assets"))
    )
}

/// Office preview proxies serve content loaded in same-origin iframes by
/// the web UI; `DENY` here blanks the preview (iOfficeAI/Qianji#3177).
fn allows_same_origin_embedding(path: &str) -> bool {
    path.starts_with("/api/ppt-proxy/") || path.starts_with("/api/office-watch-proxy/")
}

/// Middleware that adds security response headers to every response.
///
/// Headers set:
/// - `X-Frame-Options: DENY` — prevent clickjacking on non-embeddable routes
///   (`SAMEORIGIN` + `frame-ancestors 'self'` on office preview proxies)
/// - `X-Content-Type-Options: nosniff` — prevent MIME sniffing
/// - `X-XSS-Protection: 1; mode=block` — enable XSS filter
/// - `Referrer-Policy: strict-origin-when-cross-origin` — limit referrer leakage
pub async fn security_headers_middleware(request: Request, next: Next) -> Response {
    let path = request.uri().path().to_string();
    let mut response = next.run(request).await;
    let headers = response.headers_mut();

    if allows_same_origin_embedding(&path) {
        headers.insert(X_FRAME_OPTIONS, HeaderValue::from_static("SAMEORIGIN"));
        // Append rather than insert: CSP allows multiple policies and all
        // are enforced, so an upstream policy is never silently dropped.
        headers.append(
            CONTENT_SECURITY_POLICY,
            HeaderValue::from_static("frame-ancestors 'self'"),
        );
    } else if !allows_embedding(&path) {
        headers.insert(X_FRAME_OPTIONS, HeaderValue::from_static("DENY"));
    }
    headers.insert(X_CONTENT_TYPE_OPTIONS, HeaderValue::from_static("nosniff"));
    headers.insert(X_XSS_PROTECTION, HeaderValue::from_static("1; mode=block"));
    headers.insert(
        REFERRER_POLICY,
        HeaderValue::from_static("strict-origin-when-cross-origin"),
    );

    response
}

#[cfg(test)]
mod tests {
    use super::*;
    use axum::body::Body;
    use axum::routing::get;
    use axum::{Router, middleware};
    use tower::ServiceExt;

    #[tokio::test]
    async fn all_security_headers_present() {
        let app = Router::new()
            .route("/test", get(|| async { "ok" }))
            .layer(middleware::from_fn(security_headers_middleware));

        let response = app
            .oneshot(axum::http::Request::builder().uri("/test").body(Body::empty()).unwrap())
            .await
            .unwrap();

        assert_eq!(response.headers().get("x-frame-options").unwrap(), "DENY");
        assert_eq!(response.headers().get("x-content-type-options").unwrap(), "nosniff");
        assert_eq!(response.headers().get("x-xss-protection").unwrap(), "1; mode=block");
        assert_eq!(
            response.headers().get("referrer-policy").unwrap(),
            "strict-origin-when-cross-origin"
        );
    }

    #[tokio::test]
    async fn security_headers_on_error_responses() {
        let app = Router::new()
            .route(
                "/error",
                get(|| async { axum::http::StatusCode::INTERNAL_SERVER_ERROR }),
            )
            .layer(middleware::from_fn(security_headers_middleware));

        let response = app
            .oneshot(
                axum::http::Request::builder()
                    .uri("/error")
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();

        assert_eq!(response.status(), axum::http::StatusCode::INTERNAL_SERVER_ERROR);
        // Security headers still present even on error responses
        assert_eq!(response.headers().get("x-frame-options").unwrap(), "DENY");
    }

    #[tokio::test]
    async fn office_proxy_routes_get_sameorigin_frame_headers() {
        // Regression for iOfficeAI/Qianji#3177: the office preview proxies
        // serve iframe content for the same-origin web UI; `DENY` blanks
        // the preview iframe in browsers.
        let app = Router::new()
            .route("/api/ppt-proxy/{port}", get(|| async { "ok" }))
            .route("/api/office-watch-proxy/{port}/{*path}", get(|| async { "ok" }))
            .layer(middleware::from_fn(security_headers_middleware));

        for uri in ["/api/ppt-proxy/41307", "/api/office-watch-proxy/41307/some/page"] {
            let response = app
                .clone()
                .oneshot(axum::http::Request::builder().uri(uri).body(Body::empty()).unwrap())
                .await
                .unwrap();

            assert_eq!(
                response.headers().get("x-frame-options").unwrap(),
                "SAMEORIGIN",
                "{uri} must stay frameable by the same-origin web UI"
            );
            assert_eq!(
                response.headers().get("content-security-policy").unwrap(),
                "frame-ancestors 'self'",
                "{uri} should carry the modern frame-ancestors policy"
            );
            assert_eq!(response.headers().get("x-content-type-options").unwrap(), "nosniff");
        }
    }

    #[tokio::test]
    async fn extension_asset_routes_omit_frame_deny_header() {
        let app = Router::new()
            .route(
                "/api/extensions/hello/assets/settings/index.html",
                get(|| async { "ok" }),
            )
            .layer(middleware::from_fn(security_headers_middleware));

        let response = app
            .oneshot(
                axum::http::Request::builder()
                    .uri("/api/extensions/hello/assets/settings/index.html")
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();

        assert!(response.headers().get("x-frame-options").is_none());
        assert_eq!(response.headers().get("x-content-type-options").unwrap(), "nosniff");
    }
}
