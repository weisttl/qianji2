use std::sync::Arc;

use qianji_ai_agent::{AgentError, IWorkerTaskManager};
use qianji_api_types::{
    CloneConversationRequest, CreateConversationRequest, ListMessagesQuery, SearchMessagesQuery, WebSocketMessage,
};
use qianji_common::{AgentKillReason, ConversationStatus, TimestampMs, generate_prefixed_id, now_ms};
use qianji_conversation::skill_resolver::SkillResolver;
use qianji_conversation::{ConversationError, ConversationService};
use qianji_db::models::MessageRow;
use qianji_db::{IConversationRepository, SqliteConversationRepository, init_database_memory};
use qianji_realtime::EventBroadcaster;
use serde_json::json;
use std::sync::Mutex;

// ── Test infrastructure ────────────────────────────────────────────

struct TestBroadcaster {
    events: Mutex<Vec<WebSocketMessage<serde_json::Value>>>,
}

impl TestBroadcaster {
    fn new() -> Self {
        Self {
            events: Mutex::new(vec![]),
        }
    }
}

impl EventBroadcaster for TestBroadcaster {
    fn broadcast(&self, event: WebSocketMessage<serde_json::Value>) {
        self.events.lock().unwrap().push(event);
    }
}

struct NoopTaskManager;

#[async_trait::async_trait]
impl IWorkerTaskManager for NoopTaskManager {
    fn get_task(&self, _: &str) -> Option<qianji_ai_agent::AgentInstance> {
        None
    }
    async fn get_or_build_task(
        &self,
        _: &str,
        _: qianji_ai_agent::types::BuildTaskOptions,
    ) -> Result<qianji_ai_agent::AgentInstance, AgentError> {
        Err(AgentError::internal("noop"))
    }
    fn kill(&self, _: &str, _: Option<AgentKillReason>) -> Result<(), AgentError> {
        Ok(())
    }
    fn kill_and_wait(
        &self,
        _: &str,
        _: Option<AgentKillReason>,
    ) -> std::pin::Pin<Box<dyn std::future::Future<Output = ()> + Send>> {
        Box::pin(std::future::ready(()))
    }
    async fn clear(&self) {}
    fn active_count(&self) -> usize {
        0
    }
    fn collect_idle(&self, _: TimestampMs) -> Vec<String> {
        vec![]
    }
}

struct EmptySkillResolver;

#[async_trait::async_trait]
impl SkillResolver for EmptySkillResolver {
    async fn auto_inject_names(&self) -> Vec<String> {
        Vec::new()
    }

    async fn resolve_skills(&self, _names: &[String]) -> Vec<qianji_extension::ResolvedAgentSkill> {
        Vec::new()
    }
}

async fn setup() -> (
    ConversationService,
    Arc<SqliteConversationRepository>,
    Arc<TestBroadcaster>,
) {
    let db = init_database_memory().await.unwrap();
    let repo = Arc::new(SqliteConversationRepository::new(db.pool().clone()));
    let broadcaster = Arc::new(TestBroadcaster::new());
    let agent_metadata_repo: Arc<dyn qianji_db::IAgentMetadataRepository> =
        Arc::new(qianji_db::SqliteAgentMetadataRepository::new(db.pool().clone()));
    let acp_session_repo: Arc<dyn qianji_db::IAcpSessionRepository> =
        Arc::new(qianji_db::SqliteAcpSessionRepository::new(db.pool().clone()));
    let task_mgr: Arc<dyn IWorkerTaskManager> = Arc::new(NoopTaskManager);
    let svc = ConversationService::new(
        std::env::temp_dir(),
        broadcaster.clone(),
        Arc::new(EmptySkillResolver),
        task_mgr,
        repo.clone(),
        agent_metadata_repo,
        acp_session_repo,
    );
    (svc, repo, broadcaster)
}

const USER_ID: &str = "system_default_user";

fn ensure_test_workspace_path() -> String {
    ensure_named_workspace_path("qianji-conversation-extended-test-project")
}

fn ensure_named_workspace_path(name: &str) -> String {
    let workspace = std::env::temp_dir().join(name);
    std::fs::create_dir_all(&workspace).unwrap();
    workspace.to_string_lossy().to_string()
}

fn make_create_req() -> CreateConversationRequest {
    let workspace = ensure_test_workspace_path();
    serde_json::from_value(json!({
        "type": "acp",
        "extra": { "workspace": workspace }
    }))
    .unwrap()
}

fn make_message(conv_id: &str, content: &str, offset_ms: i64) -> MessageRow {
    MessageRow {
        id: generate_prefixed_id("msg"),
        conversation_id: conv_id.to_string(),
        msg_id: Some(generate_prefixed_id("client")),
        r#type: "text".to_string(),
        content: format!(r#"{{"content":"{content}"}}"#),
        position: Some("right".to_string()),
        status: Some("finish".to_string()),
        hidden: false,
        created_at: now_ms() + offset_ms,
        backend_turn_id: None,
    }
}

fn make_acp_tool_message(conv_id: &str, id: &str, output: &str, offset_ms: i64) -> MessageRow {
    MessageRow {
        id: id.to_string(),
        conversation_id: conv_id.to_string(),
        msg_id: Some(id.to_string()),
        r#type: "acp_tool_call".to_string(),
        content: json!({
            "session_id": "session-1",
            "update": {
                "session_update": "tool_call",
                "tool_call_id": id,
                "status": "completed",
                "title": "rg",
                "kind": "search",
                "raw_input": { "pattern": "needle", "path": "." },
                "content": [{
                    "type": "content",
                    "content": { "type": "text", "text": output }
                }]
            }
        })
        .to_string(),
        position: Some("left".to_string()),
        status: Some("finish".to_string()),
        hidden: false,
        created_at: now_ms() + offset_ms,
        backend_turn_id: None,
    }
}

// ── T6: Clone conversation ─────────────────────────────────────────

#[tokio::test]
async fn t6_2_clone_without_source() {
    let (svc, _repo, _b) = setup().await;

    let req: CloneConversationRequest = serde_json::from_value(json!({
        "conversation": {
            "type": "acp",
            "name": "Direct",
            "extra": {}
        }
    }))
    .unwrap();
    let resp = svc.clone_create(USER_ID, req).await.unwrap();
    assert_eq!(resp.name, "Direct");
    // No source to merge from — only the caller-provided CreateConversationRequest
    // drives `extra`, so source-only keys (e.g. `contextFileName`) must not appear.
    assert!(resp.extra.get("contextFileName").is_none());
}

// ── T7: Reset conversation ─────────────────────────────────────────

#[tokio::test]
async fn t7_1_reset_clears_messages_and_status() {
    let (svc, repo, _b) = setup().await;

    let conv = svc.create(USER_ID, make_create_req()).await.unwrap();
    // Insert messages
    for i in 0..3 {
        repo.insert_message(USER_ID, &make_message(&conv.id, &format!("msg {i}"), i))
            .await
            .unwrap();
    }

    svc.reset(USER_ID, &conv.id).await.unwrap();

    let fetched = svc.get(USER_ID, &conv.id).await.unwrap();
    assert_eq!(fetched.status, ConversationStatus::Pending);

    let messages = svc
        .list_messages(USER_ID, &conv.id, ListMessagesQuery::default())
        .await
        .unwrap();
    assert!(messages.items.is_empty());
    assert!(messages.oldest_cursor.is_none());
    assert!(messages.newest_cursor.is_none());
    assert!(!messages.has_more_before);
    assert!(!messages.has_more_after);
}

#[tokio::test]
async fn t7_3_reset_not_found() {
    let (svc, _repo, _b) = setup().await;
    let err = svc.reset(USER_ID, "nonexistent").await.unwrap_err();
    assert!(matches!(err, ConversationError::NotFound { .. }));
}

// ── T8: Message list ───────────────────────────────────────────────

#[tokio::test]
async fn t8_1_empty_messages() {
    let (svc, _repo, _b) = setup().await;
    let conv = svc.create(USER_ID, make_create_req()).await.unwrap();

    let result = svc
        .list_messages(USER_ID, &conv.id, ListMessagesQuery::default())
        .await
        .unwrap();
    assert!(result.items.is_empty());
    assert!(result.oldest_cursor.is_none());
    assert!(result.newest_cursor.is_none());
    assert!(!result.has_more_before);
    assert!(!result.has_more_after);
}

#[tokio::test]
async fn t8_2_cursor_pagination() {
    let (svc, repo, _b) = setup().await;
    let conv = svc.create(USER_ID, make_create_req()).await.unwrap();

    for i in 0..10 {
        repo.insert_message(USER_ID, &make_message(&conv.id, &format!("msg {i}"), i * 100))
            .await
            .unwrap();
    }

    let query = ListMessagesQuery {
        limit: Some(3),
        content_mode: None,
        ..Default::default()
    };
    let result = svc.list_messages(USER_ID, &conv.id, query).await.unwrap();
    assert_eq!(result.items.len(), 3);
    assert!(result.oldest_cursor.is_some());
    assert!(result.newest_cursor.is_some());
    assert!(result.has_more_before);
    assert!(!result.has_more_after);

    let older = svc
        .list_messages(
            USER_ID,
            &conv.id,
            ListMessagesQuery {
                limit: Some(3),
                before: result.oldest_cursor.clone(),
                ..Default::default()
            },
        )
        .await
        .unwrap();
    assert_eq!(older.items.len(), 3);
    assert!(older.has_more_before);
    assert!(older.has_more_after);
}

#[tokio::test]
async fn t8_3_asc_order_default() {
    let (svc, repo, _b) = setup().await;
    let conv = svc.create(USER_ID, make_create_req()).await.unwrap();

    for i in 0..3 {
        repo.insert_message(USER_ID, &make_message(&conv.id, &format!("msg {i}"), i * 1000))
            .await
            .unwrap();
    }

    let result = svc
        .list_messages(USER_ID, &conv.id, ListMessagesQuery::default())
        .await
        .unwrap();
    // Latest page is returned in ascending display order.
    assert!(result.items[0].created_at <= result.items[1].created_at);
    assert!(result.items[1].created_at <= result.items[2].created_at);
}

#[tokio::test]
async fn t8_4_asc_order() {
    let (svc, repo, _b) = setup().await;
    let conv = svc.create(USER_ID, make_create_req()).await.unwrap();

    for i in 0..3 {
        repo.insert_message(USER_ID, &make_message(&conv.id, &format!("msg {i}"), i * 1000))
            .await
            .unwrap();
    }

    let result = svc
        .list_messages(USER_ID, &conv.id, ListMessagesQuery::default())
        .await
        .unwrap();
    assert!(result.items[0].created_at <= result.items[1].created_at);
    assert!(result.items[1].created_at <= result.items[2].created_at);
}

#[tokio::test]
async fn t8_5_conversation_not_found() {
    let (svc, _repo, _b) = setup().await;
    let err = svc
        .list_messages(USER_ID, "nonexistent", ListMessagesQuery::default())
        .await
        .unwrap_err();
    assert!(matches!(err, ConversationError::NotFound { .. }));
}

#[tokio::test]
async fn t8_6_rejects_before_and_after_together() {
    let (svc, _repo, _b) = setup().await;
    let conv = svc.create(USER_ID, make_create_req()).await.unwrap();

    let err = svc
        .list_messages(
            USER_ID,
            &conv.id,
            ListMessagesQuery {
                before: Some("v1.bad".into()),
                after: Some("v1.bad".into()),
                ..Default::default()
            },
        )
        .await
        .unwrap_err();

    assert!(
        matches!(err, ConversationError::BadRequest { reason } if reason == "before, after, and anchor_message_id are mutually exclusive")
    );
}

#[tokio::test]
async fn t8_7_rejects_anchor_with_cursor() {
    let (svc, _repo, _b) = setup().await;
    let conv = svc.create(USER_ID, make_create_req()).await.unwrap();

    let err = svc
        .list_messages(
            USER_ID,
            &conv.id,
            ListMessagesQuery {
                before: Some("v1.bad".into()),
                anchor_message_id: Some("msg-1".into()),
                ..Default::default()
            },
        )
        .await
        .unwrap_err();

    assert!(
        matches!(err, ConversationError::BadRequest { reason } if reason == "before, after, and anchor_message_id are mutually exclusive")
    );
}

#[tokio::test]
async fn t8_8_rejects_invalid_cursor() {
    let (svc, _repo, _b) = setup().await;
    let conv = svc.create(USER_ID, make_create_req()).await.unwrap();

    let err = svc
        .list_messages(
            USER_ID,
            &conv.id,
            ListMessagesQuery {
                before: Some("not-a-cursor".into()),
                ..Default::default()
            },
        )
        .await
        .unwrap_err();

    assert!(matches!(err, ConversationError::BadRequest { reason } if reason == "invalid message cursor"));
}

#[tokio::test]
async fn t8_9_anchor_returns_window_containing_target() {
    let (svc, repo, _b) = setup().await;
    let conv = svc.create(USER_ID, make_create_req()).await.unwrap();
    let mut target_id = String::new();

    for i in 0..7 {
        let msg = make_message(&conv.id, &format!("msg {i}"), i * 100);
        if i == 3 {
            target_id = msg.id.clone();
        }
        repo.insert_message(USER_ID, &msg).await.unwrap();
    }

    let page = svc
        .list_messages(
            USER_ID,
            &conv.id,
            ListMessagesQuery {
                limit: Some(5),
                anchor_message_id: Some(target_id.clone()),
                ..Default::default()
            },
        )
        .await
        .unwrap();

    assert_eq!(page.items.len(), 5);
    assert!(page.items.iter().any(|item| item.id == target_id));
    assert!(page.has_more_before);
    assert!(page.has_more_after);
}

// ── T9: Message search ─────────────────────────────────────────────

#[tokio::test]
async fn t8_6_compact_mode_truncates_large_tool_content_only_for_list_response() {
    let (svc, repo, _b) = setup().await;
    let conv = svc.create(USER_ID, make_create_req()).await.unwrap();
    let large_output = "match line\n".repeat(10_000);

    repo.insert_message(USER_ID, &make_acp_tool_message(&conv.id, "tool-big", &large_output, 0))
        .await
        .unwrap();

    let full = svc
        .list_messages(USER_ID, &conv.id, ListMessagesQuery::default())
        .await
        .unwrap();
    assert_eq!(
        full.items[0].content["update"]["content"][0]["content"]["text"]
            .as_str()
            .unwrap(),
        large_output
    );

    let compact = svc
        .list_messages(
            USER_ID,
            &conv.id,
            ListMessagesQuery {
                content_mode: Some("compact".into()),
                ..Default::default()
            },
        )
        .await
        .unwrap();
    let compact_content = &compact.items[0].content;
    let preview = compact_content["update"]["content"][0]["content"]["text"]
        .as_str()
        .unwrap();

    assert!(compact_content["_compact"]["truncated"].as_bool().unwrap());
    assert!(compact_content["_compact"]["original_size"].as_u64().unwrap() > preview.len() as u64);
    assert!(preview.len() < large_output.len());
    assert!(!preview.contains(&large_output));
}

#[tokio::test]
async fn t8_7_get_message_returns_full_tool_content_after_compact_list() {
    let (svc, repo, _b) = setup().await;
    let conv = svc.create(USER_ID, make_create_req()).await.unwrap();
    let large_output = "wide rg output\n".repeat(10_000);

    repo.insert_message(
        USER_ID,
        &make_acp_tool_message(&conv.id, "tool-detail", &large_output, 0),
    )
    .await
    .unwrap();

    let _ = svc
        .list_messages(
            USER_ID,
            &conv.id,
            ListMessagesQuery {
                content_mode: Some("compact".into()),
                ..Default::default()
            },
        )
        .await
        .unwrap();

    let detail = svc.get_message(USER_ID, &conv.id, "tool-detail").await.unwrap();

    assert_eq!(
        detail.content["update"]["content"][0]["content"]["text"]
            .as_str()
            .unwrap(),
        large_output
    );
}

#[tokio::test]
async fn t8_8_get_message_not_found() {
    let (svc, _repo, _b) = setup().await;
    let conv = svc.create(USER_ID, make_create_req()).await.unwrap();

    let err = svc.get_message(USER_ID, &conv.id, "missing-message").await.unwrap_err();

    assert!(matches!(
        err,
        ConversationError::MessageNotFound { id } if id == "missing-message"
    ));
}

#[tokio::test]
async fn t9_1_keyword_match() {
    let (svc, repo, _b) = setup().await;
    let workspace = ensure_test_workspace_path();
    let conv = svc.create(USER_ID, make_create_req()).await.unwrap();

    repo.insert_message(USER_ID, &make_message(&conv.id, "Rust review report", 0))
        .await
        .unwrap();
    repo.insert_message(USER_ID, &make_message(&conv.id, "Python test", 100))
        .await
        .unwrap();

    let query = SearchMessagesQuery {
        keyword: "review".into(),
        page: None,
        page_size: None,
    };
    let result = svc.search_messages(USER_ID, query).await.unwrap();
    assert_eq!(result.items.len(), 1);
    assert_eq!(result.total, 1);

    let item = &result.items[0];
    assert_eq!(item.message_type, "text");
    assert!(item.message_created_at > 0);
    assert!(item.preview_text.contains("Rust review report"));

    assert_eq!(item.conversation.id, conv.id);
    assert_eq!(item.conversation.name, conv.name);
    assert_eq!(item.conversation.extra["workspace"], workspace);
}

#[tokio::test]
async fn t9_2_no_match() {
    let (svc, repo, _b) = setup().await;
    let conv = svc.create(USER_ID, make_create_req()).await.unwrap();
    repo.insert_message(USER_ID, &make_message(&conv.id, "hello world", 0))
        .await
        .unwrap();

    let query = SearchMessagesQuery {
        keyword: "xxxxnotexist".into(),
        page: None,
        page_size: None,
    };
    let result = svc.search_messages(USER_ID, query).await.unwrap();
    assert!(result.items.is_empty());
    assert_eq!(result.total, 0);
}

#[tokio::test]
async fn t9_3_search_pagination() {
    let (svc, repo, _b) = setup().await;
    let conv = svc.create(USER_ID, make_create_req()).await.unwrap();

    for i in 0..5 {
        repo.insert_message(
            USER_ID,
            &make_message(&conv.id, &format!("match keyword item {i}"), i * 100),
        )
        .await
        .unwrap();
    }

    let query = SearchMessagesQuery {
        keyword: "keyword".into(),
        page: Some(1),
        page_size: Some(2),
    };
    let result = svc.search_messages(USER_ID, query).await.unwrap();
    assert_eq!(result.items.len(), 2);
    assert_eq!(result.total, 5);
    assert!(result.has_more);
}

#[tokio::test]
async fn t9_4_empty_keyword() {
    let (svc, _repo, _b) = setup().await;

    let query = SearchMessagesQuery {
        keyword: "".into(),
        page: None,
        page_size: None,
    };
    let err = svc.search_messages(USER_ID, query).await.unwrap_err();
    assert!(matches!(err, ConversationError::BadRequest { .. }));
}

#[tokio::test]
async fn t9_5_preview_text_extracts_from_json_content() {
    let (svc, repo, _b) = setup().await;
    let conv = svc.create(USER_ID, make_create_req()).await.unwrap();

    let complex_msg = MessageRow {
        id: generate_prefixed_id("msg"),
        conversation_id: conv.id.clone(),
        msg_id: None,
        r#type: "text".to_string(),
        content: r#"[{"type":"text","content":"Design document for search"},{"type":"text","content":"feature implementation"}]"#.to_string(),
        position: Some("right".to_string()),
        status: Some("finish".to_string()),
        hidden: false,
        created_at: now_ms(),
        backend_turn_id: None,
    };
    repo.insert_message(USER_ID, &complex_msg).await.unwrap();

    let query = SearchMessagesQuery {
        keyword: "search".into(),
        page: None,
        page_size: None,
    };
    let result = svc.search_messages(USER_ID, query).await.unwrap();
    assert_eq!(result.items.len(), 1);

    let item = &result.items[0];
    assert!(!item.preview_text.contains('{'));
    assert!(!item.preview_text.contains('['));
    assert!(item.preview_text.contains("Design document for search"));
    assert!(item.preview_text.contains("feature implementation"));
}

#[tokio::test]
async fn t9_6_search_result_includes_conversation_model() {
    let (svc, repo, _b) = setup().await;
    let workspace = ensure_test_workspace_path();

    // Search surfaces conversation.model only for qianjirs (the only type that
    // carries a top-level model under the qianjirs-only rule).
    let qianjirs_req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "qianjirs",
        "model": { "provider_id": "p1", "model": "claude-sonnet-4-20250514" },
        "extra": { "workspace": workspace }
    }))
    .unwrap();
    let conv = svc.create(USER_ID, qianjirs_req).await.unwrap();

    repo.insert_message(USER_ID, &make_message(&conv.id, "model test keyword", 0))
        .await
        .unwrap();

    let query = SearchMessagesQuery {
        keyword: "model test".into(),
        page: None,
        page_size: None,
    };
    let result = svc.search_messages(USER_ID, query).await.unwrap();
    assert_eq!(result.items.len(), 1);

    let item = &result.items[0];
    let model = item.conversation.model.as_ref().unwrap();
    assert_eq!(model.provider_id, "p1");
    assert_eq!(model.model, "claude-sonnet-4-20250514");
}

#[tokio::test]
async fn t9_7_search_does_not_leak_other_users_messages() {
    let (svc, repo, _b) = setup().await;

    let conv = svc.create(USER_ID, make_create_req()).await.unwrap();
    repo.insert_message(USER_ID, &make_message(&conv.id, "secret keyword data", 0))
        .await
        .unwrap();

    let query = SearchMessagesQuery {
        keyword: "secret".into(),
        page: None,
        page_size: None,
    };
    let result = svc.search_messages("other_user_id", query).await.unwrap();
    assert!(result.items.is_empty());
    assert_eq!(result.total, 0);
}

// ── T10: Associated conversations ──────────────────────────────────

#[tokio::test]
async fn t10_1_same_workspace() {
    let (svc, _repo, _b) = setup().await;
    let shared_workspace = ensure_named_workspace_path("qianji-conversation-extended-shared-workspace");
    let other_workspace = ensure_named_workspace_path("qianji-conversation-extended-other-workspace");

    let req1: CreateConversationRequest = serde_json::from_value(json!({
        "type": "acp",
        "name": "Conv A",
        "extra": { "workspace": shared_workspace }
    }))
    .unwrap();
    let conv1 = svc.create(USER_ID, req1).await.unwrap();

    let req2: CreateConversationRequest = serde_json::from_value(json!({
        "type": "acp",
        "name": "Conv B",
        "extra": { "workspace": shared_workspace }
    }))
    .unwrap();
    let conv2 = svc.create(USER_ID, req2).await.unwrap();

    // Different workspace
    let req3: CreateConversationRequest = serde_json::from_value(json!({
        "type": "acp",
        "name": "Conv C",
        "extra": { "workspace": other_workspace }
    }))
    .unwrap();
    svc.create(USER_ID, req3).await.unwrap();

    let associated = svc.list_associated(USER_ID, &conv1.id).await.unwrap();
    assert_eq!(associated.len(), 1);
    assert_eq!(associated[0].id, conv2.id);
}

#[tokio::test]
async fn t10_2_no_associated() {
    let (svc, _repo, _b) = setup().await;
    let workspace = ensure_named_workspace_path("qianji-conversation-extended-unique-workspace");

    let req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "acp",
        "extra": { "workspace": workspace }
    }))
    .unwrap();
    let conv = svc.create(USER_ID, req).await.unwrap();

    let associated = svc.list_associated(USER_ID, &conv.id).await.unwrap();
    assert!(associated.is_empty());
}

#[tokio::test]
async fn t10_3_associated_not_found() {
    let (svc, _repo, _b) = setup().await;
    let err = svc.list_associated(USER_ID, "nonexistent").await.unwrap_err();
    assert!(matches!(err, ConversationError::NotFound { .. }));
}

// ── T12: Boundary scenarios ────────────────────────────────────────

#[tokio::test]
async fn t12_4_search_sql_injection() {
    let (svc, repo, _b) = setup().await;
    let conv = svc.create(USER_ID, make_create_req()).await.unwrap();
    repo.insert_message(USER_ID, &make_message(&conv.id, "safe content", 0))
        .await
        .unwrap();

    let query = SearchMessagesQuery {
        keyword: "'; DROP TABLE messages; --".into(),
        page: None,
        page_size: None,
    };
    // Should return empty results, not crash
    let result = svc.search_messages(USER_ID, query).await.unwrap();
    assert!(result.items.is_empty());
}

// ── Ownership cross-cutting ────────────────────────────────────────

#[tokio::test]
async fn messages_wrong_user_returns_not_found() {
    let (svc, repo, _b) = setup().await;
    let conv = svc.create(USER_ID, make_create_req()).await.unwrap();
    repo.insert_message(USER_ID, &make_message(&conv.id, "hello", 0))
        .await
        .unwrap();

    let err = svc
        .list_messages("other_user", &conv.id, ListMessagesQuery::default())
        .await
        .unwrap_err();
    assert!(matches!(err, ConversationError::NotFound { .. }));
}

#[tokio::test]
async fn reset_wrong_user_returns_not_found() {
    let (svc, _repo, _b) = setup().await;
    let conv = svc.create(USER_ID, make_create_req()).await.unwrap();

    let err = svc.reset("other_user", &conv.id).await.unwrap_err();
    assert!(matches!(err, ConversationError::NotFound { .. }));
}

// ── Conversation fork ───────────────────────────────────────────────

async fn setup_fork() -> (
    ConversationService,
    Arc<SqliteConversationRepository>,
    Arc<dyn qianji_db::IAcpSessionRepository>,
) {
    let db = init_database_memory().await.unwrap();
    let repo = Arc::new(SqliteConversationRepository::new(db.pool().clone()));
    let broadcaster = Arc::new(TestBroadcaster::new());
    let agent_metadata_repo: Arc<dyn qianji_db::IAgentMetadataRepository> =
        Arc::new(qianji_db::SqliteAgentMetadataRepository::new(db.pool().clone()));
    let acp_session_repo: Arc<dyn qianji_db::IAcpSessionRepository> =
        Arc::new(qianji_db::SqliteAcpSessionRepository::new(db.pool().clone()));
    let task_mgr: Arc<dyn IWorkerTaskManager> = Arc::new(NoopTaskManager);
    let svc = ConversationService::new(
        std::env::temp_dir(),
        broadcaster,
        Arc::new(EmptySkillResolver),
        task_mgr,
        repo.clone(),
        agent_metadata_repo,
        acp_session_repo.clone(),
    );
    (svc, repo, acp_session_repo)
}

fn fork_create_req(backend: &str) -> CreateConversationRequest {
    let workspace = ensure_named_workspace_path(&format!("qianji-fork-test-{backend}"));
    serde_json::from_value(json!({
        "type": "acp",
        "extra": { "workspace": workspace, "backend": backend }
    }))
    .unwrap()
}

fn fork_req(message_id: &str) -> qianji_api_types::ForkConversationRequest {
    serde_json::from_value(json!({ "message_id": message_id })).unwrap()
}

#[tokio::test]
async fn fork_head_creates_lineage_row_and_copies_messages() {
    let (svc, repo, acp_repo) = setup_fork().await;
    let parent = svc.create(USER_ID, fork_create_req("claude")).await.unwrap();
    acp_repo
        .update_session_id_for_user(USER_ID, &parent.id, "parent-sid-1")
        .await
        .unwrap();
    let m1 = make_message(&parent.id, "hello", 0);
    let m2 = make_message(&parent.id, "world", 10);
    repo.insert_message(USER_ID, &m1).await.unwrap();
    repo.insert_message(USER_ID, &m2).await.unwrap();

    // HEAD fork (claude is seeded with a head-only fork capability by 036).
    let fork = svc.fork(USER_ID, &parent.id, fork_req(&m2.id)).await.unwrap();
    assert_ne!(fork.id, parent.id);
    assert_eq!(fork.name, parent.name, "name defaults to the parent's");
    assert_eq!(
        fork.fork_capability,
        Some(qianji_api_types::ForkCapabilityView { at_turn: false }),
        "claude declares a HEAD-only fork capability"
    );
    let spec = fork.extra.get("fork").expect("fork lineage in extra");
    assert_eq!(spec["parent_conversation_id"], parent.id);
    assert_eq!(spec["parent_message_id"], m2.id);
    assert_eq!(spec["parent_session_id"], "parent-sid-1");
    assert!(spec.get("last_turn_id").is_none(), "HEAD fork carries no turn anchor");

    // Copied history, reminted ids, same workspace.
    let page = repo
        .list_messages_page(
            USER_ID,
            &fork.id,
            &qianji_db::MessagePageParams {
                limit: 50,
                direction: qianji_db::MessagePageDirection::InitialLatest,
            },
        )
        .await
        .unwrap();
    assert_eq!(page.items.len(), 2);
    assert_eq!(
        fork.extra.get("workspace"),
        // The response extra echoes the parent's workspace verbatim.
        svc.get(USER_ID, &parent.id).await.unwrap().extra.get("workspace"),
        "fork shares the parent workspace (claude cwd constraint)"
    );

    // The fork's acp_session row exists, same agent identity, UNBOUND sid.
    let fork_session = acp_repo.get_for_user(USER_ID, &fork.id).await.unwrap().unwrap();
    assert_eq!(fork_session.session_id, None, "fork pending until first open");
    let parent_session = acp_repo.get_for_user(USER_ID, &parent.id).await.unwrap().unwrap();
    assert_eq!(fork_session.agent_id, parent_session.agent_id);
    assert_eq!(
        parent_session.session_id.as_deref(),
        Some("parent-sid-1"),
        "the parent's binding is untouched"
    );
}

#[tokio::test]
async fn fork_mid_history_is_refused_for_head_only_backends() {
    let (svc, repo, acp_repo) = setup_fork().await;
    let parent = svc.create(USER_ID, fork_create_req("claude")).await.unwrap();
    acp_repo
        .update_session_id_for_user(USER_ID, &parent.id, "parent-sid-2")
        .await
        .unwrap();
    let m1 = make_message(&parent.id, "one", 0);
    let m2 = make_message(&parent.id, "two", 10);
    repo.insert_message(USER_ID, &m1).await.unwrap();
    repo.insert_message(USER_ID, &m2).await.unwrap();

    let err = svc.fork(USER_ID, &parent.id, fork_req(&m1.id)).await.unwrap_err();
    assert!(
        matches!(&err, ConversationError::Unprocessable { reason } if reason.starts_with("FORK_POINT_UNSUPPORTED")),
        "claude mid-history fork must be refused, got {err:?}"
    );
}

#[tokio::test]
async fn fork_mid_history_resolves_codex_turn_anchor() {
    let (svc, repo, acp_repo) = setup_fork().await;
    let parent = svc.create(USER_ID, fork_create_req("codex")).await.unwrap();
    acp_repo
        .update_session_id_for_user(USER_ID, &parent.id, "th-parent")
        .await
        .unwrap();
    let mut m1 = make_message(&parent.id, "one", 0);
    m1.backend_turn_id = Some("turn-1".into());
    let m2 = make_message(&parent.id, "two", 10);
    repo.insert_message(USER_ID, &m1).await.unwrap();
    repo.insert_message(USER_ID, &m2).await.unwrap();

    let fork = svc.fork(USER_ID, &parent.id, fork_req(&m1.id)).await.unwrap();
    assert_eq!(
        fork.fork_capability,
        Some(qianji_api_types::ForkCapabilityView { at_turn: true }),
        "codex declares an at-turn fork capability"
    );
    assert_eq!(
        fork.extra["fork"]["last_turn_id"], "turn-1",
        "the mid-history fork resolved the stamped codex turn anchor"
    );
    // And only the pre-fork-point message was copied.
    let page = repo
        .list_messages_page(
            USER_ID,
            &fork.id,
            &qianji_db::MessagePageParams {
                limit: 50,
                direction: qianji_db::MessagePageDirection::InitialLatest,
            },
        )
        .await
        .unwrap();
    assert_eq!(page.items.len(), 1);
}

#[tokio::test]
async fn fork_mid_history_without_anchor_is_refused_not_degraded() {
    let (svc, repo, acp_repo) = setup_fork().await;
    let parent = svc.create(USER_ID, fork_create_req("codex")).await.unwrap();
    acp_repo
        .update_session_id_for_user(USER_ID, &parent.id, "th-parent")
        .await
        .unwrap();
    // Legacy rows: no backend_turn_id anywhere.
    let m1 = make_message(&parent.id, "one", 0);
    let m2 = make_message(&parent.id, "two", 10);
    repo.insert_message(USER_ID, &m1).await.unwrap();
    repo.insert_message(USER_ID, &m2).await.unwrap();

    let err = svc.fork(USER_ID, &parent.id, fork_req(&m1.id)).await.unwrap_err();
    assert!(
        matches!(&err, ConversationError::Unprocessable { reason } if reason.starts_with("FORK_POINT_UNSUPPORTED")),
        "an unresolvable anchor must refuse, never silently fork at HEAD, got {err:?}"
    );
}

#[tokio::test]
async fn fork_rejects_unbound_parent_and_unsupported_agent() {
    let (svc, repo, acp_repo) = setup_fork().await;

    // Unbound parent (never had a backend session).
    let unbound = svc.create(USER_ID, fork_create_req("claude")).await.unwrap();
    let m = make_message(&unbound.id, "hello", 0);
    repo.insert_message(USER_ID, &m).await.unwrap();
    let err = svc.fork(USER_ID, &unbound.id, fork_req(&m.id)).await.unwrap_err();
    assert!(
        matches!(&err, ConversationError::Busy { reason } if reason.starts_with("FORK_PARENT_UNBOUND")),
        "got {err:?}"
    );

    // Agent without a fork declaration (qwen's seeded capabilities carry no fork key).
    let unsupported = svc.create(USER_ID, fork_create_req("qwen")).await.unwrap();
    acp_repo
        .update_session_id_for_user(USER_ID, &unsupported.id, "sid-x")
        .await
        .unwrap();
    let m = make_message(&unsupported.id, "hello", 0);
    repo.insert_message(USER_ID, &m).await.unwrap();
    let err = svc.fork(USER_ID, &unsupported.id, fork_req(&m.id)).await.unwrap_err();
    assert!(
        matches!(&err, ConversationError::Unprocessable { reason } if reason.starts_with("FORK_UNSUPPORTED")),
        "got {err:?}"
    );
}

#[tokio::test]
async fn create_strips_client_supplied_fork_spec() {
    let (svc, _repo, _acp) = setup_fork().await;
    let workspace = ensure_named_workspace_path("qianji-fork-test-strip");
    let req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "acp",
        "extra": {
            "workspace": workspace,
            "backend": "claude",
            "fork": { "parent_conversation_id": "x", "parent_message_id": "y", "parent_session_id": "stolen" }
        }
    }))
    .unwrap();
    let created = svc.create(USER_ID, req).await.unwrap();
    assert!(
        created.extra.get("fork").is_none(),
        "a client-supplied fork spec must be stripped on the create path"
    );
}

#[tokio::test]
async fn get_projects_fork_capability_on_detail_path() {
    let (svc, _repo, _acp) = setup_fork().await;
    let claude_conv = svc.create(USER_ID, fork_create_req("claude")).await.unwrap();
    let got = svc.get(USER_ID, &claude_conv.id).await.unwrap();
    assert_eq!(
        got.fork_capability,
        Some(qianji_api_types::ForkCapabilityView { at_turn: false })
    );

    let codex_conv = svc.create(USER_ID, fork_create_req("codex")).await.unwrap();
    let got = svc.get(USER_ID, &codex_conv.id).await.unwrap();
    assert_eq!(
        got.fork_capability,
        Some(qianji_api_types::ForkCapabilityView { at_turn: true })
    );
}

#[tokio::test]
async fn get_projects_prompt_capability_on_detail_path() {
    let (svc, _repo, _acp) = setup_fork().await;

    // claude: migration 037 seeds image-only prompt capabilities.
    let claude_conv = svc.create(USER_ID, fork_create_req("claude")).await.unwrap();
    let got = svc.get(USER_ID, &claude_conv.id).await.unwrap();
    assert_eq!(
        got.prompt_capability,
        Some(qianji_api_types::PromptCapabilityView {
            image: true,
            audio: false
        })
    );

    // qwen: 003 seeds image + audio.
    let qwen_conv = svc.create(USER_ID, fork_create_req("qwen")).await.unwrap();
    let got = svc.get(USER_ID, &qwen_conv.id).await.unwrap();
    assert_eq!(
        got.prompt_capability,
        Some(qianji_api_types::PromptCapabilityView {
            image: true,
            audio: true
        })
    );
}

#[tokio::test]
async fn delete_parent_keeps_workspace_shared_with_fork() {
    let (svc, repo, acp_repo) = setup_fork().await;
    // No workspace in extra → create() auto-provisions one under
    // workspace_root/conversations/... — the deletable kind.
    let req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "acp",
        "extra": { "backend": "claude" }
    }))
    .unwrap();
    let parent = svc.create(USER_ID, req).await.unwrap();
    let workspace = parent
        .extra
        .get("workspace")
        .and_then(|v| v.as_str())
        .expect("auto-provisioned workspace")
        .to_owned();
    assert!(std::path::Path::new(&workspace).is_dir());

    acp_repo
        .update_session_id_for_user(USER_ID, &parent.id, "parent-sid-ws")
        .await
        .unwrap();
    let m = make_message(&parent.id, "hello", 0);
    repo.insert_message(USER_ID, &m).await.unwrap();
    let fork = svc.fork(USER_ID, &parent.id, fork_req(&m.id)).await.unwrap();
    assert_eq!(
        fork.extra.get("workspace").and_then(|v| v.as_str()),
        Some(workspace.as_str()),
        "the fork shares the parent's auto workspace"
    );

    svc.delete(USER_ID, &parent.id).await.unwrap();
    assert!(
        std::path::Path::new(&workspace).is_dir(),
        "deleting the parent must NOT remove the workspace the fork still uses"
    );

    // Deleting the fork leaves the directory too: the auto-workspace removal
    // is keyed on the `-temp-{id}` name suffix, which only the PARENT matches.
    // An orphaned directory is the accepted trade-off (safety over cleanup).
    svc.delete(USER_ID, &fork.id).await.unwrap();
    assert!(
        std::path::Path::new(&workspace).is_dir(),
        "the fork's delete never removes a workspace named after the parent"
    );
    std::fs::remove_dir_all(&workspace).ok();
}

#[tokio::test]
async fn fork_resolves_stream_msg_id_when_row_id_unknown() {
    let (svc, repo, acp_repo) = setup_fork().await;
    let parent = svc.create(USER_ID, fork_create_req("claude")).await.unwrap();
    acp_repo
        .update_session_id_for_user(USER_ID, &parent.id, "parent-sid-msgid")
        .await
        .unwrap();
    // make_message mints msg_id ("client_...") distinct from the row id — the
    // shape a live-streamed frontend message sends (its local `id` is never
    // persisted, only the stream msg_id matches anything in the DB).
    let m = make_message(&parent.id, "hello", 0);
    repo.insert_message(USER_ID, &m).await.unwrap();

    let fork = svc
        .fork(USER_ID, &parent.id, fork_req(m.msg_id.as_deref().unwrap()))
        .await
        .expect("msg_id fallback resolves the fork point");
    assert_eq!(
        fork.extra["fork"]["parent_message_id"], m.id,
        "resolved to the real row"
    );
}

// ── Conversation fork: builtin qianjirs agent (no acp_session row) ────

fn qianjirs_create_req() -> CreateConversationRequest {
    let workspace = ensure_named_workspace_path("qianji-fork-test-qianjirs");
    serde_json::from_value(json!({
        "type": "qianjirs",
        "extra": { "workspace": workspace, "backend": "qianjirs" }
    }))
    .unwrap()
}

#[tokio::test]
async fn fork_head_qianjirs_uses_conversation_id_anchor_without_acp_row() {
    let (svc, repo, acp_repo) = setup_fork().await;
    let parent = svc.create(USER_ID, qianjirs_create_req()).await.unwrap();
    // qianjirs conversations own no acp_session row (create() only makes one
    // for ACP/antigravity) — the whole point of this path. The agent
    // identity resolves through the builtin binding ladder (agent_type
    // "qianjirs" -> seed row), no assistant snapshot required.
    assert!(acp_repo.get_for_user(USER_ID, &parent.id).await.unwrap().is_none());
    let m1 = make_message(&parent.id, "hello", 0);
    let m2 = make_message(&parent.id, "world", 10);
    repo.insert_message(USER_ID, &m1).await.unwrap();
    repo.insert_message(USER_ID, &m2).await.unwrap();

    let fork = svc.fork(USER_ID, &parent.id, fork_req(&m2.id)).await.unwrap();
    assert_ne!(fork.id, parent.id);
    assert_eq!(
        fork.fork_capability,
        Some(qianji_api_types::ForkCapabilityView { at_turn: true }),
        "qianjirs declares an at-turn fork capability (migration 038)"
    );
    let spec = fork.extra.get("fork").expect("fork lineage in extra");
    assert_eq!(spec["parent_conversation_id"], parent.id);
    assert_eq!(spec["parent_message_id"], m2.id);
    assert_eq!(
        spec["parent_session_id"], parent.id,
        "qianjirs sessions are keyed by conversation id, so the parent conversation id is the session anchor"
    );
    assert!(spec.get("last_turn_id").is_none(), "qianjirs forks only at HEAD");

    // Copied history.
    let page = repo
        .list_messages_page(
            USER_ID,
            &fork.id,
            &qianji_db::MessagePageParams {
                limit: 50,
                direction: qianji_db::MessagePageDirection::InitialLatest,
            },
        )
        .await
        .unwrap();
    assert_eq!(page.items.len(), 2);

    // The fork, like every qianjirs conversation, owns no acp_session row.
    assert!(acp_repo.get_for_user(USER_ID, &fork.id).await.unwrap().is_none());
}

#[tokio::test]
async fn fork_mid_history_without_anchor_is_refused_for_qianjirs() {
    let (svc, repo, _acp_repo) = setup_fork().await;
    let parent = svc.create(USER_ID, qianjirs_create_req()).await.unwrap();
    // Rows without backend_turn_id: written before turn stamping existed.
    let m1 = make_message(&parent.id, "one", 0);
    let m2 = make_message(&parent.id, "two", 10);
    repo.insert_message(USER_ID, &m1).await.unwrap();
    repo.insert_message(USER_ID, &m2).await.unwrap();

    let err = svc.fork(USER_ID, &parent.id, fork_req(&m1.id)).await.unwrap_err();
    assert!(
        matches!(&err, ConversationError::Unprocessable { reason } if reason.starts_with("FORK_POINT_UNSUPPORTED")),
        "unanchored qianjirs mid-history fork must be refused, not degraded to HEAD, got {err:?}"
    );
}

#[tokio::test]
async fn fork_mid_history_resolves_qianjirs_turn_anchor() {
    let (svc, repo, _acp_repo) = setup_fork().await;
    let parent = svc.create(USER_ID, qianjirs_create_req()).await.unwrap();
    // Rows stamped by the qianjirs turn wiring (manager emits BackendTurnBound
    // with the conversation-layer turn id).
    let mut m1 = make_message(&parent.id, "one", 0);
    m1.backend_turn_id = Some("turn_qianji1".into());
    let m2 = make_message(&parent.id, "two", 10);
    repo.insert_message(USER_ID, &m1).await.unwrap();
    repo.insert_message(USER_ID, &m2).await.unwrap();

    let fork = svc.fork(USER_ID, &parent.id, fork_req(&m1.id)).await.unwrap();
    let spec = fork.extra.get("fork").expect("fork lineage in extra");
    assert_eq!(
        spec["last_turn_id"], "turn_qianji1",
        "mid-history fork snapshots the resolved qianjirs turn anchor"
    );
    assert_eq!(spec["parent_session_id"], parent.id);
}

#[tokio::test]
async fn get_projects_fork_capability_for_qianjirs_on_detail_path() {
    let (svc, _repo, _acp_repo) = setup_fork().await;
    let conv = svc.create(USER_ID, qianjirs_create_req()).await.unwrap();

    let detail = svc.get(USER_ID, &conv.id).await.unwrap();
    assert_eq!(
        detail.fork_capability,
        Some(qianji_api_types::ForkCapabilityView { at_turn: true }),
        "detail path projects the qianjirs fork capability via the builtin binding ladder"
    );
}
