use std::sync::Arc;

use qianji_api_types::{ConversationRuntimeSummary, WebSocketMessage};
use qianji_common::{ErrorChain, now_ms};
use qianji_db::{ConversationRowUpdate, IConversationRepository};
use qianji_realtime::EventBroadcaster;
use serde_json::json;
use tracing::{debug, error};

use crate::runtime_persistence::{RuntimePersistenceCoordinator, RuntimeWriteKind};

#[derive(Clone)]
pub struct RuntimeCompletionPublisher {
    user_id: String,
    repo: Arc<dyn IConversationRepository>,
    broadcaster: Arc<dyn EventBroadcaster>,
    persistence: RuntimePersistenceCoordinator,
}

impl RuntimeCompletionPublisher {
    pub fn new(
        user_id: String,
        repo: Arc<dyn IConversationRepository>,
        broadcaster: Arc<dyn EventBroadcaster>,
        persistence: RuntimePersistenceCoordinator,
    ) -> Self {
        Self {
            user_id,
            repo,
            broadcaster,
            persistence,
        }
    }

    #[tracing::instrument(skip_all, fields(conversation_id = %conversation_id, turn_id = %turn_id))]
    pub async fn publish(&self, conversation_id: &str, turn_id: &str, runtime: Option<ConversationRuntimeSummary>) {
        if !self
            .persistence
            .allows(conversation_id, RuntimeWriteKind::ConversationFinished)
        {
            debug!(
                conversation_id,
                turn_id, "turn completion skipped by runtime persistence policy"
            );
            return;
        }

        match self.repo.get(&self.user_id, conversation_id).await {
            Ok(Some(_)) => {}
            Ok(None) => {
                debug!(
                    conversation_id,
                    turn_id, "turn completion skipped because conversation row is missing"
                );
                return;
            }
            Err(error) => {
                error!(
                    conversation_id,
                    turn_id,
                    error = %ErrorChain(&error),
                    "turn completion skipped because conversation row lookup failed"
                );
                return;
            }
        }

        let update = ConversationRowUpdate {
            status: Some("finished".to_owned()),
            updated_at: Some(now_ms()),
            ..Default::default()
        };
        if let Err(error) = self.repo.update(&self.user_id, conversation_id, &update).await {
            error!(
                conversation_id,
                turn_id,
                error = %ErrorChain(&error),
                "Failed to update conversation status"
            );
            return;
        }

        let payload = json!({
            "user_id": self.user_id,
            "conversation_id": conversation_id,
            "session_id": conversation_id,
            "turn_id": turn_id,
            "status": "finished",
            "canSendMessage": true,
            "runtime": runtime,
        });
        self.broadcaster
            .broadcast(WebSocketMessage::new("turn.completed", payload));

        debug!(conversation_id, turn_id, status = "finished", "Turn completed");
    }
}
