use std::sync::Arc;

use qianji_ai_agent::protocol::events::{ErrorEventData, TipType, TipsEventData};
use qianji_ai_agent::{AgentSendError, AgentStreamEvent, protocol::events::ThinkingEventData};

use crate::response_middleware::{ISkillLoadService, MessageMiddleware, MiddlewareResult};
use crate::skill_resolver::{LoadedAgentSkill, SkillResolver};
use qianji_api_types::{AgentErrorCode, WebSocketMessage};
use qianji_common::{ErrorChain, normalize_keys_to_snake_case, now_ms};

use crate::runtime_persistence::RuntimePersistenceCoordinator;
use crate::runtime_state::ConversationRuntimeStateService;
use crate::service::ConversationService;
use crate::stream_persistence::{
    PersistedTextSegment, StreamPersistenceAdapter, TextSegmentState, ThinkingSegmentState,
};
use qianji_db::IConversationRepository;
use qianji_realtime::EventBroadcaster;
use serde_json::json;
use tokio::sync::broadcast::error::TryRecvError;
use tokio::sync::{broadcast, oneshot};
use tracing::{debug, info, warn};

/// Number of text chunks to accumulate before flushing to the database.
const FLUSH_INTERVAL: u32 = 20;

/// Running totals for tips that supersede themselves, kept for the whole turn.
///
/// A superseding tip is one card the user watches update — codex's retry card
/// is the first — and what it measures is the turn, not the agent process. A
/// stalled prompt can be replayed against a freshly spawned CLI, and a counter
/// living in that process restarts at 1 halfway through the card. The relay
/// outlives those attempts, so the totals belong here.
///
/// The two params are added to whatever the producer already sent, so a locale
/// body can use them (`CODEX_RETRYING`) or ignore them.
///
/// Shared by handle: the turn orchestrator builds a FRESH relay per attempt, so
/// state living in one relay resets on exactly the boundary this is meant to
/// span. The orchestrator makes one of these per turn and hands every attempt
/// the same handle.
#[derive(Debug, Clone, Default)]
pub struct SupersedingTipTotals {
    seen: Arc<std::sync::Mutex<std::collections::HashMap<String, (u64, i64)>>>,
}

impl SupersedingTipTotals {
    /// Returns the tip with `attempts`/`elapsed` filled in, or `None` when it
    /// carries no merge key and therefore has no history to report.
    fn annotate(&self, data: &TipsEventData, now_ms: i64) -> Option<TipsEventData> {
        let key = data.supersedes_key.as_deref()?;
        let (attempts, first_ms) = {
            let mut seen = self.seen.lock().unwrap_or_else(|e| e.into_inner());
            let entry = seen.entry(key.to_owned()).or_insert((0, now_ms));
            entry.0 += 1;
            *entry
        };

        let mut params = match data.params.clone() {
            Some(serde_json::Value::Object(map)) => map,
            _ => serde_json::Map::new(),
        };
        params.insert("attempts".into(), serde_json::Value::from(attempts));
        params.insert(
            "elapsed".into(),
            serde_json::Value::String(humanize_ms(now_ms.saturating_sub(first_ms))),
        );

        Some(TipsEventData {
            params: Some(serde_json::Value::Object(params)),
            ..data.clone()
        })
    }
}

/// Compact, locale-neutral duration: `45s`, `7m41s`, `1h02m`.
fn humanize_ms(ms: i64) -> String {
    let total = (ms.max(0) / 1000) as u64;
    match (total / 3600, (total % 3600) / 60, total % 60) {
        (0, 0, s) => format!("{s}s"),
        (0, m, s) => format!("{m}m{s:02}s"),
        (h, m, _) => format!("{h}h{m:02}m"),
    }
}

/// Conservative summary of what happened during one agent send attempt.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct TurnAttemptSummary {
    pub saw_visible_output: bool,
    pub saw_tool_or_side_effect: bool,
    pub persisted_assistant_output: bool,
    pub terminal_error: Option<ErrorEventData>,
    pub terminal_error_deferred: bool,
    /// The turn ended benignly (a Finish, not an Error) but the agent signalled
    /// that it needs sign-in — an `ACP_EMPTY_TURN_NEEDS_AUTH` tip. Lets the turn
    /// orchestrator reflect "needs auth" into the agent's availability even
    /// though the turn itself is not an error.
    pub needs_auth: bool,
}

impl TurnAttemptSummary {
    pub fn safe_to_auto_replay(&self) -> bool {
        !self.saw_visible_output && !self.saw_tool_or_side_effect && !self.persisted_assistant_output
    }

    pub fn merge(&mut self, other: &TurnAttemptSummary) {
        self.saw_visible_output |= other.saw_visible_output;
        self.saw_tool_or_side_effect |= other.saw_tool_or_side_effect;
        self.persisted_assistant_output |= other.persisted_assistant_output;
        self.needs_auth |= other.needs_auth;
        if other.terminal_error.is_some() {
            self.terminal_error = other.terminal_error.clone();
        }
        self.terminal_error_deferred |= other.terminal_error_deferred;
    }
}

/// Result returned after a relay turn has fully drained and finalized.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct RelayOutcome {
    pub system_responses: Vec<String>,
    pub terminal: RelayTerminal,
    pub attempt: TurnAttemptSummary,
}

#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub enum RelayTerminal {
    #[default]
    Finish,
    Error {
        code: Option<AgentErrorCode>,
        retryable: Option<bool>,
    },
    ChannelClosed,
}

impl RelayTerminal {
    pub fn is_error(&self) -> bool {
        matches!(self, Self::Error { .. })
    }

    pub fn code(&self) -> Option<AgentErrorCode> {
        match self {
            Self::Error { code, .. } => *code,
            Self::Finish | Self::ChannelClosed => None,
        }
    }

    pub fn retryable(&self) -> Option<bool> {
        match self {
            Self::Error { retryable, .. } => *retryable,
            Self::Finish | Self::ChannelClosed => None,
        }
    }
}

/// Relays agent stream events to WebSocket and persists messages.
///
/// This struct is created for each `send_message` call and runs as a
/// background tokio task until the agent finishes or errors out.
pub struct StreamRelay {
    conversation_id: String,
    msg_id: String,
    turn_id: String,
    user_id: String,
    repo: Arc<dyn IConversationRepository>,
    broadcaster: Arc<dyn EventBroadcaster>,
    skill_resolver: Option<Arc<dyn SkillResolver>>,
    allowed_skill_names: Vec<String>,
    runtime_state: Option<Arc<ConversationRuntimeStateService>>,
    persistence: Option<RuntimePersistenceCoordinator>,
    adapter: StreamPersistenceAdapter,
    complete_turn: bool,
    defer_clean_terminal_errors: bool,
    superseding_tips: SupersedingTipTotals,
}

impl StreamRelay {
    pub fn new(
        conversation_id: String,
        msg_id: String,
        turn_id: String,
        user_id: String,
        repo: Arc<dyn IConversationRepository>,
        broadcaster: Arc<dyn EventBroadcaster>,
    ) -> Self {
        let adapter = StreamPersistenceAdapter::new(
            user_id.clone(),
            conversation_id.clone(),
            msg_id.clone(),
            repo.clone(),
            None,
        );
        Self {
            conversation_id,
            msg_id,
            turn_id,
            user_id,
            repo,
            broadcaster,
            skill_resolver: None,
            allowed_skill_names: Vec::new(),
            runtime_state: None,
            persistence: None,
            adapter,
            complete_turn: true,
            defer_clean_terminal_errors: false,
            superseding_tips: SupersedingTipTotals::default(),
        }
    }

    pub fn with_runtime_state(mut self, runtime_state: Arc<ConversationRuntimeStateService>) -> Self {
        self.runtime_state = Some(runtime_state);
        self
    }

    pub fn with_skill_resolver(mut self, skill_resolver: Arc<dyn SkillResolver>) -> Self {
        self.skill_resolver = Some(skill_resolver);
        self
    }

    pub fn with_allowed_skill_names(mut self, skill_names: Vec<String>) -> Self {
        self.allowed_skill_names = skill_names;
        self
    }

    pub fn with_persistence(mut self, persistence: RuntimePersistenceCoordinator) -> Self {
        self.persistence = Some(persistence.clone());
        self.adapter = self.adapter.with_persistence(persistence);
        self
    }

    pub fn with_turn_completion(mut self, enabled: bool) -> Self {
        self.complete_turn = enabled;
        self
    }

    /// Share this turn's superseding-tip totals across its replay attempts.
    /// Without it each attempt counts from one, and the card the user is
    /// watching restarts mid-stall.
    pub fn with_superseding_tip_totals(mut self, totals: SupersedingTipTotals) -> Self {
        self.superseding_tips = totals;
        self
    }

    pub fn with_defer_clean_terminal_errors(mut self, enabled: bool) -> Self {
        self.defer_clean_terminal_errors = enabled;
        self
    }

    /// Run the relay loop. Consumes `self` and runs until the agent stream ends.
    #[tracing::instrument(
        skip_all,
        fields(
            conversation_id = %self.conversation_id,
            msg_id = %self.msg_id,
            turn_id = %self.turn_id,
        )
    )]
    pub async fn consume(self, rx: broadcast::Receiver<AgentStreamEvent>) -> RelayOutcome {
        self.consume_inner(rx, None).await
    }

    /// Run the relay loop while also accepting a typed send failure from the
    /// task that called `IAgentTask::send_message`.
    #[tracing::instrument(
        skip_all,
        fields(
            conversation_id = %self.conversation_id,
            msg_id = %self.msg_id,
            turn_id = %self.turn_id,
        )
    )]
    pub async fn consume_with_send_error(
        self,
        rx: broadcast::Receiver<AgentStreamEvent>,
        send_error_rx: oneshot::Receiver<AgentSendError>,
    ) -> RelayOutcome {
        self.consume_inner(rx, Some(send_error_rx)).await
    }

    async fn consume_inner(
        self,
        mut rx: broadcast::Receiver<AgentStreamEvent>,
        mut send_error_rx: Option<oneshot::Receiver<AgentSendError>>,
    ) -> RelayOutcome {
        let started_at = now_ms();
        info!(
            target: "qianji_feedback_diagnostics",
            diagnostic_event = "feedback.runtime.turn_start",
            conversation_id = %self.conversation_id,
            turn_id = %self.turn_id,
            msg_id = %self.msg_id,
            "feedback.runtime.turn_start"
        );

        let mut full_text_buffer = String::new();
        let mut text_segments: Vec<PersistedTextSegment> = Vec::new();
        let mut active_text: Option<TextSegmentState> = None;
        let mut active_thinking: Option<ThinkingSegmentState> = None;
        let mut used_primary_segment_msg_id = false;
        let mut first_agent_event_logged = false;
        let mut first_visible_output_logged = false;
        let mut send_error_done = send_error_rx.is_none();
        let mut pending_send_error: Option<AgentSendError> = None;
        let mut attempt = TurnAttemptSummary::default();

        loop {
            let recv_result = if send_error_done {
                if let Some(send_error) = pending_send_error.take() {
                    match rx.try_recv() {
                        Ok(event) => {
                            if !matches!(event, AgentStreamEvent::Finish(_) | AgentStreamEvent::Error(_)) {
                                pending_send_error = Some(send_error);
                            } else {
                                debug!("Runtime terminal event won race with fallback send error");
                            }
                            Ok(event)
                        }
                        Err(TryRecvError::Empty) | Err(TryRecvError::Closed) => {
                            warn!(
                                code = ?send_error.code(),
                                ownership = ?send_error.ownership(),
                                "Injecting stream error for failed agent send"
                            );
                            Ok(AgentStreamEvent::Error(send_error.into_stream_error()))
                        }
                        Err(TryRecvError::Lagged(n)) => Err(broadcast::error::RecvError::Lagged(n)),
                    }
                } else {
                    rx.recv().await
                }
            } else {
                tokio::select! {
                    recv = rx.recv() => recv,
                    send_error = send_error_rx.as_mut().expect("send_error_rx exists while pending") => {
                        send_error_done = true;
                        match send_error {
                            Ok(send_error) => {
                                pending_send_error = Some(send_error);
                                continue;
                            }
                            Err(_) => continue,
                        }
                    }
                }
            };

            match recv_result {
                Ok(event) => {
                    let deleting = self.is_deleting();
                    if deleting && !matches!(event, AgentStreamEvent::Finish(_) | AgentStreamEvent::Error(_)) {
                        debug!(
                            event_type = Self::event_kind(&event),
                            "Skipping non-terminal stream event because conversation is deleting"
                        );
                        continue;
                    }

                    if !first_agent_event_logged {
                        first_agent_event_logged = true;
                        info!(
                            target: "qianji_feedback_diagnostics",
                            diagnostic_event = "feedback.runtime.turn_first_agent_event",
                            conversation_id = %self.conversation_id,
                            turn_id = %self.turn_id,
                            msg_id = %self.msg_id,
                            event_type = %Self::event_kind(&event),
                            elapsed_ms = now_ms().saturating_sub(started_at),
                            "feedback.runtime.turn_first_agent_event"
                        );
                    }

                    match &event {
                        AgentStreamEvent::SegmentBreak => {
                            // Intra-turn soft boundary (see AgentStreamEvent::SegmentBreak):
                            // close the current text/thinking segment so the next batch of
                            // text starts a fresh bubble, but do NOT terminate the relay and
                            // do NOT forward this event to the WebSocket.
                            self.complete_active_thinking(&mut active_thinking).await;
                            self.close_active_text_segment(&mut active_text, &mut text_segments, "finish")
                                .await;
                        }
                        AgentStreamEvent::AcpDialectSignal(_) => {
                            // Internal-only turn/near-window signal (see
                            // AgentStreamEvent::AcpDialectSignal): consumed by the ACP
                            // empty-turn judgment, never rendered. Explicitly dropped here so
                            // the catch-all below does not forward it to the WebSocket, and
                            // it is never persisted.
                        }
                        AgentStreamEvent::BackendTurnBound(backend_turn_id) => {
                            // Internal-only fork anchor (codex Turn.id): stamp it on the
                            // adapter so every message row persisted for this turn carries
                            // `messages.backend_turn_id` — the `thread/fork` lastTurnId
                            // lookup key. Never forwarded to the WS, never persisted as an
                            // event itself.
                            self.adapter.set_backend_turn_id(backend_turn_id.clone());
                        }
                        AgentStreamEvent::Thinking(data) => {
                            if data.status.as_deref() == Some("done") {
                                self.complete_active_thinking(&mut active_thinking).await;
                                continue;
                            }

                            // POLICY — one place, every backend: a thinking chunk with no
                            // text carries nothing to render, so it must never open a
                            // segment. Letting it through mints a "thinking done · 0s" card
                            // that expands to nothing, and once that segment is persisted the
                            // user gets one such card per chunk on every reload.
                            //
                            // Backends manufacture empty thoughts from several INDEPENDENT
                            // places — claude's consolidated `thinking` block, the ACP
                            // `agent_thought_chunk` translate path, codex's `unwrap_or("")`
                            // delta, qianjirs `emit_thinking` — so guarding them one by one is
                            // whack-a-mole. They all converge here.
                            //
                            // This also delivers the live/reload parity that
                            // `persist_thinking_segment` used to chase by STORING the empty
                            // row: both sides now agree, with no blank card on either.
                            if data.content.is_empty() && data.subject.is_none() {
                                continue;
                            }

                            self.close_active_text_segment(&mut active_text, &mut text_segments, "finish")
                                .await;
                            if !first_visible_output_logged && !data.content.is_empty() {
                                first_visible_output_logged = true;
                                info!(
                                    target: "qianji_feedback_diagnostics",
                                    diagnostic_event = "feedback.runtime.turn_first_visible_output",
                                    conversation_id = %self.conversation_id,
                                    turn_id = %self.turn_id,
                                    msg_id = %self.msg_id,
                                    event_type = "Thinking",
                                    elapsed_ms = now_ms().saturating_sub(started_at),
                                    "feedback.runtime.turn_first_visible_output"
                                );
                            }
                            if !data.content.is_empty() {
                                attempt.saw_visible_output = true;
                            }

                            let segment = active_thinking.get_or_insert_with(|| ThinkingSegmentState {
                                id: Self::mint_segment_msg_id(&mut used_primary_segment_msg_id, &self.msg_id),
                                buffer: String::new(),
                                started_at: now_ms(),
                            });
                            segment.buffer.push_str(&data.content);
                            self.forward_to_websocket_with_msg_id(&segment.id, &event);
                        }
                        AgentStreamEvent::Text(data) => {
                            self.complete_active_thinking(&mut active_thinking).await;
                            if !first_visible_output_logged && !data.content.is_empty() {
                                first_visible_output_logged = true;
                                info!(
                                    target: "qianji_feedback_diagnostics",
                                    diagnostic_event = "feedback.runtime.turn_first_visible_output",
                                    conversation_id = %self.conversation_id,
                                    turn_id = %self.turn_id,
                                    msg_id = %self.msg_id,
                                    event_type = "Text",
                                    elapsed_ms = now_ms().saturating_sub(started_at),
                                    "feedback.runtime.turn_first_visible_output"
                                );
                            }
                            if !data.content.is_empty() {
                                attempt.saw_visible_output = true;
                            }

                            let segment = active_text.get_or_insert_with(|| TextSegmentState {
                                id: Self::mint_segment_msg_id(&mut used_primary_segment_msg_id, &self.msg_id),
                                buffer: String::new(),
                                created_at: now_ms(),
                                record_created: false,
                                flush_counter: 0,
                            });
                            self.forward_to_websocket_with_msg_id(&segment.id, &event);
                            segment.buffer.push_str(&data.content);
                            full_text_buffer.push_str(&data.content);
                            segment.flush_counter += 1;
                            if segment.flush_counter >= FLUSH_INTERVAL {
                                self.adapter.flush_text_segment(segment).await;
                                segment.flush_counter = 0;
                            }
                        }
                        AgentStreamEvent::Finish(_) | AgentStreamEvent::Error(_) => {
                            let elapsed_ms = now_ms() - started_at;
                            let event_type = if matches!(event, AgentStreamEvent::Finish(_)) {
                                "Finish"
                            } else {
                                "Error"
                            };
                            let terminal = Self::terminal_from_event(&event);
                            info!(
                                target: "qianji_feedback_diagnostics",
                                diagnostic_event = "feedback.runtime.turn_terminal",
                                conversation_id = %self.conversation_id,
                                turn_id = %self.turn_id,
                                msg_id = %self.msg_id,
                                event_type = %event_type,
                                elapsed_ms,
                                text_len = full_text_buffer.len(),
                                error_code = ?terminal.code(),
                                retryable = ?terminal.retryable(),
                                saw_visible_output = attempt.saw_visible_output,
                                saw_tool_or_side_effect = attempt.saw_tool_or_side_effect,
                                persisted_assistant_output = !full_text_buffer.is_empty(),
                                "feedback.runtime.turn_terminal"
                            );

                            let defer_clean_error = self.defer_clean_terminal_errors
                                && matches!(
                                    terminal,
                                    RelayTerminal::Error {
                                        retryable: Some(true),
                                        ..
                                    }
                                )
                                && terminal.code() != Some(AgentErrorCode::UserLlmProviderModelNotFound)
                                && attempt.safe_to_auto_replay();

                            if defer_clean_error {
                                if let AgentStreamEvent::Error(data) = &event {
                                    attempt.terminal_error = Some(data.clone());
                                    attempt.terminal_error_deferred = true;
                                }
                                info!(
                                    event_type,
                                    elapsed_ms, "StreamRelay deferred clean terminal error for possible auto replay"
                                );
                                break RelayOutcome {
                                    system_responses: Vec::new(),
                                    terminal,
                                    attempt,
                                };
                            }

                            if deleting {
                                debug!("Skipping terminal DB finalization because conversation is deleting");
                            } else {
                                self.complete_active_thinking(&mut active_thinking).await;
                                self.close_active_text_segment(
                                    &mut active_text,
                                    &mut text_segments,
                                    if matches!(event, AgentStreamEvent::Error(_)) {
                                        "error"
                                    } else {
                                        "finish"
                                    },
                                )
                                .await;
                            }
                            self.forward_to_websocket(&event);
                            if let AgentStreamEvent::Error(data) = &event {
                                attempt.terminal_error = Some(data.clone());
                            }
                            let mut outcome = if deleting {
                                RelayOutcome {
                                    system_responses: Vec::new(),
                                    terminal,
                                    attempt: attempt.clone(),
                                }
                            } else {
                                self.finalize(&full_text_buffer, &text_segments, &event, terminal).await
                            };
                            outcome.attempt = attempt.clone();
                            if !full_text_buffer.is_empty() {
                                outcome.attempt.persisted_assistant_output = true;
                            }
                            if self.complete_turn && !deleting {
                                self.adapter
                                    .complete_conversation(&self.broadcaster, &self.turn_id, None)
                                    .await;
                            }
                            break outcome;
                        }
                        AgentStreamEvent::ToolCall(data) => {
                            attempt.saw_tool_or_side_effect = true;
                            self.complete_active_thinking(&mut active_thinking).await;
                            self.close_active_text_segment(&mut active_text, &mut text_segments, "finish")
                                .await;
                            self.forward_to_websocket(&event);
                            self.adapter.persist_tool_call(data).await;
                        }
                        AgentStreamEvent::AcpToolCall(data) => {
                            attempt.saw_tool_or_side_effect = true;
                            self.complete_active_thinking(&mut active_thinking).await;
                            self.close_active_text_segment(&mut active_text, &mut text_segments, "finish")
                                .await;
                            self.forward_to_websocket(&event);
                            self.adapter.persist_acp_tool_call(data).await;
                        }
                        AgentStreamEvent::ToolGroup(entries) => {
                            attempt.saw_tool_or_side_effect = true;
                            self.complete_active_thinking(&mut active_thinking).await;
                            self.close_active_text_segment(&mut active_text, &mut text_segments, "finish")
                                .await;
                            self.forward_to_websocket(&event);
                            self.adapter.persist_tool_group(entries).await;
                        }
                        AgentStreamEvent::WorkflowProgress(data) if data.settle_only => {
                            // Update-only settle for a card this pump never
                            // opened (post-resume terminal). Forward ONLY if the
                            // stored row existed — otherwise the frontend would
                            // append a junk nameless card for a workflow-internal
                            // ref that never had one.
                            if self.adapter.settle_tool_call_if_present(&data.card).await {
                                self.forward_workflow_progress(data);
                            }
                        }
                        AgentStreamEvent::WorkflowProgress(data) => {
                            // A running workflow refreshes its progress roughly once a
                            // second, WHILE the assistant is still streaming its "workflow
                            // started" reply (claude runs with --include-partial-messages,
                            // so that reply arrives as deltas). Every other tool-ish arm
                            // above closes the active text segment first — doing that here
                            // would shatter that one reply into a fresh bubble per refresh.
                            //
                            // So this arm deliberately does NOT touch `active_text` /
                            // `active_thinking`. It projects the snapshot into the two
                            // frames the frontend already renders and persists them, and
                            // is otherwise invisible to the turn: no `saw_tool_or_side_effect`
                            // either, since a progress refresh is not the turn doing work.
                            self.forward_workflow_progress(data);
                            self.adapter.persist_tool_call(&data.card).await;
                            if !data.agents.is_empty() {
                                self.adapter.persist_tool_group(&data.agents).await;
                            }
                        }
                        AgentStreamEvent::Tips(data) => {
                            // Only a Success tip blocks auto-replay: it can represent
                            // completed work product. Warning/Info tips are system
                            // diagnostics (e.g. codex rejecting a mode seed against a
                            // dead thread, ELECTRON-3Q0) — counting them as visible
                            // output made every such failed attempt "unsafe to
                            // replay", so the transparent dead-anchor recovery never
                            // fired on cron turns.
                            if matches!(data.tip_type, TipType::Success) {
                                attempt.saw_visible_output = true;
                            }
                            if data.code.as_deref() == Some("ACP_EMPTY_TURN_NEEDS_AUTH") {
                                attempt.needs_auth = true;
                            }
                            // A card that supersedes itself gets this turn's
                            // running totals before it goes anywhere, so the
                            // live frame and the persisted row agree.
                            let annotated = self.superseding_tips.annotate(data, now_ms());
                            let forwarded = match &annotated {
                                Some(data) => std::borrow::Cow::Owned(AgentStreamEvent::Tips(data.clone())),
                                None => std::borrow::Cow::Borrowed(&event),
                            };
                            self.forward_to_websocket(&forwarded);
                            if matches!(data.tip_type, TipType::Success | TipType::Warning | TipType::Info) {
                                self.adapter.persist_tip(annotated.as_ref().unwrap_or(data)).await;
                            }
                        }
                        AgentStreamEvent::CronTrigger(_)
                        | AgentStreamEvent::Permission(_)
                        | AgentStreamEvent::AcpPermission(_)
                        // Ask rides the permission lane: a raised question is a
                        // side-effect (blocks auto-replay) and must reach the ws
                        // live for the card to pop mid-turn.
                        | AgentStreamEvent::Ask(_) => {
                            attempt.saw_tool_or_side_effect = true;
                            self.forward_to_websocket(&event);
                        }
                        AgentStreamEvent::MessageLifecycle(_) => {
                            // Internal-only correlation frame (mid-turn interjection
                            // Task 3): consumed by the BackgroundStreamWatcher between
                            // turns; inside a turn it is pure bookkeeping. Never
                            // forwarded to the WebSocket.
                        }
                        // Agent session titles. The BackgroundStreamWatcher is the
                        // between-turns consumer, but while it lends its receiver to
                        // an orphan-turn relay THIS relay is the only consumer — live
                        // 2026-08-19 (conv a7f2838a): claude's generate_session_title
                        // reply landed 0.6s after a CLI-initiated turn opened, the
                        // frame was dropped here, and the one-shot latch was already
                        // completed (no retry) — the placeholder name stuck forever.
                        // apply_agent_title is idempotent (same-title no-op) and
                        // name_source-guarded, so watcher+relay double-apply is safe.
                        AgentStreamEvent::AcpSessionInfo(payload) => {
                            if let Some(title) = payload
                                .get("title")
                                .and_then(serde_json::Value::as_str)
                                .map(str::trim)
                                .filter(|t| !t.is_empty())
                                && let Err(e) = crate::service::apply_agent_title(
                                    &self.repo,
                                    &self.broadcaster,
                                    &self.user_id,
                                    &self.conversation_id,
                                    title,
                                    "relay",
                                )
                                .await
                            {
                                warn!(
                                    conversation_id = %self.conversation_id,
                                    error = %e,
                                    "agent session title apply failed (relay)"
                                );
                            }
                            // The raw frame still reaches the frontend via message.stream.
                            self.forward_to_websocket(&event);
                        }
                        AgentStreamEvent::Plan(data) => {
                            // A plan is a side-channel SNAPSHOT, not turn work. It
                            // deliberately does NOT set `saw_tool_or_side_effect` (that
                            // would make an otherwise-replayable turn look unsafe to
                            // retry) and does NOT close the active text segment — a plan
                            // refresh lands mid-reply and would otherwise shatter that
                            // reply into a fresh bubble, the same reasoning as the
                            // WorkflowProgress arm above.
                            self.forward_to_websocket(&event);
                            self.adapter.persist_plan(data, &self.turn_id).await;
                        }
                        _ => {
                            self.forward_to_websocket(&event);
                        }
                    }
                }
                Err(broadcast::error::RecvError::Closed) => {
                    let elapsed_ms = now_ms() - started_at;
                    warn!(
                        target: "qianji_feedback_diagnostics",
                        diagnostic_event = "feedback.runtime.turn_terminal",
                        conversation_id = %self.conversation_id,
                        turn_id = %self.turn_id,
                        msg_id = %self.msg_id,
                        event_type = "ChannelClosed",
                        elapsed_ms,
                        text_len = full_text_buffer.len(),
                        error_code = ?RelayTerminal::ChannelClosed.code(),
                        retryable = ?RelayTerminal::ChannelClosed.retryable(),
                        saw_visible_output = attempt.saw_visible_output,
                        saw_tool_or_side_effect = attempt.saw_tool_or_side_effect,
                        persisted_assistant_output = !full_text_buffer.is_empty(),
                        "feedback.runtime.turn_terminal"
                    );

                    let deleting = self.is_deleting();
                    if deleting {
                        debug!("Skipping channel-closed DB finalization because conversation is deleting");
                    } else {
                        self.complete_active_thinking(&mut active_thinking).await;
                        self.close_active_text_segment(&mut active_text, &mut text_segments, "finish")
                            .await;
                    }
                    // Channel closed without finish/error — still finalize
                    let mut outcome = if deleting {
                        RelayOutcome {
                            system_responses: Vec::new(),
                            terminal: RelayTerminal::ChannelClosed,
                            attempt: attempt.clone(),
                        }
                    } else {
                        self.finalize(
                            &full_text_buffer,
                            &text_segments,
                            &AgentStreamEvent::Finish(qianji_ai_agent::protocol::events::FinishEventData::default()),
                            RelayTerminal::ChannelClosed,
                        )
                        .await
                    };
                    outcome.attempt = attempt.clone();
                    if !full_text_buffer.is_empty() {
                        outcome.attempt.persisted_assistant_output = true;
                    }
                    if self.complete_turn && !deleting {
                        self.adapter
                            .complete_conversation(&self.broadcaster, &self.turn_id, None)
                            .await;
                    }
                    break outcome;
                }
                Err(broadcast::error::RecvError::Lagged(n)) => {
                    warn!(lagged = n, "Stream relay lagged, some events dropped");
                }
            }
        }
    }

    fn is_deleting(&self) -> bool {
        self.runtime_state
            .as_ref()
            .is_some_and(|state| state.is_deleting(&self.conversation_id))
    }

    fn event_kind(event: &AgentStreamEvent) -> &'static str {
        match event {
            AgentStreamEvent::Start(_) => "Start",
            AgentStreamEvent::Text(_) => "Text",
            AgentStreamEvent::Tips(_) => "Tips",
            AgentStreamEvent::Thinking(_) => "Thinking",
            AgentStreamEvent::ToolCall(_) => "ToolCall",
            AgentStreamEvent::AcpToolCall(_) => "AcpToolCall",
            AgentStreamEvent::ToolGroup(_) => "ToolGroup",
            AgentStreamEvent::AgentStatus(_) => "AgentStatus",
            AgentStreamEvent::Plan(_) => "Plan",
            AgentStreamEvent::Permission(_) => "Permission",
            AgentStreamEvent::AcpPermission(_) => "AcpPermission",
            AgentStreamEvent::Ask(_) => "Ask",
            AgentStreamEvent::SkillSuggest(_) => "SkillSuggest",
            AgentStreamEvent::CronTrigger(_) => "CronTrigger",
            AgentStreamEvent::AcpModelInfo(_) => "AcpModelInfo",
            AgentStreamEvent::AcpModeInfo(_) => "AcpModeInfo",
            AgentStreamEvent::AcpConfigOption(_) => "AcpConfigOption",
            AgentStreamEvent::AcpSessionInfo(_) => "AcpSessionInfo",
            AgentStreamEvent::AcpContextUsage(_) => "AcpContextUsage",
            AgentStreamEvent::AcpTerminalOutput(_) => "AcpTerminalOutput",
            AgentStreamEvent::AcpPromptHookWarning(_) => "AcpPromptHookWarning",
            AgentStreamEvent::SlashCommandsUpdated(_) => "SlashCommandsUpdated",
            AgentStreamEvent::AvailableCommands(_) => "AvailableCommands",
            AgentStreamEvent::Finish(_) => "Finish",
            AgentStreamEvent::Error(_) => "Error",
            AgentStreamEvent::System(_) => "System",
            AgentStreamEvent::RequestTrace(_) => "RequestTrace",
            AgentStreamEvent::SessionAssigned(_) => "SessionAssigned",
            AgentStreamEvent::SegmentBreak => "SegmentBreak",
            AgentStreamEvent::BackendTurnBound(_) => "BackendTurnBound",
            AgentStreamEvent::WorkflowProgress(_) => "WorkflowProgress",
            AgentStreamEvent::AcpDialectSignal(_) => "AcpDialectSignal",
            AgentStreamEvent::MessageLifecycle(_) => "MessageLifecycle",
        }
    }

    fn terminal_from_event(event: &AgentStreamEvent) -> RelayTerminal {
        match event {
            AgentStreamEvent::Error(data) => RelayTerminal::Error {
                code: data.code,
                retryable: data.retryable,
            },
            AgentStreamEvent::Finish(_) => RelayTerminal::Finish,
            _ => RelayTerminal::ChannelClosed,
        }
    }

    fn mint_segment_msg_id(used_primary: &mut bool, primary_msg_id: &str) -> String {
        if !*used_primary {
            *used_primary = true;
            primary_msg_id.to_owned()
        } else {
            ConversationService::mint_msg_id()
        }
    }

    /// Forward an agent event to connected WebSocket clients.
    #[tracing::instrument(skip_all)]
    fn forward_to_websocket(&self, event: &AgentStreamEvent) {
        self.forward_to_websocket_with_msg_id(&self.msg_id, event);
    }

    #[tracing::instrument(skip_all)]
    fn forward_to_websocket_with_msg_id(&self, msg_id: &str, event: &AgentStreamEvent) {
        let mut event_data = match serde_json::to_value(event) {
            Ok(v) => v,
            Err(e) => {
                warn!(error = %ErrorChain(&e), "Failed to serialize agent event for WebSocket");
                return;
            }
        };
        // Nested ACP SDK payloads serialise as camelCase on their own;
        // force every object key down the tree to snake_case so the
        // wire contract stays uniform.
        normalize_keys_to_snake_case(&mut event_data);

        let payload = json!({
            "conversation_id": self.conversation_id,
            "msg_id": msg_id,
            "turn_id": self.turn_id,
            "type": event_data.get("type").cloned().unwrap_or(json!("unknown")),
            "data": event_data.get("data").cloned().unwrap_or(json!({})),
            "hidden": false,
        });

        self.broadcast_stream_payload(payload);
    }

    /// Finalize assistant text on stream end and apply middleware rewrites.
    #[tracing::instrument(skip_all)]
    async fn finalize(
        &self,
        text: &str,
        text_segments: &[PersistedTextSegment],
        event: &AgentStreamEvent,
        terminal: RelayTerminal,
    ) -> RelayOutcome {
        let mut outcome = RelayOutcome {
            system_responses: Vec::new(),
            terminal,
            attempt: TurnAttemptSummary::default(),
        };
        let status = match event {
            AgentStreamEvent::Error(_) => "error",
            _ => "finish",
        };

        if !text.is_empty() {
            let processed = self.process_final_text(text).await;
            let final_text = processed.message.trim().to_owned();
            let hidden = final_text.is_empty();

            let rewrite_segments = processed.message != text || hidden;
            let overrides = self
                .adapter
                .persist_final_text(text_segments, status, &final_text, hidden, rewrite_segments)
                .await;
            for override_event in overrides {
                self.send_final_text_override(&override_event.msg_id, &override_event.text, override_event.hidden);
            }

            self.send_system_responses(&processed.system_responses);
            outcome.system_responses = processed.system_responses;
        } else if let AgentStreamEvent::Error(data) = event {
            self.adapter.persist_error_tip(data).await;
        }

        outcome
    }

    #[tracing::instrument(skip_all)]
    async fn complete_active_thinking(&self, active_thinking: &mut Option<ThinkingSegmentState>) {
        let Some(segment) = active_thinking.take() else {
            return;
        };
        let duration_ms = (now_ms() - segment.started_at).max(0);
        self.send_thinking_done(&segment.id, duration_ms as u64);
        self.adapter.persist_thinking_segment(segment, duration_ms as u64).await;
    }

    #[tracing::instrument(skip_all)]
    async fn close_active_text_segment(
        &self,
        active_text: &mut Option<TextSegmentState>,
        text_segments: &mut Vec<PersistedTextSegment>,
        status: &str,
    ) {
        let Some(text_segment) = active_text.take() else {
            return;
        };
        if let Some(segment) = self.adapter.finalize_text_segment(text_segment, status).await {
            text_segments.push(segment);
        }
    }

    /// Send a `thinking` event with `status: "done"` to close the thinking UI.
    fn send_thinking_done(&self, msg_id: &str, duration: u64) {
        let thinking_done = AgentStreamEvent::Thinking(ThinkingEventData {
            content: String::new(),
            subject: None,
            duration: Some(duration),
            status: Some("done".into()),
        });
        self.forward_to_websocket_with_msg_id(msg_id, &thinking_done);
    }

    async fn process_final_text(&self, text: &str) -> MiddlewareResult {
        let middleware = MessageMiddleware::new_with_skill_loader(self.skill_resolver.as_ref().map(|resolver| {
            Box::new(SharedSkillResolver {
                resolver: Arc::clone(resolver),
                user_id: self.user_id.clone(),
                allowed_skill_names: self.allowed_skill_names.clone(),
            }) as Box<dyn ISkillLoadService>
        }));

        middleware.process(text, &self.user_id, &self.conversation_id).await
    }

    fn send_final_text_override(&self, msg_id: &str, text: &str, hidden: bool) {
        self.broadcast_stream_payload(json!({
            "conversation_id": self.conversation_id,
            "msg_id": msg_id,
            "turn_id": self.turn_id,
            "type": "content",
            "data": { "content": text },
            "hidden": hidden,
            "replace": true,
        }));
    }

    fn send_system_responses(&self, responses: &[String]) {
        for response in responses {
            self.broadcast_stream_payload(json!({
                "conversation_id": self.conversation_id,
                "msg_id": ConversationService::mint_msg_id(),
                "turn_id": self.turn_id,
                "type": "system",
                "data": response,
                "hidden": true,
            }));
        }
    }

    /// Project a workflow snapshot onto the wire as the two frame types the
    /// frontend already renders, so no new renderer is needed:
    ///
    /// - `tool_call` — the container row, keyed by the Workflow tool call's own
    ///   `call_id`, so it updates the card the user is already looking at.
    /// - `tool_group` — one entry per workflow agent, each with its own status
    ///   badge.
    ///
    /// Hand-built rather than routed through `forward_to_websocket`, which derives
    /// the wire `type` from the event's own serde tag — that would put
    /// `workflow_progress` on the wire, which no frontend arm handles (it would
    /// land in `useAcpMessage`'s `default:` and light a spurious turn timer).
    fn forward_workflow_progress(&self, data: &qianji_ai_agent::protocol::events::WorkflowProgressData) {
        let mut frames = vec![("tool_call", serde_json::to_value(&data.card))];
        // A background-task card has no per-agent roster; an EMPTY tool_group
        // would persist a junk row under a freshly minted id.
        if !data.agents.is_empty() {
            frames.push(("tool_group", serde_json::to_value(&data.agents)));
        }
        for (kind, body) in frames {
            let mut body = match body {
                Ok(v) => v,
                Err(e) => {
                    warn!(error = %ErrorChain(&e), kind, "Failed to serialize workflow progress frame");
                    continue;
                }
            };
            normalize_keys_to_snake_case(&mut body);
            self.broadcast_stream_payload(json!({
                "conversation_id": self.conversation_id,
                "msg_id": self.msg_id,
                "turn_id": self.turn_id,
                "type": kind,
                "data": body,
                "hidden": false,
            }));
        }
    }

    fn broadcast_stream_payload(&self, mut payload: serde_json::Value) {
        if let Some(obj) = payload.as_object_mut() {
            obj.entry("user_id")
                .or_insert_with(|| serde_json::Value::String(self.user_id.clone()));
            obj.entry("turn_id")
                .or_insert_with(|| serde_json::Value::String(self.turn_id.clone()));
            // Fork anchoring parity with persistence: live frames carry the
            // backend turn anchor so the UI can show mid-history fork entries
            // during the session, not only after a history reload.
            if let Some(anchor) = self.adapter.current_backend_turn_id() {
                obj.entry("backend_turn_id")
                    .or_insert_with(|| serde_json::Value::String(anchor));
            }
        }
        let msg = WebSocketMessage::new("message.stream", payload);
        self.broadcaster.broadcast(msg);
    }
}

struct SharedSkillResolver {
    resolver: Arc<dyn SkillResolver>,
    user_id: String,
    allowed_skill_names: Vec<String>,
}

#[async_trait::async_trait]
impl ISkillLoadService for SharedSkillResolver {
    async fn load_skill_bodies(&self, names: &[String]) -> Vec<LoadedAgentSkill> {
        if self.allowed_skill_names.is_empty() {
            return Vec::new();
        }
        let filtered: Vec<String> = names
            .iter()
            .filter(|name| self.allowed_skill_names.iter().any(|allowed| allowed == *name))
            .cloned()
            .collect();
        self.resolver.load_skill_bodies_for_user(&self.user_id, &filtered).await
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::stream_persistence::StreamPersistenceAdapter;
    use qianji_ai_agent::AgentError;
    use qianji_ai_agent::protocol::events::{ErrorEventData, FinishEventData, TextEventData, ThinkingEventData};
    use qianji_db::DbError;
    use qianji_db::models::MessageRow;
    use std::io::Write;
    use std::sync::Mutex;
    use std::sync::atomic::{AtomicBool, Ordering};
    use tracing::Level;
    use tracing_subscriber::fmt;

    // ── run() async tests ─────────────────────────────────────────

    #[derive(Clone)]
    struct SharedLogBuffer(Arc<Mutex<Vec<u8>>>);

    impl Write for SharedLogBuffer {
        fn write(&mut self, buf: &[u8]) -> std::io::Result<usize> {
            self.0.lock().expect("log buffer lock").extend_from_slice(buf);
            Ok(buf.len())
        }

        fn flush(&mut self) -> std::io::Result<()> {
            Ok(())
        }
    }

    fn capture_logs(level: Level, f: impl FnOnce()) -> String {
        let buffer = Arc::new(Mutex::new(Vec::<u8>::new()));
        let make_writer = {
            let buffer = Arc::clone(&buffer);
            move || SharedLogBuffer(Arc::clone(&buffer))
        };
        let subscriber = fmt::Subscriber::builder()
            .with_max_level(level)
            .with_writer(make_writer)
            .with_ansi(false)
            .finish();

        tracing::subscriber::with_default(subscriber, f);
        String::from_utf8(buffer.lock().expect("log buffer lock").clone()).expect("utf8 logs")
    }

    #[derive(Default)]
    struct RecordingSkillResolverForRelay {
        requested: Mutex<Vec<String>>,
        requested_user_ids: Mutex<Vec<String>>,
    }

    #[async_trait::async_trait]
    impl SkillResolver for RecordingSkillResolverForRelay {
        async fn auto_inject_names(&self) -> Vec<String> {
            Vec::new()
        }

        async fn resolve_skills(&self, _names: &[String]) -> Vec<qianji_extension::ResolvedAgentSkill> {
            Vec::new()
        }

        async fn load_skill_bodies_for_user(&self, user_id: &str, names: &[String]) -> Vec<LoadedAgentSkill> {
            self.requested_user_ids.lock().unwrap().push(user_id.to_owned());
            self.requested.lock().unwrap().extend(names.iter().cloned());
            names
                .iter()
                .map(|name| LoadedAgentSkill {
                    name: name.clone(),
                    body: format!("{name} body"),
                    source_path: std::path::PathBuf::from(format!("/src/{name}")),
                })
                .collect()
        }
    }

    #[tokio::test]
    async fn shared_skill_resolver_filters_requests_to_allowed_skill_names() {
        let concrete = Arc::new(RecordingSkillResolverForRelay::default());
        let resolver: Arc<dyn SkillResolver> = concrete.clone();
        let loader = SharedSkillResolver {
            resolver,
            user_id: "system_default_user".into(),
            allowed_skill_names: vec!["cron".into()],
        };

        let loaded = loader.load_skill_bodies(&["cron".to_owned(), "pdf".to_owned()]).await;

        assert_eq!(loaded.len(), 1);
        assert_eq!(loaded[0].name, "cron");
        assert_eq!(concrete.requested.lock().unwrap().as_slice(), ["cron"]);
        assert_eq!(
            concrete.requested_user_ids.lock().unwrap().as_slice(),
            ["system_default_user"]
        );
    }

    #[tokio::test]
    async fn run_text_then_finish_persists_message() {
        let repo = Arc::new(RecordingRepo::new());
        let bus = Arc::new(qianji_realtime::BroadcastEventBus::new(64));
        let (tx, _) = broadcast::channel(64);

        let relay = StreamRelay::new(
            "conv-1".into(),
            "asst-1".into(),
            "turn-1".into(),
            "user-1".into(),
            repo.clone(),
            bus.clone(),
        );

        let rx = tx.subscribe();

        // Send text events then finish
        tx.send(AgentStreamEvent::Text(TextEventData {
            content: "Hello ".into(),
        }))
        .unwrap();
        tx.send(AgentStreamEvent::Text(TextEventData {
            content: "World".into(),
        }))
        .unwrap();
        tx.send(AgentStreamEvent::Finish(FinishEventData::default())).unwrap();

        let outcome = relay.consume(rx).await;
        assert!(outcome.system_responses.is_empty());
        assert_eq!(outcome.terminal, RelayTerminal::Finish);

        // Should have inserted a message with accumulated text
        let inserts = repo.take_inserts();
        assert_eq!(inserts.len(), 1);
        let msg = &inserts[0];
        assert_eq!(msg.conversation_id, "conv-1");
        assert_eq!(msg.id, "asst-1");
        assert_eq!(msg.r#type, "text");
        assert_eq!(msg.status.as_deref(), Some("finish"));

        let content: serde_json::Value = serde_json::from_str(&msg.content).unwrap();
        assert_eq!(content["content"], "Hello World");
    }

    fn agent_title_test_row(name: &str, name_source: Option<&str>) -> qianji_db::models::ConversationRow {
        let now = qianji_common::now_ms();
        qianji_db::models::ConversationRow {
            id: "conv-1".into(),
            user_id: "user-1".into(),
            name: name.into(),
            r#type: "acp".into(),
            extra: "{}".into(),
            model: None,
            status: None,
            source: None,
            channel_chat_id: None,
            pinned: false,
            pinned_at: None,
            created_at: now,
            updated_at: now,
            project_id: None,
            folder_id: None,
            name_source: name_source.map(str::to_owned),
        }
    }

    /// Live 2026-08-19 (conv a7f2838a): claude's `generate_session_title` reply
    /// landed 0.6s after the BackgroundStreamWatcher lent its receiver to a
    /// CLI-initiated orphan turn — the relay was the ONLY consumer of the title
    /// frame and dropped it, and the one-shot latch was already completed, so
    /// the conversation kept its placeholder name forever. The relay must apply
    /// titles itself (apply_agent_title is idempotent and name_source-guarded,
    /// so watcher+relay double-apply is a harmless no-op).
    #[tokio::test]
    async fn acp_session_info_applies_agent_title_at_relay_level() {
        let repo = Arc::new(RecordingRepo::new());
        *repo.conversation.lock().unwrap() = Some(agent_title_test_row("first message placeholder", None));
        let bus = Arc::new(qianji_realtime::BroadcastEventBus::new(64));
        let mut ws_rx = bus.subscribe();
        let (tx, _) = broadcast::channel(64);

        let relay = StreamRelay::new(
            "conv-1".into(),
            "asst-1".into(),
            "turn-1".into(),
            "user-1".into(),
            repo.clone(),
            bus.clone(),
        );
        let rx = tx.subscribe();
        tx.send(AgentStreamEvent::AcpSessionInfo(serde_json::json!({
            "title": "Fix login bug"
        })))
        .unwrap();
        tx.send(AgentStreamEvent::Finish(FinishEventData::default())).unwrap();
        let outcome = relay.consume(rx).await;
        assert_eq!(outcome.terminal, RelayTerminal::Finish);

        let renamed = repo.conversation_updates.lock().unwrap().iter().any(|(id, u)| {
            id == "conv-1" && u.name.as_deref() == Some("Fix login bug") && u.name_source.as_deref() == Some("agent")
        });
        assert!(
            renamed,
            "relay must apply the agent title (rename + name_source='agent')"
        );
        // The raw frame still reaches the frontend via message.stream.
        let mut saw_forward = false;
        while let Ok(msg) = ws_rx.try_recv() {
            if msg.name == "message.stream" && msg.data["data"]["title"] == "Fix login bug" {
                saw_forward = true;
            }
        }
        assert!(saw_forward, "AcpSessionInfo frame must still be forwarded");
    }

    #[tokio::test]
    async fn acp_session_info_never_renames_user_owned_name() {
        let repo = Arc::new(RecordingRepo::new());
        *repo.conversation.lock().unwrap() = Some(agent_title_test_row("my name", Some("user")));
        let bus = Arc::new(qianji_realtime::BroadcastEventBus::new(64));
        let (tx, _) = broadcast::channel(64);

        let relay = StreamRelay::new(
            "conv-1".into(),
            "asst-1".into(),
            "turn-1".into(),
            "user-1".into(),
            repo.clone(),
            bus.clone(),
        );
        let rx = tx.subscribe();
        tx.send(AgentStreamEvent::AcpSessionInfo(serde_json::json!({
            "title": "Fix login bug"
        })))
        .unwrap();
        tx.send(AgentStreamEvent::Finish(FinishEventData::default())).unwrap();
        relay.consume(rx).await;

        assert!(
            repo.conversation_updates
                .lock()
                .unwrap()
                .iter()
                .all(|(_, u)| u.name.is_none()),
            "a user-owned name must never be overwritten by an agent title"
        );
    }

    #[tokio::test]
    async fn acp_session_info_null_title_never_renames() {
        let repo = Arc::new(RecordingRepo::new());
        *repo.conversation.lock().unwrap() = Some(agent_title_test_row("kept name", None));
        let bus = Arc::new(qianji_realtime::BroadcastEventBus::new(64));
        let (tx, _) = broadcast::channel(64);

        let relay = StreamRelay::new(
            "conv-1".into(),
            "asst-1".into(),
            "turn-1".into(),
            "user-1".into(),
            repo.clone(),
            bus.clone(),
        );
        let rx = tx.subscribe();
        tx.send(AgentStreamEvent::AcpSessionInfo(serde_json::json!({ "title": null })))
            .unwrap();
        tx.send(AgentStreamEvent::AcpSessionInfo(serde_json::json!({ "title": "   " })))
            .unwrap();
        tx.send(AgentStreamEvent::Finish(FinishEventData::default())).unwrap();
        relay.consume(rx).await;

        assert!(
            repo.conversation_updates
                .lock()
                .unwrap()
                .iter()
                .all(|(_, u)| u.name.is_none()),
            "null/blank titles must not rename"
        );
    }

    #[tokio::test]
    async fn needs_auth_tip_sets_summary_flag_on_finish() {
        use qianji_ai_agent::protocol::events::{TipType, TipsEventData};

        let repo = Arc::new(RecordingRepo::new());
        let bus = Arc::new(qianji_realtime::BroadcastEventBus::new(64));
        let (tx, _) = broadcast::channel(64);
        let relay = StreamRelay::new(
            "conv-1".into(),
            "asst-1".into(),
            "turn-1".into(),
            "user-1".into(),
            repo.clone(),
            bus.clone(),
        );
        let rx = tx.subscribe();

        // An agent that connected but isn't signed in: needs-auth tip, then a
        // benign end_turn (Finish). Terminal stays non-error, but the summary
        // must flag needs_auth so the orchestrator can reflect it into availability.
        tx.send(AgentStreamEvent::Tips(TipsEventData {
            content: String::new(),
            tip_type: TipType::Info,
            code: Some("ACP_EMPTY_TURN_NEEDS_AUTH".into()),
            params: Some(serde_json::json!({ "hint": "Run `kilo auth login` in the terminal" })),
            supersedes_key: None,
        }))
        .unwrap();
        tx.send(AgentStreamEvent::Finish(FinishEventData::default())).unwrap();

        let outcome = relay.consume(rx).await;
        assert_eq!(
            outcome.terminal,
            RelayTerminal::Finish,
            "needs-auth empty turn is a benign finish"
        );
        assert!(outcome.attempt.needs_auth, "needs-auth tip must set the summary flag");
    }

    #[tokio::test]
    async fn plain_empty_turn_tip_does_not_set_needs_auth() {
        use qianji_ai_agent::protocol::events::{TipType, TipsEventData};

        let repo = Arc::new(RecordingRepo::new());
        let bus = Arc::new(qianji_realtime::BroadcastEventBus::new(64));
        let (tx, _) = broadcast::channel(64);
        let relay = StreamRelay::new(
            "conv-1".into(),
            "asst-1".into(),
            "turn-1".into(),
            "user-1".into(),
            repo.clone(),
            bus.clone(),
        );
        let rx = tx.subscribe();

        tx.send(AgentStreamEvent::Tips(TipsEventData {
            content: String::new(),
            tip_type: TipType::Info,
            code: Some("ACP_EMPTY_TURN".into()),
            params: None,
            supersedes_key: None,
        }))
        .unwrap();
        tx.send(AgentStreamEvent::Finish(FinishEventData::default())).unwrap();

        let outcome = relay.consume(rx).await;
        assert!(
            !outcome.attempt.needs_auth,
            "a plain empty turn must NOT be treated as needs-auth"
        );
    }

    // issue 136586749 (F4): the new ACP_EMPTY_TURN_TOKEN_LIMIT tip is a
    // token/context-class outcome. It must NOT reflect needs-auth (which would
    // wrongly mark the agent unavailable), yet must still be forwarded + persisted
    // like any other Info tip. Guards the relay's needs-auth attribution.
    #[tokio::test]
    async fn token_limit_tip_does_not_set_needs_auth_and_is_forwarded() {
        use qianji_ai_agent::protocol::events::{TipType, TipsEventData};

        let repo = Arc::new(RecordingRepo::new());
        let bus = Arc::new(qianji_realtime::BroadcastEventBus::new(64));
        let mut ws_rx = bus.subscribe();
        let (tx, _) = broadcast::channel(64);
        let relay = StreamRelay::new(
            "conv-1".into(),
            "asst-1".into(),
            "turn-1".into(),
            "user-1".into(),
            repo.clone(),
            bus.clone(),
        );
        let rx = tx.subscribe();

        tx.send(AgentStreamEvent::Tips(TipsEventData {
            content: String::new(),
            tip_type: TipType::Info,
            code: Some("ACP_EMPTY_TURN_TOKEN_LIMIT".into()),
            params: None,
            supersedes_key: None,
        }))
        .unwrap();
        tx.send(AgentStreamEvent::Finish(FinishEventData::default())).unwrap();

        let outcome = relay.consume(rx).await;
        assert_eq!(outcome.terminal, RelayTerminal::Finish);
        assert!(
            !outcome.attempt.needs_auth,
            "a token-limit tip must NOT be reflected as needs-auth (contrast ACP_EMPTY_TURN_NEEDS_AUTH)"
        );

        let inserts = repo.take_inserts();
        assert!(
            inserts.iter().any(|m| m.r#type == "tips"),
            "the token-limit Info tip is persisted"
        );

        let mut saw_tip = false;
        while let Ok(evt) = ws_rx.try_recv() {
            if evt.name == "message.stream" && evt.data["type"] == "tips" {
                saw_tip |= evt.data["data"]["code"] == "ACP_EMPTY_TURN_TOKEN_LIMIT";
            }
        }
        assert!(saw_tip, "the token-limit tip must be forwarded to the WS");
    }

    /// A workflow refreshes its progress ~1×/s WHILE the assistant is still
    /// streaming its "workflow started" reply (claude runs with
    /// `--include-partial-messages`, so that reply arrives as deltas). Every other
    /// tool-ish arm closes the active text segment first, which would shatter that
    /// one reply into a fresh bubble per refresh — a worse regression than showing
    /// nothing at all. This arm must leave the text segment alone.
    ///
    /// The `ToolCall` control below proves the test actually exercises the
    /// splitting path, rather than passing because no split could occur anyway.
    #[tokio::test]
    async fn workflow_progress_does_not_split_the_streaming_reply() {
        use qianji_ai_agent::protocol::events::tool_call::{ToolGroupEntry, ToolGroupStatus};
        use qianji_ai_agent::protocol::events::{
            TextEventData, ToolCallEventData, ToolCallStatus, WorkflowProgressData,
        };

        async fn run_with(interruption: AgentStreamEvent) -> (Vec<MessageRow>, Vec<serde_json::Value>) {
            let repo = Arc::new(RecordingRepo::new());
            let bus = Arc::new(qianji_realtime::BroadcastEventBus::new(64));
            let mut ws_rx = bus.subscribe();
            let (tx, _) = broadcast::channel(64);
            let relay = StreamRelay::new(
                "conv-1".into(),
                "asst-1".into(),
                "turn-1".into(),
                "user-1".into(),
                repo.clone(),
                bus.clone(),
            );
            let rx = tx.subscribe();

            tx.send(AgentStreamEvent::Text(TextEventData {
                content: "Workflow started, ".into(),
            }))
            .unwrap();
            tx.send(interruption).unwrap();
            tx.send(AgentStreamEvent::Text(TextEventData {
                content: "running in the background.".into(),
            }))
            .unwrap();
            tx.send(AgentStreamEvent::Finish(FinishEventData::default())).unwrap();
            relay.consume(rx).await;

            let mut frames = Vec::new();
            while let Ok(evt) = ws_rx.try_recv() {
                if evt.name == "message.stream" {
                    frames.push(evt.data.clone());
                }
            }
            (repo.take_inserts(), frames)
        }

        fn progress_event() -> AgentStreamEvent {
            AgentStreamEvent::WorkflowProgress(WorkflowProgressData {
                card: ToolCallEventData {
                    call_id: "toolu_wf".into(),
                    name: "Workflow".into(),
                    args: serde_json::json!({"script": "phase('Run')"}),
                    status: ToolCallStatus::Running,
                    input: None,
                    output: Some("Phase 1  Run   [0/1]".into()),
                    description: Some("Run [0/1] · run:A · 1 agents".into()),
                    parent_call_id: None,
                },
                agents: vec![ToolGroupEntry {
                    call_id: "1".into(),
                    name: "run:A".into(),
                    status: ToolGroupStatus::Executing,
                    description: Some("[P1 Run] · opus-4-8".into()),
                }],
                settle_only: false,
            })
        }

        let (inserts, frames) = run_with(progress_event()).await;
        let texts = inserts.iter().filter(|m| m.r#type == "text").count();
        assert_eq!(
            texts, 1,
            "the streaming reply must stay ONE message; a progress refresh may not close its segment"
        );

        // Both projections must still reach the WS, under the frame types the
        // frontend already renders — never the internal `workflow_progress` tag.
        let kinds: Vec<&str> = frames.iter().filter_map(|f| f["type"].as_str()).collect();
        assert!(
            kinds.contains(&"tool_call"),
            "container row must be forwarded: {kinds:?}"
        );
        assert!(kinds.contains(&"tool_group"), "agent rows must be forwarded: {kinds:?}");
        assert!(
            !kinds.contains(&"workflow_progress"),
            "the internal variant must never hit the wire: {kinds:?}"
        );
        let card = frames.iter().find(|f| f["type"] == "tool_call").unwrap();
        assert_eq!(card["data"]["call_id"], "toolu_wf");
        assert_eq!(
            card["data"]["name"], "Workflow",
            "identity fields survive the projection"
        );
        let group = frames.iter().find(|f| f["type"] == "tool_group").unwrap();
        assert_eq!(
            group["data"][0]["status"], "Executing",
            "tool_group's PascalCase vocabulary"
        );

        // Control: a plain ToolCall DOES split the reply. Without this, the
        // assertion above could pass simply because nothing ever splits.
        let (control_inserts, _) = run_with(AgentStreamEvent::ToolCall(ToolCallEventData {
            call_id: "toolu_other".into(),
            name: "Bash".into(),
            args: serde_json::Value::Null,
            status: ToolCallStatus::Running,
            input: None,
            output: None,
            description: None,
            parent_call_id: None,
        }))
        .await;
        assert_eq!(
            control_inserts.iter().filter(|m| m.r#type == "text").count(),
            2,
            "control: an ordinary tool call splits the reply, so the test does exercise that path"
        );
    }

    // issue 136586749 (B-3): AcpDialectSignal is an internal-only turn/near-window
    // signal. Like SegmentBreak it must never reach the WS and must not persist.
    #[tokio::test]
    async fn acp_dialect_signal_is_not_forwarded_or_persisted() {
        use qianji_ai_agent::protocol::events::{AcpDialectSignalData, AcpDialectSignalKind};

        let repo = Arc::new(RecordingRepo::new());
        let bus = Arc::new(qianji_realtime::BroadcastEventBus::new(64));
        let mut ws_rx = bus.subscribe();
        let (tx, _) = broadcast::channel(64);
        let relay = StreamRelay::new(
            "conv-1".into(),
            "asst-1".into(),
            "turn-1".into(),
            "user-1".into(),
            repo.clone(),
            bus.clone(),
        );
        let rx = tx.subscribe();

        tx.send(AgentStreamEvent::AcpDialectSignal(AcpDialectSignalData {
            kind: AcpDialectSignalKind::TokenPressure,
        }))
        .unwrap();
        tx.send(AgentStreamEvent::Finish(FinishEventData::default())).unwrap();

        relay.consume(rx).await;

        let mut saw_dialect_frame = false;
        while let Ok(evt) = ws_rx.try_recv() {
            if evt.name == "message.stream" && evt.data["type"] == "acp_dialect_signal" {
                saw_dialect_frame = true;
            }
        }
        assert!(!saw_dialect_frame, "AcpDialectSignal must never be forwarded to the WS");
        assert!(
            repo.take_inserts().is_empty(),
            "AcpDialectSignal must not be persisted as a message"
        );
    }

    #[tokio::test]
    async fn run_text_tool_text_splits_text_segments() {
        use qianji_ai_agent::protocol::events::tool_call::{ToolCallEventData, ToolCallStatus};

        let repo = Arc::new(RecordingRepo::new());
        let bus = Arc::new(qianji_realtime::BroadcastEventBus::new(64));
        let (tx, _) = broadcast::channel(64);

        let relay = StreamRelay::new(
            "conv-1".into(),
            "asst-1".into(),
            "turn-1".into(),
            "user-1".into(),
            repo.clone(),
            bus.clone(),
        );

        let mut ws_rx = bus.subscribe();
        let rx = tx.subscribe();

        tx.send(AgentStreamEvent::Text(TextEventData {
            content: "Alpha".into(),
        }))
        .unwrap();
        tx.send(AgentStreamEvent::ToolCall(ToolCallEventData {
            call_id: "tc-001".into(),
            name: "read_file".into(),
            args: json!({"path": "a.ts"}),
            status: ToolCallStatus::Running,
            description: None,
            parent_call_id: None,
            input: None,
            output: None,
        }))
        .unwrap();
        tx.send(AgentStreamEvent::Text(TextEventData { content: "Beta".into() }))
            .unwrap();
        tx.send(AgentStreamEvent::Finish(FinishEventData::default())).unwrap();

        relay.consume(rx).await;

        let inserts = repo.take_inserts();
        let text_msgs: Vec<_> = inserts.iter().filter(|msg| msg.r#type == "text").collect();
        assert_eq!(text_msgs.len(), 2, "text should split across tool boundaries");
        assert_eq!(text_msgs[0].id, "asst-1");
        assert_ne!(text_msgs[0].id, text_msgs[1].id);

        let mut text_event_msg_ids = Vec::new();
        while let Ok(evt) = ws_rx.try_recv() {
            if evt.name == "message.stream" && (evt.data["type"] == "text" || evt.data["type"] == "content") {
                text_event_msg_ids.push(evt.data["msg_id"].as_str().unwrap_or_default().to_owned());
            }
        }
        assert_eq!(text_event_msg_ids.len(), 2);
        assert_eq!(text_event_msg_ids[0], "asst-1");
        assert_ne!(text_event_msg_ids[0], text_event_msg_ids[1]);
    }

    // A SegmentBreak (emitted by the direct-CLI pump when it suppresses a
    // non-blocking Workflow's launch result) must split text into two bubbles
    // just like a tool call does — but WITHOUT terminating the relay and
    // WITHOUT being forwarded to the WebSocket as its own frame.
    #[tokio::test]
    async fn segment_break_splits_text_without_forwarding_or_terminating() {
        let repo = Arc::new(RecordingRepo::new());
        let bus = Arc::new(qianji_realtime::BroadcastEventBus::new(64));
        let (tx, _) = broadcast::channel(64);

        let relay = StreamRelay::new(
            "conv-1".into(),
            "asst-1".into(),
            "turn-1".into(),
            "user-1".into(),
            repo.clone(),
            bus.clone(),
        );

        let mut ws_rx = bus.subscribe();
        let rx = tx.subscribe();

        // launch reply -> SegmentBreak -> completion reply -> Finish
        tx.send(AgentStreamEvent::Text(TextEventData {
            content: "launching workflow".into(),
        }))
        .unwrap();
        tx.send(AgentStreamEvent::SegmentBreak).unwrap();
        tx.send(AgentStreamEvent::Text(TextEventData {
            content: "workflow done".into(),
        }))
        .unwrap();
        tx.send(AgentStreamEvent::Finish(FinishEventData::default())).unwrap();

        relay.consume(rx).await;

        // Two persisted text segments under two different msg_ids.
        let inserts = repo.take_inserts();
        let text_msgs: Vec<_> = inserts.iter().filter(|msg| msg.r#type == "text").collect();
        assert_eq!(text_msgs.len(), 2, "SegmentBreak should split text into two segments");
        assert_eq!(text_msgs[0].id, "asst-1");
        assert_ne!(text_msgs[0].id, text_msgs[1].id);

        // The two text frames reach the WS under two msg_ids, and no
        // `segment_break` frame is ever forwarded.
        let mut text_event_msg_ids = Vec::new();
        let mut saw_segment_break_frame = false;
        while let Ok(evt) = ws_rx.try_recv() {
            if evt.name == "message.stream" {
                if evt.data["type"] == "text" || evt.data["type"] == "content" {
                    text_event_msg_ids.push(evt.data["msg_id"].as_str().unwrap_or_default().to_owned());
                }
                if evt.data["type"] == "segment_break" {
                    saw_segment_break_frame = true;
                }
            }
        }
        assert!(
            !saw_segment_break_frame,
            "SegmentBreak must never be forwarded to the WS"
        );
        assert_eq!(text_event_msg_ids.len(), 2);
        assert_eq!(text_event_msg_ids[0], "asst-1");
        assert_ne!(text_event_msg_ids[0], text_event_msg_ids[1]);
    }

    #[tokio::test]
    async fn run_error_with_no_text_stores_tips_message() {
        let repo = Arc::new(RecordingRepo::new());
        let bus = Arc::new(qianji_realtime::BroadcastEventBus::new(64));
        let (tx, _) = broadcast::channel(64);

        let relay = StreamRelay::new(
            "conv-1".into(),
            "asst-1".into(),
            "turn-1".into(),
            "user-1".into(),
            repo.clone(),
            bus.clone(),
        );

        let rx = tx.subscribe();

        tx.send(AgentStreamEvent::Error(ErrorEventData::legacy(
            "Something went wrong",
            None,
        )))
        .unwrap();

        let outcome = relay.consume(rx).await;
        assert!(outcome.system_responses.is_empty());
        assert_eq!(
            outcome.terminal,
            RelayTerminal::Error {
                code: None,
                retryable: None
            }
        );

        let inserts = repo.take_inserts();
        assert_eq!(inserts.len(), 1);
        let msg = &inserts[0];
        assert_eq!(msg.r#type, "tips");
        assert_eq!(msg.status.as_deref(), Some("error"));

        let content: serde_json::Value = serde_json::from_str(&msg.content).unwrap();
        assert_eq!(content["content"], "Something went wrong");
        assert_eq!(content["type"], "error");
    }

    #[test]
    fn stream_relay_emits_feedback_runtime_terminal_log() {
        let runtime = tokio::runtime::Builder::new_current_thread()
            .enable_all()
            .build()
            .unwrap();
        let captured = capture_logs(Level::INFO, || {
            runtime.block_on(async {
                let repo = Arc::new(RecordingRepo::new());
                let bus = Arc::new(qianji_realtime::BroadcastEventBus::new(64));
                let (tx, rx) = broadcast::channel(64);

                let relay = StreamRelay::new(
                    "conv-1".into(),
                    "asst-1".into(),
                    "turn-1".into(),
                    "user-1".into(),
                    repo,
                    bus,
                );

                tx.send(AgentStreamEvent::Error(ErrorEventData::legacy(
                    "Something went wrong",
                    None,
                )))
                .unwrap();
                drop(tx);

                relay.consume(rx).await;
            });
        });

        assert!(captured.contains("qianji_feedback_diagnostics"), "{captured}");
        assert!(captured.contains("feedback.runtime.turn_terminal"), "{captured}");
        assert!(captured.contains("conversation_id=conv-1"), "{captured}");
        assert!(captured.contains("turn_id=turn-1"), "{captured}");
        assert!(captured.contains("msg_id=asst-1"), "{captured}");
        assert!(captured.contains("event_type=Error"), "{captured}");
        assert!(captured.contains("text_len=0"), "{captured}");
    }

    #[tokio::test]
    async fn clean_retryable_error_can_be_deferred_for_replay() {
        let repo = Arc::new(RecordingRepo::new());
        let bus = Arc::new(qianji_realtime::BroadcastEventBus::new(64));
        let mut ws_rx = bus.subscribe();
        let (tx, rx) = broadcast::channel(8);

        let relay = StreamRelay::new(
            "conv-1".into(),
            "msg-1".into(),
            "turn-1".into(),
            "user-1".into(),
            repo.clone(),
            bus.clone(),
        )
        .with_turn_completion(false)
        .with_defer_clean_terminal_errors(true);

        tx.send(AgentStreamEvent::Error(ErrorEventData {
            message: "temporary provider failure".into(),
            code: Some(AgentErrorCode::UnknownUpstreamError),
            ownership: None,
            detail: None,
            workspace_path: None,
            retryable: Some(true),
            feedback_recommended: None,
            resolution: None,
        }))
        .unwrap();
        drop(tx);

        let outcome = relay.consume(rx).await;

        assert_eq!(
            outcome.terminal,
            RelayTerminal::Error {
                code: Some(AgentErrorCode::UnknownUpstreamError),
                retryable: Some(true),
            }
        );
        assert!(outcome.attempt.safe_to_auto_replay());
        assert!(
            ws_rx.try_recv().is_err(),
            "clean first-attempt errors stay hidden before replay"
        );
        assert!(
            repo.take_inserts().is_empty(),
            "no assistant error tip is persisted before replay"
        );
    }

    #[tokio::test]
    async fn text_before_retryable_error_is_not_clean_for_replay() {
        let repo = Arc::new(RecordingRepo::new());
        let bus = Arc::new(qianji_realtime::BroadcastEventBus::new(64));
        let mut ws_rx = bus.subscribe();
        let (tx, rx) = broadcast::channel(8);

        let relay = StreamRelay::new(
            "conv-1".into(),
            "msg-1".into(),
            "turn-1".into(),
            "user-1".into(),
            repo.clone(),
            bus.clone(),
        )
        .with_turn_completion(false)
        .with_defer_clean_terminal_errors(true);

        tx.send(AgentStreamEvent::Text(TextEventData {
            content: "partial".into(),
        }))
        .unwrap();
        tx.send(AgentStreamEvent::Error(ErrorEventData {
            message: "temporary provider failure".into(),
            code: Some(AgentErrorCode::UnknownUpstreamError),
            ownership: None,
            detail: None,
            workspace_path: None,
            retryable: Some(true),
            feedback_recommended: None,
            resolution: None,
        }))
        .unwrap();
        drop(tx);

        let outcome = relay.consume(rx).await;

        assert!(outcome.attempt.saw_visible_output);
        assert!(!outcome.attempt.safe_to_auto_replay());
        let mut saw_error = false;
        while let Ok(event) = ws_rx.try_recv() {
            saw_error |= event.data["type"] == "error";
        }
        assert!(saw_error, "unsafe errors are still broadcast");
    }

    // ELECTRON-3Q0: a Warning/Info tip is a system diagnostic (e.g. codex
    // rejecting a mode seed against a dead thread), NOT assistant output — it
    // must not make a failed attempt unsafe to auto-replay, or the dead-anchor
    // recovery never fires on cron turns (the mode seed always precedes the send).
    #[tokio::test]
    async fn warning_tip_before_retryable_error_stays_clean_for_replay() {
        use qianji_ai_agent::protocol::events::{TipType, TipsEventData};

        let repo = Arc::new(RecordingRepo::new());
        let bus = Arc::new(qianji_realtime::BroadcastEventBus::new(64));
        let (tx, rx) = broadcast::channel(8);

        let relay = StreamRelay::new(
            "conv-1".into(),
            "msg-1".into(),
            "turn-1".into(),
            "user-1".into(),
            repo.clone(),
            bus.clone(),
        )
        .with_turn_completion(false)
        .with_defer_clean_terminal_errors(true);

        tx.send(AgentStreamEvent::Tips(TipsEventData {
            content: "Codex rejected mode change".into(),
            tip_type: TipType::Warning,
            code: None,
            params: None,
            supersedes_key: None,
        }))
        .unwrap();
        tx.send(AgentStreamEvent::Error(ErrorEventData {
            message: "codex rejected the turn request: thread not found: 0199-dead".into(),
            code: Some(AgentErrorCode::UserAgentSessionNotFound),
            ownership: None,
            detail: None,
            workspace_path: None,
            retryable: Some(true),
            feedback_recommended: None,
            resolution: None,
        }))
        .unwrap();
        drop(tx);

        let outcome = relay.consume(rx).await;

        assert!(
            !outcome.attempt.saw_visible_output,
            "a Warning tip is not assistant output"
        );
        assert!(
            outcome.attempt.safe_to_auto_replay(),
            "the failed attempt must stay eligible for the dead-anchor auto-replay"
        );
    }

    #[tokio::test]
    async fn tool_call_before_retryable_error_is_not_clean_for_replay() {
        use qianji_ai_agent::protocol::events::tool_call::{ToolCallEventData, ToolCallStatus};

        let repo = Arc::new(RecordingRepo::new());
        let bus = Arc::new(qianji_realtime::BroadcastEventBus::new(64));
        let (tx, rx) = broadcast::channel(8);

        let relay = StreamRelay::new(
            "conv-1".into(),
            "msg-1".into(),
            "turn-1".into(),
            "user-1".into(),
            repo.clone(),
            bus.clone(),
        )
        .with_turn_completion(false)
        .with_defer_clean_terminal_errors(true);

        tx.send(AgentStreamEvent::ToolCall(ToolCallEventData {
            call_id: "call-1".into(),
            name: "write_file".into(),
            args: serde_json::json!({}),
            status: ToolCallStatus::Running,
            input: None,
            output: None,
            description: None,
            parent_call_id: None,
        }))
        .unwrap();
        tx.send(AgentStreamEvent::Error(ErrorEventData {
            message: "temporary provider failure".into(),
            code: Some(AgentErrorCode::UnknownUpstreamError),
            ownership: None,
            detail: None,
            workspace_path: None,
            retryable: Some(true),
            feedback_recommended: None,
            resolution: None,
        }))
        .unwrap();
        drop(tx);

        let outcome = relay.consume(rx).await;

        assert!(outcome.attempt.saw_tool_or_side_effect);
        assert!(!outcome.attempt.safe_to_auto_replay());
    }

    #[tokio::test]
    async fn run_warning_tip_with_finish_persists_warning_tip() {
        let repo = Arc::new(RecordingRepo::new());
        let bus = Arc::new(qianji_realtime::BroadcastEventBus::new(64));
        let (tx, _) = broadcast::channel(64);

        let relay = StreamRelay::new(
            "conv-1".into(),
            "asst-1".into(),
            "turn-1".into(),
            "user-1".into(),
            repo.clone(),
            bus.clone(),
        );

        let rx = tx.subscribe();

        tx.send(AgentStreamEvent::Tips(
            qianji_ai_agent::protocol::events::TipsEventData {
                content: String::new(),
                tip_type: qianji_ai_agent::protocol::events::TipType::Warning,
                code: Some("ACP_EMPTY_TURN".into()),
                params: None,
                supersedes_key: None,
            },
        ))
        .unwrap();
        tx.send(AgentStreamEvent::Finish(FinishEventData::default())).unwrap();

        let outcome = relay.consume(rx).await;
        assert!(outcome.system_responses.is_empty());
        assert_eq!(outcome.terminal, RelayTerminal::Finish);

        let inserts = repo.take_inserts();
        assert_eq!(inserts.len(), 1);
        let msg = &inserts[0];
        assert_eq!(msg.r#type, "tips");
        assert_eq!(msg.status.as_deref(), Some("finish"));

        let content: serde_json::Value = serde_json::from_str(&msg.content).unwrap();
        assert_eq!(content["content"], "");
        assert_eq!(content["type"], "warning");
        assert_eq!(content["code"], "ACP_EMPTY_TURN");
    }

    #[tokio::test]
    async fn run_send_error_injects_error_and_completes_turn() {
        let repo = Arc::new(RecordingRepo::new());
        let bus = Arc::new(qianji_realtime::BroadcastEventBus::new(64));
        let (tx, _) = broadcast::channel(64);

        let relay = StreamRelay::new(
            "conv-1".into(),
            "asst-1".into(),
            "turn-1".into(),
            "user-1".into(),
            repo.clone(),
            bus.clone(),
        );

        let mut ws_rx = bus.subscribe();
        let rx = tx.subscribe();
        let (send_error_tx, send_error_rx) = tokio::sync::oneshot::channel();
        send_error_tx
            .send(AgentSendError::from_agent_error(AgentError::bad_gateway(
                "provider returned 401 invalid api key",
            )))
            .unwrap();

        let outcome = relay.consume_with_send_error(rx, send_error_rx).await;
        assert!(outcome.system_responses.is_empty());
        assert_eq!(
            outcome.terminal,
            RelayTerminal::Error {
                code: Some(qianji_api_types::AgentErrorCode::UserLlmProviderAuthFailed),
                retryable: Some(false)
            }
        );

        let inserts = repo.take_inserts();
        assert_eq!(inserts.len(), 1);
        assert_eq!(inserts[0].r#type, "tips");
        assert_eq!(inserts[0].status.as_deref(), Some("error"));
        let content: serde_json::Value = serde_json::from_str(&inserts[0].content).unwrap();
        assert_eq!(content["content"], "The model provider rejected the request");
        assert_eq!(content["type"], "error");
        assert_eq!(content["error"]["code"], "USER_LLM_PROVIDER_AUTH_FAILED");
        assert_eq!(content["error"]["ownership"], "user_llm_provider");
        assert_eq!(content["error"]["retryable"], false);
        assert_eq!(content["error"]["feedback_recommended"], false);
        assert_eq!(content["error"]["detail"], "provider returned 401 invalid api key");
        assert_eq!(content["error"]["resolution"]["kind"], "check_provider_credentials");
        assert_eq!(content["error"]["resolution"]["target"], "provider_settings");

        let mut ws_events = vec![];
        while let Ok(evt) = ws_rx.try_recv() {
            ws_events.push(evt);
        }

        let error_event = ws_events
            .iter()
            .find(|evt| evt.name == "message.stream" && evt.data["type"] == "error")
            .expect("send error should be forwarded as message.stream error");
        assert_eq!(error_event.data["data"]["code"], "USER_LLM_PROVIDER_AUTH_FAILED");
        assert_eq!(error_event.data["data"]["ownership"], "user_llm_provider");
        assert!(ws_events.iter().any(|evt| evt.name == "turn.completed"));
    }

    #[tokio::test]
    async fn run_send_error_keeps_existing_stream_error_when_it_arrives_first() {
        let repo = Arc::new(RecordingRepo::new());
        let bus = Arc::new(qianji_realtime::BroadcastEventBus::new(64));
        let (tx, _) = broadcast::channel(64);

        let relay = StreamRelay::new(
            "conv-1".into(),
            "asst-1".into(),
            "turn-1".into(),
            "user-1".into(),
            repo.clone(),
            bus.clone(),
        );

        let rx = tx.subscribe();
        let send_error =
            AgentSendError::from_agent_error(AgentError::bad_gateway("provider returned 401 invalid api key"));
        tx.send(AgentStreamEvent::Error(ErrorEventData::legacy(
            "stream already emitted",
            None,
        )))
        .unwrap();
        let (send_error_tx, send_error_rx) = tokio::sync::oneshot::channel();
        let delayed_send_error = tokio::spawn(async move {
            tokio::time::sleep(std::time::Duration::from_millis(20)).await;
            let _ = send_error_tx.send(send_error);
        });

        let outcome = relay.consume_with_send_error(rx, send_error_rx).await;
        delayed_send_error.await.unwrap();
        assert!(outcome.system_responses.is_empty());

        let inserts = repo.take_inserts();
        assert_eq!(inserts.len(), 1);
        assert_eq!(inserts[0].r#type, "tips");
        let content: serde_json::Value = serde_json::from_str(&inserts[0].content).unwrap();
        assert_eq!(content["content"], "stream already emitted");
        assert_eq!(content["type"], "error");
    }

    #[tokio::test]
    async fn run_send_error_uses_send_error_when_it_arrives_first() {
        let repo = Arc::new(RecordingRepo::new());
        let bus = Arc::new(qianji_realtime::BroadcastEventBus::new(64));
        let (tx, _) = broadcast::channel(64);

        let relay = StreamRelay::new(
            "conv-1".into(),
            "asst-1".into(),
            "turn-1".into(),
            "user-1".into(),
            repo.clone(),
            bus.clone(),
        );

        let rx = tx.subscribe();
        let (send_error_tx, send_error_rx) = tokio::sync::oneshot::channel();
        send_error_tx
            .send(AgentSendError::from_agent_error(AgentError::bad_gateway(
                "provider returned 401 invalid api key",
            )))
            .unwrap();
        let delayed_stream_error = tokio::spawn(async move {
            tokio::time::sleep(std::time::Duration::from_millis(20)).await;
            let _ = tx.send(AgentStreamEvent::Error(ErrorEventData::legacy(
                "stream already emitted",
                None,
            )));
        });

        let outcome = relay.consume_with_send_error(rx, send_error_rx).await;
        delayed_stream_error.await.unwrap();
        assert!(outcome.system_responses.is_empty());
        assert_eq!(
            outcome.terminal,
            RelayTerminal::Error {
                code: Some(qianji_api_types::AgentErrorCode::UserLlmProviderAuthFailed),
                retryable: Some(false)
            }
        );

        let inserts = repo.take_inserts();
        assert_eq!(inserts.len(), 1);
        assert_eq!(inserts[0].r#type, "tips");
        let content: serde_json::Value = serde_json::from_str(&inserts[0].content).unwrap();
        assert_eq!(content["content"], "The model provider rejected the request");
        assert_eq!(content["type"], "error");
        assert_eq!(content["error"]["resolution"]["kind"], "check_provider_credentials");
        assert_eq!(content["error"]["resolution"]["target"], "provider_settings");
    }

    #[tokio::test]
    async fn run_drops_empty_thinking_segment_without_persisting() {
        // A thinking chunk with no text must not open a segment at all: it has
        // nothing to render, and persisting it is what produced the column of blank
        // "thinking done · 0s" cards on reload. Live and reload agree because
        // NEITHER shows a card — not because both show an empty one.
        use qianji_ai_agent::protocol::events::tool_call::{ToolCallEventData, ToolCallStatus};

        let repo = Arc::new(RecordingRepo::new());
        let bus = Arc::new(qianji_realtime::BroadcastEventBus::new(64));
        let (tx, _) = broadcast::channel(64);

        let relay = StreamRelay::new(
            "conv-1".into(),
            "asst-1".into(),
            "turn-1".into(),
            "user-1".into(),
            repo.clone(),
            bus.clone(),
        );

        let mut ws_rx = bus.subscribe();
        let rx = tx.subscribe();

        tx.send(AgentStreamEvent::Thinking(ThinkingEventData {
            content: String::new(),
            subject: None,
            duration: None,
            status: Some("thinking".into()),
        }))
        .unwrap();
        tx.send(AgentStreamEvent::ToolCall(ToolCallEventData {
            call_id: "tc-001".into(),
            name: "read_file".into(),
            args: json!({"path": "a.ts"}),
            status: ToolCallStatus::Running,
            description: None,
            parent_call_id: None,
            input: None,
            output: None,
        }))
        .unwrap();
        tx.send(AgentStreamEvent::Finish(FinishEventData::default())).unwrap();

        relay.consume(rx).await;

        let inserts = repo.take_inserts();
        let thinking_msgs: Vec<_> = inserts.iter().filter(|msg| msg.r#type == "thinking").collect();
        assert!(
            thinking_msgs.is_empty(),
            "an empty thinking chunk must persist nothing, got: {thinking_msgs:?}"
        );
        // The tool row is untouched — dropping the blank thought must not swallow
        // the real content that followed it.
        assert_eq!(
            inserts.iter().filter(|msg| msg.r#type == "tool_call").count(),
            1,
            "the tool row must still be persisted"
        );

        // Nothing thinking-shaped reaches the live stream either, so the reloaded
        // view and the live view agree: no card on either side.
        let mut thinking_frames = 0;
        while let Ok(evt) = ws_rx.try_recv() {
            if evt.name == "message.stream" && evt.data["type"] == "thinking" {
                thinking_frames += 1;
            }
        }
        assert_eq!(thinking_frames, 0, "no thinking frame should reach the WebSocket");
    }

    #[tokio::test]
    async fn run_thinking_tool_thinking_splits_thinking_segments() {
        use qianji_ai_agent::protocol::events::tool_call::{ToolCallEventData, ToolCallStatus};

        let repo = Arc::new(RecordingRepo::new());
        let bus = Arc::new(qianji_realtime::BroadcastEventBus::new(64));
        let (tx, _) = broadcast::channel(64);

        let relay = StreamRelay::new(
            "conv-1".into(),
            "asst-1".into(),
            "turn-1".into(),
            "user-1".into(),
            repo.clone(),
            bus.clone(),
        );

        let mut ws_rx = bus.subscribe();
        let rx = tx.subscribe();

        tx.send(AgentStreamEvent::Thinking(ThinkingEventData {
            content: "Plan A".into(),
            subject: None,
            duration: None,
            status: Some("thinking".into()),
        }))
        .unwrap();
        tx.send(AgentStreamEvent::ToolCall(ToolCallEventData {
            call_id: "tc-001".into(),
            name: "read_file".into(),
            args: json!({"path": "a.ts"}),
            status: ToolCallStatus::Running,
            description: None,
            parent_call_id: None,
            input: None,
            output: None,
        }))
        .unwrap();
        tx.send(AgentStreamEvent::Thinking(ThinkingEventData {
            content: "Plan B".into(),
            subject: None,
            duration: None,
            status: Some("thinking".into()),
        }))
        .unwrap();
        tx.send(AgentStreamEvent::Finish(FinishEventData::default())).unwrap();

        relay.consume(rx).await;

        let inserts = repo.take_inserts();
        let thinking_msgs: Vec<_> = inserts.iter().filter(|msg| msg.r#type == "thinking").collect();
        assert_eq!(thinking_msgs.len(), 2, "thinking should split across tool boundaries");
        assert_eq!(thinking_msgs[0].msg_id.as_deref(), Some("asst-1"));
        assert_ne!(thinking_msgs[0].msg_id, thinking_msgs[1].msg_id);

        let mut done_msg_ids = Vec::new();
        while let Ok(evt) = ws_rx.try_recv() {
            if evt.name == "message.stream" && evt.data["type"] == "thinking" && evt.data["data"]["status"] == "done" {
                done_msg_ids.push(evt.data["msg_id"].as_str().unwrap_or_default().to_owned());
            }
        }
        assert_eq!(done_msg_ids.len(), 2);
        assert_eq!(done_msg_ids[0], "asst-1");
        assert_ne!(done_msg_ids[0], done_msg_ids[1]);
    }

    #[tokio::test]
    async fn run_thinking_then_text_uses_distinct_segment_ids() {
        let repo = Arc::new(RecordingRepo::new());
        let bus = Arc::new(qianji_realtime::BroadcastEventBus::new(64));
        let (tx, _) = broadcast::channel(64);

        let relay = StreamRelay::new(
            "conv-1".into(),
            "asst-1".into(),
            "turn-1".into(),
            "user-1".into(),
            repo.clone(),
            bus.clone(),
        );

        let mut ws_rx = bus.subscribe();
        let rx = tx.subscribe();

        tx.send(AgentStreamEvent::Thinking(ThinkingEventData {
            content: "Plan first".into(),
            subject: None,
            duration: None,
            status: Some("thinking".into()),
        }))
        .unwrap();
        tx.send(AgentStreamEvent::Text(TextEventData {
            content: "Final answer".into(),
        }))
        .unwrap();
        tx.send(AgentStreamEvent::Finish(FinishEventData::default())).unwrap();

        relay.consume(rx).await;

        let inserts = repo.take_inserts();
        let thinking_msgs: Vec<_> = inserts.iter().filter(|msg| msg.r#type == "thinking").collect();
        let text_msgs: Vec<_> = inserts.iter().filter(|msg| msg.r#type == "text").collect();

        assert_eq!(thinking_msgs.len(), 1);
        assert_eq!(text_msgs.len(), 1);
        assert_eq!(thinking_msgs[0].id, "asst-1");
        assert_ne!(thinking_msgs[0].id, text_msgs[0].id);

        let mut text_msg_ids = Vec::new();
        let mut thinking_done_ids = Vec::new();
        while let Ok(evt) = ws_rx.try_recv() {
            if evt.name != "message.stream" {
                continue;
            }
            if evt.data["type"] == "text" || evt.data["type"] == "content" {
                text_msg_ids.push(evt.data["msg_id"].as_str().unwrap_or_default().to_owned());
            }
            if evt.data["type"] == "thinking" && evt.data["data"]["status"] == "done" {
                thinking_done_ids.push(evt.data["msg_id"].as_str().unwrap_or_default().to_owned());
            }
        }

        assert_eq!(thinking_done_ids, vec!["asst-1".to_string()]);
        assert_eq!(text_msg_ids.len(), 1);
        assert_ne!(text_msg_ids[0], "asst-1");
    }

    #[tokio::test]
    async fn run_channel_closed_finalizes() {
        let repo = Arc::new(RecordingRepo::new());
        let bus = Arc::new(qianji_realtime::BroadcastEventBus::new(64));
        let (tx, _) = broadcast::channel(64);

        let relay = StreamRelay::new(
            "conv-1".into(),
            "asst-1".into(),
            "turn-1".into(),
            "user-1".into(),
            repo.clone(),
            bus.clone(),
        );

        let rx = tx.subscribe();

        // Send text then drop sender (channel closes without Finish)
        tx.send(AgentStreamEvent::Text(TextEventData {
            content: "partial".into(),
        }))
        .unwrap();
        drop(tx);

        let outcome = relay.consume(rx).await;
        assert!(outcome.system_responses.is_empty());
        assert_eq!(outcome.terminal, RelayTerminal::ChannelClosed);

        // Should still persist the partial text
        let inserts = repo.take_inserts();
        assert_eq!(inserts.len(), 1);
        let content: serde_json::Value = serde_json::from_str(&inserts[0].content).unwrap();
        assert_eq!(content["content"], "partial");
    }

    #[tokio::test]
    async fn run_broadcasts_turn_completed() {
        let repo = Arc::new(RecordingRepo::new());
        let bus = Arc::new(qianji_realtime::BroadcastEventBus::new(64));
        let (tx, _) = broadcast::channel(64);

        let relay = StreamRelay::new(
            "conv-1".into(),
            "asst-1".into(),
            "turn-1".into(),
            "user-1".into(),
            repo.clone(),
            bus.clone(),
        );

        // Subscribe to the bus before relay runs
        let mut ws_rx = bus.subscribe();
        let rx = tx.subscribe();

        tx.send(AgentStreamEvent::Finish(FinishEventData::default())).unwrap();

        let outcome = relay.consume(rx).await;
        assert!(outcome.system_responses.is_empty());

        // Collect WebSocket events
        let mut ws_events = vec![];
        while let Ok(evt) = ws_rx.try_recv() {
            ws_events.push(evt);
        }

        // Should have turn.completed event
        let turn_event = ws_events.iter().find(|e| e.name == "turn.completed");
        assert!(turn_event.is_some());
        let data = &turn_event.unwrap().data;
        assert_eq!(data["conversation_id"], "conv-1");
        assert_eq!(data["session_id"], "conv-1");
        assert_eq!(data["turn_id"], "turn-1");
        assert_eq!(data["status"], "finished");
        assert_eq!(data["canSendMessage"], true);

        let stream_event = ws_events
            .iter()
            .find(|e| e.name == "message.stream")
            .expect("finish should be forwarded as message.stream");
        assert_eq!(stream_event.data["turn_id"], "turn-1");
    }

    // ── Tool persistence tests ────────────────────────────────────

    /// A plan snapshot must reach the DB, not just the WebSocket: a turn that
    /// keeps running in the background has to rehydrate its plan bar when the
    /// user comes back to the conversation.
    ///
    /// One row per turn, upserted — a plan is a FULL-REPLACEMENT snapshot, so a
    /// second frame overwrites the first rather than stacking a second card.
    #[tokio::test]
    async fn run_plan_persists_message() {
        use qianji_ai_agent::protocol::events::session_updates::PlanEventData;

        let repo = Arc::new(RecordingRepo::new());
        let bus = Arc::new(qianji_realtime::BroadcastEventBus::new(64));
        let (tx, _) = broadcast::channel(64);

        let relay = StreamRelay::new(
            "conv-1".into(),
            "asst-1".into(),
            "turn-1".into(),
            "user-1".into(),
            repo.clone(),
            bus.clone(),
        );

        let rx = tx.subscribe();

        tx.send(AgentStreamEvent::Plan(PlanEventData {
            session_id: None,
            entries: vec![json!({"content": "step one", "status": "pending"})],
        }))
        .unwrap();
        tx.send(AgentStreamEvent::Plan(PlanEventData {
            session_id: None,
            entries: vec![json!({"content": "step one", "status": "completed"})],
        }))
        .unwrap();
        tx.send(AgentStreamEvent::Finish(FinishEventData::default())).unwrap();

        relay.consume(rx).await;

        let inserts = repo.take_inserts();
        let plans: Vec<_> = inserts.iter().filter(|m| m.r#type == "plan").collect();
        assert_eq!(plans.len(), 1, "one row per turn, not one per frame: {inserts:?}");

        let row = plans[0];
        assert_eq!(row.id, "plan:asst-1");
        // BARE msg_id: the live WS frame carries the turn msg_id, and the
        // renderer dedupes history against live frames on `${type}:${msg_id}`.
        assert_eq!(row.msg_id.as_deref(), Some("asst-1"));

        let updates = repo.take_updates();
        let (_, upd) = updates
            .iter()
            .find(|(id, _)| id == "plan:asst-1")
            .expect("the second frame must upsert the same row");

        let content: serde_json::Value = serde_json::from_str(upd.content.as_deref().unwrap()).unwrap();
        assert_eq!(content["entries"][0]["status"], "completed");
        // turn_id rides inside content (the column set is fixed); the plan bar
        // gates on it matching the running turn.
        assert_eq!(content["turn_id"], "turn-1");
    }

    #[tokio::test]
    async fn run_tool_call_persists_message() {
        use qianji_ai_agent::protocol::events::tool_call::{ToolCallEventData, ToolCallStatus};

        let repo = Arc::new(RecordingRepo::new());
        let bus = Arc::new(qianji_realtime::BroadcastEventBus::new(64));
        let (tx, _) = broadcast::channel(64);

        let relay = StreamRelay::new(
            "conv-1".into(),
            "asst-1".into(),
            "turn-1".into(),
            "user-1".into(),
            repo.clone(),
            bus.clone(),
        );

        let rx = tx.subscribe();

        // First event: Running with input but no output
        tx.send(AgentStreamEvent::ToolCall(ToolCallEventData {
            call_id: "tc-001".into(),
            name: "image_gen".into(),
            args: json!({"prompt": "a cat"}),
            status: ToolCallStatus::Running,
            input: Some(json!({"prompt": "a cat", "size": "1024x1024"})),
            output: None,
            description: Some("Generate image".into()),
            parent_call_id: None,
        }))
        .unwrap();
        // Second event: Completed with output but no input
        tx.send(AgentStreamEvent::ToolCall(ToolCallEventData {
            call_id: "tc-001".into(),
            name: "image_gen".into(),
            args: json!({"prompt": "a cat"}),
            status: ToolCallStatus::Completed,
            input: None,
            output: Some("image.png".into()),
            description: None,
            parent_call_id: None,
        }))
        .unwrap();
        tx.send(AgentStreamEvent::Finish(FinishEventData::default())).unwrap();

        relay.consume(rx).await;

        let inserts = repo.take_inserts();
        let tool_msg = inserts.iter().find(|m| m.r#type == "tool_call");
        assert!(tool_msg.is_some());
        let msg = tool_msg.unwrap();
        assert_eq!(msg.id, "tc-001");
        assert_eq!(msg.status.as_deref(), Some("work"));

        let updates = repo.take_updates();
        let tool_update = updates.iter().find(|(id, _)| id == "tc-001");
        assert!(tool_update.is_some());
        let (_, upd) = tool_update.unwrap();
        assert_eq!(upd.status, Some(Some("finish".to_owned())));

        // Verify merge: input from first event preserved, output from second event added
        let merged: serde_json::Value = serde_json::from_str(upd.content.as_deref().unwrap()).unwrap();
        assert_eq!(merged["name"], "image_gen");
        assert_eq!(merged["status"], "completed");
        assert!(
            merged.get("input").is_some() && !merged["input"].is_null(),
            "input must be preserved after merge"
        );
        assert_eq!(merged["input"]["prompt"], "a cat");
        assert_eq!(merged["output"], "image.png");
        assert_eq!(merged["description"], "Generate image");
    }

    #[tokio::test]
    async fn run_acp_tool_call_inserts_then_updates() {
        use qianji_ai_agent::protocol::events::tool_call::{
            AcpToolCallEventData, AcpToolCallSessionUpdateKind, AcpToolCallStatus, AcpToolCallUpdateData,
        };

        let repo = Arc::new(RecordingRepo::new());
        let bus = Arc::new(qianji_realtime::BroadcastEventBus::new(64));
        let (tx, _) = broadcast::channel(64);

        let relay = StreamRelay::new(
            "conv-1".into(),
            "asst-1".into(),
            "turn-1".into(),
            "user-1".into(),
            repo.clone(),
            bus.clone(),
        );

        let rx = tx.subscribe();

        tx.send(AgentStreamEvent::AcpToolCall(AcpToolCallEventData {
            session_id: "sess-1".into(),
            update: AcpToolCallUpdateData {
                session_update: AcpToolCallSessionUpdateKind::ToolCall,
                tool_call_id: "atc-001".into(),
                status: Some(AcpToolCallStatus::InProgress),
                title: Some("Bash".into()),
                kind: None,
                raw_input: Some(json!({"command": "mv /tmp/a /tmp/b", "description": "Move file"})),
                raw_output: None,
                content: None,
                locations: None,
            },
            meta: None,
        }))
        .unwrap();

        tx.send(AgentStreamEvent::AcpToolCall(AcpToolCallEventData {
            session_id: "sess-1".into(),
            update: AcpToolCallUpdateData {
                session_update: AcpToolCallSessionUpdateKind::ToolCallUpdate,
                tool_call_id: "atc-001".into(),
                status: Some(AcpToolCallStatus::Completed),
                title: None,
                kind: None,
                raw_input: None,
                raw_output: Some(json!("Exit code: 0\nSTDOUT:\nSTDERR:")),
                content: None,
                locations: None,
            },
            meta: None,
        }))
        .unwrap();

        tx.send(AgentStreamEvent::Finish(FinishEventData::default())).unwrap();

        relay.consume(rx).await;

        let inserts = repo.take_inserts();
        let acp_msg = inserts.iter().find(|m| m.r#type == "acp_tool_call");
        assert!(acp_msg.is_some());
        let msg = acp_msg.unwrap();
        assert_eq!(msg.id, "atc-001");
        assert_eq!(msg.status.as_deref(), Some("work"));

        let updates = repo.take_updates();
        let acp_update = updates.iter().find(|(id, _)| id == "atc-001");
        assert!(acp_update.is_some());
        let (_, upd) = acp_update.unwrap();
        assert_eq!(upd.status, Some(Some("finish".to_owned())));

        // Verify merge: raw_input from ToolCall is preserved, raw_output from ToolCallUpdate is added
        let merged: serde_json::Value = serde_json::from_str(upd.content.as_deref().unwrap()).unwrap();
        let update_obj = merged.get("update").unwrap();
        assert!(
            update_obj.get("raw_input").is_some(),
            "raw_input must be preserved after merge"
        );
        assert_eq!(
            update_obj
                .get("raw_input")
                .unwrap()
                .get("command")
                .unwrap()
                .as_str()
                .unwrap(),
            "mv /tmp/a /tmp/b"
        );
        assert!(
            update_obj.get("raw_output").is_some(),
            "raw_output must be present after merge"
        );
    }

    #[tokio::test]
    async fn run_acp_image_tool_call_update_persists_finish_without_base64() {
        use qianji_ai_agent::protocol::events::tool_call::{
            AcpToolCallEventData, AcpToolCallKind, AcpToolCallSessionUpdateKind, AcpToolCallStatus,
            AcpToolCallUpdateData,
        };

        let repo = Arc::new(RecordingRepo::new());
        let bus = Arc::new(qianji_realtime::BroadcastEventBus::new(64));
        let (tx, _) = broadcast::channel(64);

        let relay = StreamRelay::new(
            "conv-1".into(),
            "asst-1".into(),
            "turn-1".into(),
            "user-1".into(),
            repo.clone(),
            bus.clone(),
        );

        let rx = tx.subscribe();

        tx.send(AgentStreamEvent::AcpToolCall(AcpToolCallEventData {
            session_id: "sess-1".into(),
            update: AcpToolCallUpdateData {
                session_update: AcpToolCallSessionUpdateKind::ToolCall,
                tool_call_id: "ig_test_image".into(),
                status: Some(AcpToolCallStatus::InProgress),
                title: Some("Image generation".into()),
                kind: Some(AcpToolCallKind::Execute),
                raw_input: Some(json!({"prompt": "一只小猫"})),
                raw_output: None,
                content: None,
                locations: None,
            },
            meta: None,
        }))
        .unwrap();

        tx.send(AgentStreamEvent::AcpToolCall(AcpToolCallEventData {
            session_id: "sess-1".into(),
            update: AcpToolCallUpdateData {
                session_update: AcpToolCallSessionUpdateKind::ToolCallUpdate,
                tool_call_id: "ig_test_image".into(),
                status: Some(AcpToolCallStatus::Completed),
                title: None,
                kind: Some(AcpToolCallKind::Execute),
                raw_input: None,
                raw_output: Some(json!({
                    "saved_path": "/Users/test/.codex/generated_images/session/ig_test_image.png",
                    "image": {
                        "path": "/Users/test/.codex/generated_images/session/ig_test_image.png",
                        "mime_type": "image/png",
                        "source": "codex_image_generation"
                    },
                    "result_omitted": true,
                    "result_omitted_reason": "image_base64",
                    "result_bytes": 131_083
                })),
                content: None,
                locations: None,
            },
            meta: None,
        }))
        .unwrap();

        tx.send(AgentStreamEvent::Finish(FinishEventData::default())).unwrap();

        relay.consume(rx).await;

        let updates = repo.take_updates();
        let acp_update = updates.iter().find(|(id, _)| id == "ig_test_image");
        assert!(acp_update.is_some());
        let (_, upd) = acp_update.unwrap();
        assert_eq!(upd.status, Some(Some("finish".to_owned())));

        let content = upd.content.as_deref().unwrap();
        assert!(!content.contains("iVBORw0KGgo"));
        assert!(content.contains("result_omitted"));

        let merged: serde_json::Value = serde_json::from_str(content).unwrap();
        assert_eq!(
            merged["update"]["raw_output"]["image"]["path"],
            "/Users/test/.codex/generated_images/session/ig_test_image.png"
        );
    }

    #[tokio::test]
    async fn run_tool_group_persists_message() {
        use qianji_ai_agent::protocol::events::tool_call::{ToolGroupEntry, ToolGroupStatus};

        let repo = Arc::new(RecordingRepo::new());
        let bus = Arc::new(qianji_realtime::BroadcastEventBus::new(64));
        let (tx, _) = broadcast::channel(64);

        let relay = StreamRelay::new(
            "conv-1".into(),
            "asst-1".into(),
            "turn-1".into(),
            "user-1".into(),
            repo.clone(),
            bus.clone(),
        );

        let rx = tx.subscribe();

        tx.send(AgentStreamEvent::ToolGroup(vec![
            ToolGroupEntry {
                call_id: "tg-001".into(),
                name: "search".into(),
                status: ToolGroupStatus::Success,
                description: Some("Web search".into()),
            },
            ToolGroupEntry {
                call_id: "tg-002".into(),
                name: "read_file".into(),
                status: ToolGroupStatus::Success,
                description: None,
            },
        ]))
        .unwrap();
        tx.send(AgentStreamEvent::Finish(FinishEventData::default())).unwrap();

        relay.consume(rx).await;

        let inserts = repo.take_inserts();
        let group_msg = inserts.iter().find(|m| m.r#type == "tool_group");
        assert!(group_msg.is_some());
        let msg = group_msg.unwrap();
        assert_eq!(msg.id, "tg-001");
        assert_eq!(msg.status.as_deref(), Some("finish"));

        let content: serde_json::Value = serde_json::from_str(&msg.content).unwrap();
        assert!(content.is_array());
        assert_eq!(content.as_array().unwrap().len(), 2);
    }

    #[tokio::test]
    async fn close_active_text_segment_treats_not_found_as_deleted_conversation() {
        let repo = Arc::new(RecordingRepo::new());
        repo.set_not_found(true);
        let bus = Arc::new(qianji_realtime::BroadcastEventBus::new(64));

        let relay = StreamRelay::new(
            "deleted-conv".into(),
            "assistant-msg".into(),
            "turn-1".into(),
            "user-1".into(),
            repo,
            bus,
        );
        let mut active_text = Some(TextSegmentState {
            id: "missing-segment".into(),
            buffer: "partial answer".into(),
            created_at: now_ms(),
            record_created: true,
            flush_counter: 0,
        });
        let mut text_segments = Vec::new();

        relay
            .close_active_text_segment(&mut active_text, &mut text_segments, "finish")
            .await;

        assert!(active_text.is_none());
        assert!(
            text_segments.is_empty(),
            "missing DB rows should not be treated as persisted text segments"
        );
    }

    #[tokio::test]
    async fn complete_conversation_ignores_not_found_after_delete() {
        let repo = Arc::new(RecordingRepo::new());
        repo.set_not_found(true);
        let repo: Arc<dyn IConversationRepository> = repo;
        let bus: Arc<dyn EventBroadcaster> = Arc::new(qianji_realtime::BroadcastEventBus::new(64));
        let adapter =
            StreamPersistenceAdapter::new("user-test".into(), "deleted-conv".into(), "msg-1".into(), repo, None);

        adapter.complete_conversation(&bus, "turn-1", None).await;
    }

    #[tokio::test]
    async fn run_skips_db_finalization_when_conversation_is_deleting() {
        let repo = Arc::new(RecordingRepo::new());
        let bus = Arc::new(qianji_realtime::BroadcastEventBus::new(64));
        let runtime_state = Arc::new(ConversationRuntimeStateService::default());
        runtime_state.mark_deleting("deleted-conv");
        let (tx, _) = broadcast::channel(16);

        let relay = StreamRelay::new(
            "deleted-conv".into(),
            "assistant-msg".into(),
            "turn-1".into(),
            "user-1".into(),
            repo.clone(),
            bus,
        )
        .with_runtime_state(runtime_state);
        let rx = tx.subscribe();

        tx.send(AgentStreamEvent::Text(TextEventData {
            content: "partial answer".into(),
        }))
        .unwrap();
        tx.send(AgentStreamEvent::Finish(FinishEventData::default())).unwrap();

        let outcome = relay.consume(rx).await;

        assert_eq!(outcome.terminal, RelayTerminal::Finish);
        assert!(repo.take_inserts().is_empty());
        assert!(repo.take_updates().is_empty());
    }

    #[tokio::test]
    async fn finalize_treats_foreign_key_failure_as_deleted_conversation() {
        let repo = Arc::new(RecordingRepo::new());
        repo.set_foreign_key_failure(true);
        let bus = Arc::new(qianji_realtime::BroadcastEventBus::new(64));
        let relay = StreamRelay::new(
            "deleted-conv".into(),
            "assistant-msg".into(),
            "turn-1".into(),
            "user-1".into(),
            repo.clone(),
            bus,
        );

        let outcome = relay
            .finalize(
                "partial answer",
                &[],
                &AgentStreamEvent::Finish(FinishEventData::default()),
                RelayTerminal::Finish,
            )
            .await;

        assert_eq!(outcome.terminal, RelayTerminal::Finish);
        assert!(
            repo.take_inserts().is_empty(),
            "failed fallback writes must not be recorded as persisted messages"
        );
    }

    #[tokio::test]
    async fn complete_active_thinking_treats_foreign_key_failure_as_deleted_conversation() {
        let repo = Arc::new(RecordingRepo::new());
        repo.set_foreign_key_failure(true);
        let bus = Arc::new(qianji_realtime::BroadcastEventBus::new(64));
        let relay = StreamRelay::new(
            "deleted-conv".into(),
            "assistant-msg".into(),
            "turn-1".into(),
            "user-1".into(),
            repo.clone(),
            bus,
        );
        let mut active_thinking = Some(ThinkingSegmentState {
            id: "thinking-1".into(),
            buffer: "working".into(),
            started_at: now_ms(),
        });

        relay.complete_active_thinking(&mut active_thinking).await;

        assert!(active_thinking.is_none());
        assert!(
            repo.take_inserts().is_empty(),
            "failed thinking writes must not be recorded as persisted messages"
        );
    }

    // ── Helpers ──────────────────────────────────────────────────

    /// Recording repo that captures insert/update calls for assertions.
    struct RecordingRepo {
        inserts: Mutex<Vec<MessageRow>>,
        updates: Mutex<Vec<(String, qianji_db::MessageRowUpdate)>>,
        /// Optional conversation row served by `get` (agent-title tests).
        conversation: Mutex<Option<qianji_db::models::ConversationRow>>,
        /// Conversation-level updates recorded by `update` (agent-title tests).
        conversation_updates: Mutex<Vec<(String, qianji_db::ConversationRowUpdate)>>,
        not_found: AtomicBool,
        foreign_key_failure: AtomicBool,
    }

    impl RecordingRepo {
        fn new() -> Self {
            Self {
                inserts: Mutex::new(vec![]),
                updates: Mutex::new(vec![]),
                conversation: Mutex::new(None),
                conversation_updates: Mutex::new(vec![]),
                not_found: AtomicBool::new(false),
                foreign_key_failure: AtomicBool::new(false),
            }
        }

        fn set_not_found(&self, value: bool) {
            self.not_found.store(value, Ordering::Release);
        }

        fn set_foreign_key_failure(&self, value: bool) {
            self.foreign_key_failure.store(value, Ordering::Release);
        }

        fn take_inserts(&self) -> Vec<MessageRow> {
            std::mem::take(&mut self.inserts.lock().unwrap())
        }

        #[allow(dead_code)]
        fn take_updates(&self) -> Vec<(String, qianji_db::MessageRowUpdate)> {
            std::mem::take(&mut self.updates.lock().unwrap())
        }

        fn merged_row(existing: &MessageRow, incoming: &MessageRow) -> MessageRow {
            let preserve_terminal_status = matches!(existing.status.as_deref(), Some("finish" | "error"))
                && incoming.status.as_deref() == Some("work");
            let mut content = Self::merge_json_content(&existing.content, &incoming.content);
            if preserve_terminal_status {
                content = Self::preserve_json_status(&content, &existing.content, &existing.r#type);
            }

            let mut merged = existing.clone();
            merged.content = content;
            merged.status = if preserve_terminal_status {
                existing.status.clone()
            } else {
                incoming.status.clone()
            };
            merged.hidden = incoming.hidden;
            merged
        }

        fn merge_json_content(existing_json: &str, incoming_json: &str) -> String {
            let mut existing: serde_json::Value = serde_json::from_str(existing_json).unwrap_or_default();
            let incoming: serde_json::Value = serde_json::from_str(incoming_json).unwrap_or_default();
            Self::merge_json_value(&mut existing, incoming);
            existing.to_string()
        }

        fn merge_json_value(existing: &mut serde_json::Value, incoming: serde_json::Value) {
            match (existing, incoming) {
                (serde_json::Value::Object(existing_obj), serde_json::Value::Object(incoming_obj)) => {
                    for (key, value) in incoming_obj {
                        if !value.is_null() {
                            if let Some(existing_value) = existing_obj.get_mut(&key) {
                                Self::merge_json_value(existing_value, value);
                            } else {
                                existing_obj.insert(key, value);
                            }
                        }
                    }
                }
                (existing_value, incoming_value) => {
                    if !incoming_value.is_null() {
                        *existing_value = incoming_value;
                    }
                }
            }
        }

        fn preserve_json_status(merged_json: &str, existing_json: &str, msg_type: &str) -> String {
            let mut merged: serde_json::Value = serde_json::from_str(merged_json).unwrap_or_default();
            let existing: serde_json::Value = serde_json::from_str(existing_json).unwrap_or_default();
            let status = if msg_type == "acp_tool_call" {
                existing.pointer("/update/status").cloned()
            } else {
                existing.get("status").cloned()
            };

            if let Some(status) = status {
                if msg_type == "acp_tool_call" {
                    if let Some(update) = merged.get_mut("update").and_then(|value| value.as_object_mut()) {
                        update.insert("status".into(), status);
                    }
                } else if let Some(object) = merged.as_object_mut() {
                    object.insert("status".into(), status);
                }
            }

            merged.to_string()
        }
    }

    #[async_trait::async_trait]
    impl IConversationRepository for RecordingRepo {
        async fn get(&self, _user_id: &str, _id: &str) -> Result<Option<qianji_db::models::ConversationRow>, DbError> {
            Ok(self.conversation.lock().unwrap().clone())
        }
        async fn owner_user_id(&self, _id: &str) -> Result<Option<String>, DbError> {
            Ok(Some("user-1".into()))
        }
        async fn create(&self, _row: &qianji_db::models::ConversationRow) -> Result<(), DbError> {
            Ok(())
        }
        async fn update(
            &self,
            _user_id: &str,
            id: &str,
            updates: &qianji_db::ConversationRowUpdate,
        ) -> Result<(), DbError> {
            if self.not_found.load(Ordering::Acquire) {
                return Err(DbError::NotFound("Conversation deleted-conv not found".into()));
            }
            self.conversation_updates
                .lock()
                .unwrap()
                .push((id.to_string(), updates.clone()));
            Ok(())
        }
        async fn delete(&self, _user_id: &str, _id: &str) -> Result<(), DbError> {
            Ok(())
        }
        async fn list_paginated(
            &self,
            _user_id: &str,
            _filters: &qianji_db::ConversationFilters,
        ) -> Result<qianji_common::PaginatedResult<qianji_db::models::ConversationRow>, DbError> {
            Ok(qianji_common::PaginatedResult {
                items: vec![],
                total: 0,
                has_more: false,
            })
        }
        async fn find_by_source_and_chat(
            &self,
            _user_id: &str,
            _source: &str,
            _chat_id: &str,
            _agent_type: &str,
        ) -> Result<Option<qianji_db::models::ConversationRow>, DbError> {
            Ok(None)
        }
        async fn list_by_cron_job(
            &self,
            _user_id: &str,
            _cron_job_id: &str,
        ) -> Result<Vec<qianji_db::models::ConversationRow>, DbError> {
            Ok(vec![])
        }
        async fn list_associated(
            &self,
            _user_id: &str,
            _conversation_id: &str,
        ) -> Result<Vec<qianji_db::models::ConversationRow>, DbError> {
            Ok(vec![])
        }
        async fn list_messages_page(
            &self,
            _user_id: &str,
            _conv_id: &str,
            _params: &qianji_db::MessagePageParams,
        ) -> Result<qianji_db::MessagePageResult, DbError> {
            Ok(qianji_db::MessagePageResult {
                items: vec![],
                has_more_before: false,
                has_more_after: false,
            })
        }
        async fn insert_message(&self, _user_id: &str, row: &MessageRow) -> Result<(), DbError> {
            if self.not_found.load(Ordering::Acquire) {
                return Err(DbError::NotFound(format!("Message '{}'", row.id)));
            }
            if self.foreign_key_failure.load(Ordering::Acquire) {
                return Err(DbError::Init("FOREIGN KEY constraint failed".into()));
            }
            self.inserts.lock().unwrap().push(row.clone());
            Ok(())
        }
        async fn upsert_message(&self, _user_id: &str, row: &MessageRow) -> Result<(), DbError> {
            if self.not_found.load(Ordering::Acquire) {
                return Err(DbError::NotFound(format!("Message '{}'", row.id)));
            }
            if self.foreign_key_failure.load(Ordering::Acquire) {
                return Err(DbError::Init("FOREIGN KEY constraint failed".into()));
            }

            let mut inserts = self.inserts.lock().unwrap();
            if let Some(existing) = inserts.iter().find(|message| message.id == row.id) {
                let merged = Self::merged_row(existing, row);
                self.updates.lock().unwrap().push((
                    row.id.clone(),
                    qianji_db::MessageRowUpdate {
                        content: Some(merged.content),
                        status: Some(merged.status),
                        hidden: Some(merged.hidden),
                    },
                ));
            } else {
                inserts.push(row.clone());
            }
            Ok(())
        }
        async fn update_message(
            &self,
            _user_id: &str,
            _conversation_id: &str,
            id: &str,
            updates: &qianji_db::MessageRowUpdate,
        ) -> Result<(), DbError> {
            if self.not_found.load(Ordering::Acquire) {
                return Err(DbError::NotFound(format!("Message '{id}' not found")));
            }
            self.updates.lock().unwrap().push((id.to_owned(), updates.clone()));
            Ok(())
        }
        async fn delete_messages_by_conversation(&self, _user_id: &str, _conv_id: &str) -> Result<(), DbError> {
            Ok(())
        }
        async fn get_message_by_msg_id(
            &self,
            _user_id: &str,
            _conv_id: &str,
            msg_id: &str,
            msg_type: &str,
        ) -> Result<Option<MessageRow>, DbError> {
            let inserts = self.inserts.lock().unwrap();
            Ok(inserts
                .iter()
                .find(|m| m.msg_id.as_deref() == Some(msg_id) && m.r#type == msg_type)
                .cloned())
        }
        async fn search_messages(
            &self,
            _user_id: &str,
            _keyword: &str,
            _page: u32,
            _page_size: u32,
        ) -> Result<qianji_common::PaginatedResult<qianji_db::MessageSearchRow>, DbError> {
            Ok(qianji_common::PaginatedResult {
                items: vec![],
                total: 0,
                has_more: false,
            })
        }
    }
}
