use std::collections::VecDeque;
use std::path::{Path, PathBuf};
use std::sync::{
    Arc, Mutex,
    atomic::{AtomicBool, AtomicUsize, Ordering},
};
use std::time::Duration;

use qianji_ai_agent::agent_task::{AgentInstance, IAgentTask, IMockAgent};
use qianji_ai_agent::protocol::events::tool_call::{ToolCallEventData, ToolCallStatus};
use qianji_ai_agent::protocol::events::{AgentStreamEvent, ErrorEventData, FinishEventData, TextEventData};
use qianji_ai_agent::types::{
    BuildTaskOptions, CONVERSATION_RUNTIME_CONTEXT_VERSION, QIANJI_BASE_URL_ENV, QIANJI_HELPER_BIN_ENV,
    QIANJI_RUNTIME_TOKEN_ENV, SendMessageData,
};
use qianji_ai_agent::{
    AcpError, AgentAvailabilityFeedbackPort, AgentError, AgentSendError, AgentSessionKind, IWorkerTaskManager,
    RuntimeTokenService,
};

use qianji_api_types::{
    AcpConfigOptionDto, AgentErrorCode, AgentModeResponse, ConfigOptionConfirmation, ConversationArtifactKind,
    ConversationResponse, GetConfigOptionsResponse, GetModelInfoResponse, ModelInfoEntry, ModelInfoPayload,
    SetConfigOptionRequest, SetConfigOptionResponse,
};
use qianji_api_types::{
    CloneConversationRequest, CreateConversationRequest, ListConversationsQuery, SearchMessagesQuery,
    SendMessageRequest, UpdateConversationRequest, WebSocketMessage,
};
use qianji_common::{
    AgentKillReason, AgentType, Confirmation, ConversationSource, ConversationStatus, PaginatedResult,
    ProviderWithModel, TimestampMs,
};
use qianji_db::models::{
    AcpSessionRow, AgentMetadataRow, ConversationArtifactRow, ConversationAssistantSnapshotRow, ConversationRow,
    MessageRow, UpdateAgentHandshakeParams, UpsertAgentMetadataParams,
};
use qianji_db::{
    ConversationFilters, ConversationRowUpdate, CreateAcpSessionParams, DbError, IAcpSessionRepository,
    IAgentMetadataRepository, IAssistantDefinitionRepository, IAssistantOverlayRepository,
    IAssistantPreferenceRepository, IConversationRepository, MessageRowUpdate, MessageSearchRow, PersistedSessionState,
    SaveRuntimeStateParams, SqliteAssistantDefinitionRepository, SqliteAssistantOverlayRepository,
    SqliteAssistantPreferenceRepository, UpdateAgentAvailabilitySnapshotParams, UpsertAssistantDefinitionParams,
    UpsertAssistantOverlayParams, UpsertAssistantPreferenceParams, UpsertConversationAssistantSnapshotParams,
    init_database_memory,
};
use qianji_db::{MessagePageCursor, MessagePageDirection, MessagePageParams, MessagePageResult};
use qianji_extension::{AssistantRuleDispatcher, ExtensionError};
use qianji_realtime::EventBroadcaster;
use serde_json::json;
use tokio::sync::{Notify, broadcast};

use crate::service::ConversationService;
use crate::skill_resolver::{FixedSkillResolver, ResolvedAgentSkill, SkillResolver};
use crate::{ConversationAgentTurnRequest, ConversationAgentTurnStatus, ConversationError};

#[path = "service_test/acp_error_recovery_test.rs"]
mod acp_error_recovery_test;

#[path = "service_test/runtime_create_test.rs"]
mod runtime_create_test;

#[derive(Clone, Debug)]
struct RecordedViewSync {
    user_id: String,
    conversation_id: String,
    skill_names: Vec<String>,
}

struct RecordingSkillResolver {
    names: Vec<String>,
    views: Arc<Mutex<Vec<RecordedViewSync>>>,
    view_removals: Arc<Mutex<Vec<(String, String)>>>,
}

struct StaticAssistantDispatcher {
    rules: std::collections::HashMap<String, String>,
}

#[async_trait::async_trait]
impl AssistantRuleDispatcher for StaticAssistantDispatcher {
    async fn read_rule(&self, _user_id: &str, id: &str, _locale: Option<&str>) -> Result<String, ExtensionError> {
        Ok(self.rules.get(id).cloned().unwrap_or_default())
    }

    async fn write_rule(
        &self,
        _user_id: &str,
        _id: &str,
        _locale: Option<&str>,
        _content: &str,
    ) -> Result<(), ExtensionError> {
        Ok(())
    }

    async fn delete_rule(&self, _user_id: &str, _id: &str) -> Result<bool, ExtensionError> {
        Ok(true)
    }

    async fn read_skill(&self, _user_id: &str, _id: &str, _locale: Option<&str>) -> Result<String, ExtensionError> {
        Ok(String::new())
    }

    async fn write_skill(
        &self,
        _user_id: &str,
        _id: &str,
        _locale: Option<&str>,
        _content: &str,
    ) -> Result<(), ExtensionError> {
        Ok(())
    }

    async fn delete_skill(&self, _user_id: &str, _id: &str) -> Result<bool, ExtensionError> {
        Ok(true)
    }
}

impl RecordingSkillResolver {
    fn new(names: Vec<String>) -> Self {
        Self {
            names,
            views: Arc::new(Mutex::new(Vec::new())),
            view_removals: Arc::new(Mutex::new(Vec::new())),
        }
    }
}

#[async_trait::async_trait]
impl SkillResolver for RecordingSkillResolver {
    async fn auto_inject_names(&self) -> Vec<String> {
        self.names.clone()
    }

    async fn resolve_skills(&self, names: &[String]) -> Vec<ResolvedAgentSkill> {
        names
            .iter()
            .map(|name| ResolvedAgentSkill {
                name: name.clone(),
                source_path: std::env::temp_dir().join(format!("skill-source-{name}")),
            })
            .collect()
    }

    async fn sync_skill_view(&self, user_id: &str, conversation_id: &str, skills: &[ResolvedAgentSkill]) -> usize {
        self.views.lock().unwrap().push(RecordedViewSync {
            user_id: user_id.to_owned(),
            conversation_id: conversation_id.to_owned(),
            skill_names: skills.iter().map(|skill| skill.name.clone()).collect(),
        });
        skills.len()
    }

    async fn remove_skill_view(&self, user_id: &str, conversation_id: &str) {
        self.view_removals
            .lock()
            .unwrap()
            .push((user_id.to_owned(), conversation_id.to_owned()));
    }
}

// ── Mock EventBroadcaster ──────────────────────────────────────────

struct MockBroadcaster {
    events: Mutex<Vec<WebSocketMessage<serde_json::Value>>>,
}

impl MockBroadcaster {
    fn new() -> Self {
        Self {
            events: Mutex::new(vec![]),
        }
    }

    fn take_events(&self) -> Vec<WebSocketMessage<serde_json::Value>> {
        std::mem::take(&mut self.events.lock().unwrap())
    }
}

impl EventBroadcaster for MockBroadcaster {
    fn broadcast(&self, event: WebSocketMessage<serde_json::Value>) {
        self.events.lock().unwrap().push(event);
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct RecordedAvailabilityFailure {
    user_id: String,
    agent_id: String,
    code: String,
    message: String,
}

#[derive(Default)]
struct RecordingAvailabilityFeedback {
    successes: Mutex<Vec<(String, String)>>,
    failures: Mutex<Vec<RecordedAvailabilityFailure>>,
}

#[async_trait::async_trait]
impl AgentAvailabilityFeedbackPort for RecordingAvailabilityFeedback {
    async fn record_session_success(&self, user_id: &str, agent_id: &str) -> Result<(), AgentError> {
        self.successes
            .lock()
            .unwrap()
            .push((user_id.to_owned(), agent_id.to_owned()));
        Ok(())
    }

    async fn record_session_failure(
        &self,
        user_id: &str,
        agent_id: &str,
        code: &str,
        message: &str,
    ) -> Result<(), AgentError> {
        self.failures.lock().unwrap().push(RecordedAvailabilityFailure {
            user_id: user_id.to_owned(),
            agent_id: agent_id.to_owned(),
            code: code.to_owned(),
            message: message.to_owned(),
        });
        Ok(())
    }
}

// ── Mock Repository ────────────────────────────────────────────────

struct MockRepo {
    rows: Mutex<Vec<ConversationRow>>,
    messages: Mutex<Vec<MessageRow>>,
    artifacts: Mutex<Vec<ConversationArtifactRow>>,
    assistant_snapshots: Mutex<Vec<ConversationAssistantSnapshotRow>>,
}

impl MockRepo {
    fn new() -> Self {
        Self {
            rows: Mutex::new(vec![]),
            messages: Mutex::new(vec![]),
            artifacts: Mutex::new(vec![]),
            assistant_snapshots: Mutex::new(vec![]),
        }
    }
}

fn message_is_before_cursor(message: &MessageRow, cursor: &MessagePageCursor) -> bool {
    message.created_at < cursor.created_at || (message.created_at == cursor.created_at && message.id < cursor.id)
}

fn message_is_after_cursor(message: &MessageRow, cursor: &MessagePageCursor) -> bool {
    message.created_at > cursor.created_at || (message.created_at == cursor.created_at && message.id > cursor.id)
}

async fn repo_messages_asc(repo: &Arc<MockRepo>, conv_id: &str, limit: u32) -> Vec<MessageRow> {
    repo.list_messages_page(
        "user_1",
        conv_id,
        &MessagePageParams {
            limit,
            direction: MessagePageDirection::InitialLatest,
        },
    )
    .await
    .unwrap()
    .items
}

#[async_trait::async_trait]
impl IConversationRepository for MockRepo {
    async fn get(&self, user_id: &str, id: &str) -> Result<Option<ConversationRow>, qianji_db::DbError> {
        let rows = self.rows.lock().unwrap();
        Ok(rows.iter().find(|r| r.user_id == user_id && r.id == id).cloned())
    }

    async fn owner_user_id(&self, id: &str) -> Result<Option<String>, qianji_db::DbError> {
        let rows = self.rows.lock().unwrap();
        Ok(rows.iter().find(|r| r.id == id).map(|row| row.user_id.clone()))
    }

    async fn create(&self, row: &ConversationRow) -> Result<(), qianji_db::DbError> {
        self.rows.lock().unwrap().push(row.clone());
        Ok(())
    }

    async fn update(&self, user_id: &str, id: &str, updates: &ConversationRowUpdate) -> Result<(), qianji_db::DbError> {
        let mut rows = self.rows.lock().unwrap();
        let row = rows
            .iter_mut()
            .find(|r| r.user_id == user_id && r.id == id)
            .ok_or_else(|| qianji_db::DbError::NotFound(format!("Conversation {id}")))?;

        if let Some(name) = &updates.name {
            row.name = name.clone();
        }
        if let Some(pinned) = updates.pinned {
            row.pinned = pinned;
        }
        if let Some(pinned_at) = &updates.pinned_at {
            row.pinned_at = *pinned_at;
        }
        if let Some(model) = &updates.model {
            row.model = model.clone();
        }
        if let Some(extra) = &updates.extra {
            row.extra = extra.clone();
        }
        if let Some(status) = &updates.status {
            row.status = Some(status.clone());
        }
        if let Some(updated_at) = updates.updated_at {
            row.updated_at = updated_at;
        }
        if let Some(project_id) = &updates.project_id {
            row.project_id = Some(project_id.clone());
        }
        if let Some(folder_id) = &updates.folder_id {
            row.folder_id = Some(folder_id.clone());
        }
        if let Some(name_source) = &updates.name_source {
            row.name_source = Some(name_source.clone());
        }
        Ok(())
    }

    async fn delete(&self, user_id: &str, id: &str) -> Result<(), qianji_db::DbError> {
        let mut rows = self.rows.lock().unwrap();
        let len_before = rows.len();
        rows.retain(|r| !(r.user_id == user_id && r.id == id));
        if rows.len() == len_before {
            return Err(qianji_db::DbError::NotFound(format!("Conversation {id}")));
        }
        Ok(())
    }

    async fn list_paginated(
        &self,
        user_id: &str,
        filters: &ConversationFilters,
    ) -> Result<PaginatedResult<ConversationRow>, qianji_db::DbError> {
        let rows = self.rows.lock().unwrap();
        let matched: Vec<_> = rows
            .iter()
            .filter(|r| r.user_id == user_id)
            .filter(|r| {
                filters
                    .source
                    .as_ref()
                    .is_none_or(|s| r.source.as_deref() == Some(s.as_str()))
            })
            .filter(|r| filters.pinned.as_ref().is_none_or(|&p| r.pinned == p))
            .cloned()
            .collect();
        let total = matched.len() as u64;
        let limit = filters.effective_limit() as usize;
        let items: Vec<_> = matched.into_iter().take(limit).collect();
        let has_more = (total as usize) > limit;
        Ok(PaginatedResult { items, total, has_more })
    }

    async fn find_by_source_and_chat(
        &self,
        _user_id: &str,
        _source: &str,
        _chat_id: &str,
        _agent_type: &str,
    ) -> Result<Option<ConversationRow>, qianji_db::DbError> {
        Ok(None)
    }

    async fn list_by_cron_job(
        &self,
        _user_id: &str,
        _cron_job_id: &str,
    ) -> Result<Vec<ConversationRow>, qianji_db::DbError> {
        Ok(vec![])
    }

    async fn list_associated(
        &self,
        _user_id: &str,
        _conversation_id: &str,
    ) -> Result<Vec<ConversationRow>, qianji_db::DbError> {
        Ok(vec![])
    }

    async fn get_assistant_snapshot(
        &self,
        _user_id: &str,
        conversation_id: &str,
    ) -> Result<Option<ConversationAssistantSnapshotRow>, qianji_db::DbError> {
        let rows = self.assistant_snapshots.lock().unwrap();
        Ok(rows.iter().find(|row| row.conversation_id == conversation_id).cloned())
    }

    async fn upsert_assistant_snapshot(
        &self,
        _user_id: &str,
        params: &UpsertConversationAssistantSnapshotParams<'_>,
    ) -> Result<Option<ConversationAssistantSnapshotRow>, qianji_db::DbError> {
        let row = ConversationAssistantSnapshotRow {
            conversation_id: params.conversation_id.to_owned(),
            assistant_definition_id: params.assistant_definition_id.to_owned(),
            assistant_id: params.assistant_id.to_owned(),
            assistant_source: params.assistant_source.to_owned(),
            agent_id: params.agent_id.to_owned(),
            rules_content: params.rules_content.to_owned(),
            default_model_mode: params.default_model_mode.to_owned(),
            resolved_model_id: params.resolved_model_id.map(ToOwned::to_owned),
            default_permission_mode: params.default_permission_mode.to_owned(),
            resolved_permission_value: params.resolved_permission_value.map(ToOwned::to_owned),
            default_thought_level_mode: params.default_thought_level_mode.to_owned(),
            resolved_thought_level_value: params.resolved_thought_level_value.map(ToOwned::to_owned),
            default_skills_mode: params.default_skills_mode.to_owned(),
            resolved_skill_ids: params.resolved_skill_ids.to_owned(),
            resolved_disabled_builtin_skill_ids: params.resolved_disabled_builtin_skill_ids.to_owned(),
            default_mcps_mode: params.default_mcps_mode.to_owned(),
            resolved_mcp_ids: params.resolved_mcp_ids.to_owned(),
            created_at: 1,
            updated_at: 1,
        };
        let mut rows = self.assistant_snapshots.lock().unwrap();
        rows.retain(|existing| existing.conversation_id != params.conversation_id);
        rows.push(row.clone());
        Ok(Some(row))
    }

    async fn delete_assistant_snapshot(
        &self,
        _user_id: &str,
        conversation_id: &str,
    ) -> Result<bool, qianji_db::DbError> {
        let mut rows = self.assistant_snapshots.lock().unwrap();
        let before = rows.len();
        rows.retain(|row| row.conversation_id != conversation_id);
        Ok(rows.len() != before)
    }

    async fn list_messages_page(
        &self,
        _user_id: &str,
        conv_id: &str,
        params: &MessagePageParams,
    ) -> Result<MessagePageResult, qianji_db::DbError> {
        let messages = self.messages.lock().unwrap();
        let mut matched: Vec<_> = messages
            .iter()
            .filter(|message| message.conversation_id == conv_id)
            .filter(|message| !matches!(message.r#type.as_str(), "cron_trigger" | "skill_suggest"))
            .cloned()
            .collect();
        matched.sort_by(|a, b| (a.created_at, &a.id).cmp(&(b.created_at, &b.id)));

        let limit = params.limit.max(1) as usize;
        let items = match &params.direction {
            MessagePageDirection::InitialLatest => {
                let start = matched.len().saturating_sub(limit);
                matched[start..].to_vec()
            }
            MessagePageDirection::Before { cursor } => matched
                .iter()
                .filter(|message| message_is_before_cursor(message, cursor))
                .rev()
                .take(limit)
                .cloned()
                .collect::<Vec<_>>()
                .into_iter()
                .rev()
                .collect(),
            MessagePageDirection::After { cursor } => matched
                .iter()
                .filter(|message| message_is_after_cursor(message, cursor))
                .take(limit)
                .cloned()
                .collect(),
            MessagePageDirection::Anchor { message_id } => {
                let anchor = matched
                    .iter()
                    .find(|message| message.id == *message_id)
                    .cloned()
                    .ok_or_else(|| qianji_db::DbError::NotFound(format!("Message {message_id}")))?;
                let before_take = (limit.saturating_sub(1)) / 2;
                let anchor_cursor = MessagePageCursor::from(&anchor);
                let before = matched
                    .iter()
                    .filter(|message| message_is_before_cursor(message, &anchor_cursor))
                    .rev()
                    .take(before_take)
                    .cloned()
                    .collect::<Vec<_>>();
                let after = matched
                    .iter()
                    .filter(|message| message_is_after_cursor(message, &anchor_cursor))
                    .take(limit.saturating_sub(1 + before.len()))
                    .cloned()
                    .collect::<Vec<_>>();
                before
                    .into_iter()
                    .rev()
                    .chain(std::iter::once(anchor))
                    .chain(after)
                    .collect()
            }
        };
        let has_more_before = items.first().is_some_and(|first| {
            let cursor = MessagePageCursor::from(first);
            matched.iter().any(|message| message_is_before_cursor(message, &cursor))
        });
        let has_more_after = items.last().is_some_and(|last| {
            let cursor = MessagePageCursor::from(last);
            matched.iter().any(|message| message_is_after_cursor(message, &cursor))
        });

        Ok(MessagePageResult {
            items,
            has_more_before,
            has_more_after,
        })
    }

    async fn insert_message(&self, _user_id: &str, message: &MessageRow) -> Result<(), qianji_db::DbError> {
        let mut messages = self.messages.lock().unwrap();
        messages.push(message.clone());
        Ok(())
    }

    async fn update_message(
        &self,
        _user_id: &str,
        conversation_id: &str,
        id: &str,
        updates: &MessageRowUpdate,
    ) -> Result<(), qianji_db::DbError> {
        let mut messages = self.messages.lock().unwrap();
        let message = messages
            .iter_mut()
            .find(|message| message.conversation_id == conversation_id && message.id == id)
            .ok_or_else(|| qianji_db::DbError::NotFound(format!("Message {id}")))?;

        if let Some(content) = &updates.content {
            message.content = content.clone();
        }
        if let Some(status) = &updates.status {
            message.status = status.clone();
        }
        if let Some(hidden) = updates.hidden {
            message.hidden = hidden;
        }
        Ok(())
    }

    async fn delete_messages_by_conversation(&self, _user_id: &str, conv_id: &str) -> Result<(), qianji_db::DbError> {
        self.messages
            .lock()
            .unwrap()
            .retain(|message| message.conversation_id != conv_id);
        Ok(())
    }

    async fn get_message_by_msg_id(
        &self,
        _user_id: &str,
        conv_id: &str,
        msg_id: &str,
        msg_type: &str,
    ) -> Result<Option<MessageRow>, qianji_db::DbError> {
        let messages = self.messages.lock().unwrap();
        Ok(messages
            .iter()
            .find(|message| {
                message.conversation_id == conv_id
                    && message.msg_id.as_deref() == Some(msg_id)
                    && message.r#type == msg_type
            })
            .cloned())
    }

    async fn list_stale_runtime_messages(&self) -> Result<Vec<qianji_db::StaleRuntimeMessageRow>, qianji_db::DbError> {
        let messages = self.messages.lock().unwrap();
        let rows = self.rows.lock().unwrap();
        Ok(messages
            .iter()
            .filter(|message| {
                message.position.as_deref() == Some("left")
                    && matches!(message.status.as_deref(), Some("work" | "pending"))
                    && matches!(message.r#type.as_str(), "text" | "thinking")
            })
            .filter_map(|message| {
                let user_id = rows
                    .iter()
                    .find(|row| row.id == message.conversation_id)
                    .map(|row| row.user_id.clone())?;
                Some(qianji_db::StaleRuntimeMessageRow {
                    user_id,
                    message: message.clone(),
                })
            })
            .collect())
    }

    async fn search_messages(
        &self,
        _user_id: &str,
        _keyword: &str,
        _page: u32,
        _page_size: u32,
    ) -> Result<PaginatedResult<MessageSearchRow>, qianji_db::DbError> {
        Ok(PaginatedResult {
            items: vec![],
            total: 0,
            has_more: false,
        })
    }

    async fn list_artifacts(
        &self,
        _user_id: &str,
        conversation_id: &str,
    ) -> Result<Vec<ConversationArtifactRow>, qianji_db::DbError> {
        Ok(self
            .artifacts
            .lock()
            .unwrap()
            .iter()
            .filter(|artifact| artifact.conversation_id == conversation_id)
            .cloned()
            .collect())
    }

    async fn get_artifact(
        &self,
        _user_id: &str,
        conversation_id: &str,
        artifact_id: &str,
    ) -> Result<Option<ConversationArtifactRow>, qianji_db::DbError> {
        Ok(self
            .artifacts
            .lock()
            .unwrap()
            .iter()
            .find(|artifact| artifact.conversation_id == conversation_id && artifact.id == artifact_id)
            .cloned())
    }

    async fn upsert_artifact(
        &self,
        _user_id: &str,
        artifact: &ConversationArtifactRow,
    ) -> Result<ConversationArtifactRow, qianji_db::DbError> {
        let mut artifacts = self.artifacts.lock().unwrap();
        if let Some(existing) = artifacts.iter_mut().find(|row| row.id == artifact.id) {
            *existing = artifact.clone();
            return Ok(existing.clone());
        }
        artifacts.push(artifact.clone());
        Ok(artifact.clone())
    }

    async fn update_artifact_status(
        &self,
        _user_id: &str,
        conversation_id: &str,
        artifact_id: &str,
        status: &str,
        updated_at: TimestampMs,
    ) -> Result<Option<ConversationArtifactRow>, qianji_db::DbError> {
        let mut artifacts = self.artifacts.lock().unwrap();
        let Some(existing) = artifacts
            .iter_mut()
            .find(|artifact| artifact.conversation_id == conversation_id && artifact.id == artifact_id)
        else {
            return Ok(None);
        };
        existing.status = status.to_owned();
        existing.updated_at = updated_at;
        Ok(Some(existing.clone()))
    }

    async fn mark_skill_suggest_artifacts_saved(
        &self,
        _user_id: &str,
        cron_job_id: &str,
        updated_at: TimestampMs,
    ) -> Result<Vec<ConversationArtifactRow>, qianji_db::DbError> {
        let mut artifacts = self.artifacts.lock().unwrap();
        let mut updated = Vec::new();
        for artifact in artifacts
            .iter_mut()
            .filter(|artifact| artifact.cron_job_id.as_deref() == Some(cron_job_id))
        {
            artifact.status = "saved".into();
            artifact.updated_at = updated_at;
            updated.push(artifact.clone());
        }
        Ok(updated)
    }

    async fn delete_artifacts_by_conversation(
        &self,
        _user_id: &str,
        conversation_id: &str,
    ) -> Result<(), qianji_db::DbError> {
        self.artifacts
            .lock()
            .unwrap()
            .retain(|artifact| artifact.conversation_id != conversation_id);
        Ok(())
    }

    async fn list_legacy_cron_trigger_messages(
        &self,
        _user_id: &str,
        conversation_id: &str,
    ) -> Result<Vec<MessageRow>, qianji_db::DbError> {
        Ok(self
            .messages
            .lock()
            .unwrap()
            .iter()
            .filter(|message| message.conversation_id == conversation_id && message.r#type == "cron_trigger")
            .cloned()
            .collect())
    }
}

// ── Helpers ────────────────────────────────────────────────────────

/// Stub repository for tests. Builtin rows mirror the ids used by the
/// migration seed so assistant id-resolution tests exercise the same
/// boundary as the SQLite repository.
struct StubAgentMetadataRepo;

fn stub_agent_metadata_rows() -> Vec<AgentMetadataRow> {
    [
        ("2d23ff1c", Some("claude"), "acp", "Claude Code", 100),
        ("8e1acf31", Some("codex"), "acp", "Codex CLI", 110),
        ("cc126dd5", Some("gemini"), "acp", "Gemini CLI", 120),
        ("632f31d2", None, "qianjirs", "Qianji CLI", 200),
        ("b7e8a9c4", Some("openclaw"), "acp", "OpenClaw", 3140),
        ("f9f61666", None, "openclaw-gateway", "OpenClaw Gateway", 3150),
        ("custom-acp-1", None, "acp", "My Custom ACP", 1500),
    ]
    .into_iter()
    .map(|(id, backend, agent_type, name, sort_order)| AgentMetadataRow {
        id: id.to_owned(),
        user_id: None,
        icon: None,
        name: name.to_owned(),
        name_i18n: None,
        description: None,
        description_i18n: None,
        backend: backend.map(ToOwned::to_owned),
        agent_type: agent_type.to_owned(),
        agent_source: if id.starts_with("custom-") { "custom" } else { "builtin" }.to_owned(),
        agent_source_info: None,
        enabled: true,
        command: backend.map(ToOwned::to_owned),
        args: Some("[]".to_owned()),
        env: Some("[]".to_owned()),
        native_skills_dirs: None,
        skill_delivery: None,
        behavior_policy: None,
        yolo_id: None,
        agent_capabilities: None,
        auth_methods: None,
        config_options: None,
        available_modes: None,
        available_models: None,
        available_commands: None,
        sort_order,
        last_check_status: None,
        last_check_kind: None,
        last_check_error_code: None,
        last_check_error_message: None,
        last_check_guidance: None,
        last_check_latency_ms: None,
        last_check_at: None,
        last_success_at: None,
        last_failure_at: None,
        command_override: None,
        env_override: None,
        created_at: 1,
        updated_at: 1,
    })
    .collect()
}

#[async_trait::async_trait]
impl IAgentMetadataRepository for StubAgentMetadataRepo {
    async fn list_all(&self) -> Result<Vec<AgentMetadataRow>, DbError> {
        Ok(stub_agent_metadata_rows())
    }
    async fn list_all_for_user(&self, _user_id: &str) -> Result<Vec<AgentMetadataRow>, DbError> {
        self.list_all().await
    }
    async fn get(&self, id: &str) -> Result<Option<AgentMetadataRow>, DbError> {
        Ok(stub_agent_metadata_rows().into_iter().find(|row| row.id == id))
    }
    async fn get_for_user(&self, _user_id: &str, id: &str) -> Result<Option<AgentMetadataRow>, DbError> {
        self.get(id).await
    }
    async fn find_by_source_and_name(
        &self,
        _agent_source: &str,
        _name: &str,
    ) -> Result<Option<AgentMetadataRow>, DbError> {
        Ok(None)
    }
    async fn find_by_source_and_name_for_user(
        &self,
        _user_id: &str,
        agent_source: &str,
        name: &str,
    ) -> Result<Option<AgentMetadataRow>, DbError> {
        self.find_by_source_and_name(agent_source, name).await
    }
    async fn find_builtin_by_backend(&self, backend: &str) -> Result<Option<AgentMetadataRow>, DbError> {
        Ok(stub_agent_metadata_rows()
            .into_iter()
            .find(|row| row.agent_source == "builtin" && row.backend.as_deref() == Some(backend)))
    }
    async fn find_builtin_by_backend_for_user(
        &self,
        _user_id: &str,
        backend: &str,
    ) -> Result<Option<AgentMetadataRow>, DbError> {
        self.find_builtin_by_backend(backend).await
    }
    async fn upsert(&self, _params: &UpsertAgentMetadataParams<'_>) -> Result<AgentMetadataRow, DbError> {
        Err(DbError::Init("stub".into()))
    }
    async fn upsert_for_user(
        &self,
        _user_id: &str,
        params: &UpsertAgentMetadataParams<'_>,
    ) -> Result<AgentMetadataRow, DbError> {
        self.upsert(params).await
    }
    async fn apply_handshake(
        &self,
        _id: &str,
        _params: &UpdateAgentHandshakeParams<'_>,
    ) -> Result<Option<AgentMetadataRow>, DbError> {
        Ok(None)
    }
    async fn apply_handshake_for_user(
        &self,
        _user_id: &str,
        id: &str,
        params: &UpdateAgentHandshakeParams<'_>,
    ) -> Result<Option<AgentMetadataRow>, DbError> {
        self.apply_handshake(id, params).await
    }
    async fn update_availability_snapshot(
        &self,
        _id: &str,
        _params: &UpdateAgentAvailabilitySnapshotParams<'_>,
    ) -> Result<Option<AgentMetadataRow>, DbError> {
        Ok(None)
    }
    async fn update_availability_snapshot_for_user(
        &self,
        _user_id: &str,
        id: &str,
        params: &UpdateAgentAvailabilitySnapshotParams<'_>,
    ) -> Result<Option<AgentMetadataRow>, DbError> {
        self.update_availability_snapshot(id, params).await
    }
    async fn update_agent_overrides(
        &self,
        _id: &str,
        _command_override: Option<&str>,
        _env_override: Option<&str>,
    ) -> Result<(), DbError> {
        Ok(())
    }
    async fn update_agent_overrides_for_user(
        &self,
        _user_id: &str,
        id: &str,
        command_override: Option<&str>,
        env_override: Option<&str>,
    ) -> Result<(), DbError> {
        self.update_agent_overrides(id, command_override, env_override).await
    }
    async fn set_enabled(&self, _id: &str, _enabled: bool) -> Result<bool, DbError> {
        Ok(false)
    }
    async fn set_enabled_for_user(&self, _user_id: &str, id: &str, enabled: bool) -> Result<bool, DbError> {
        self.set_enabled(id, enabled).await
    }
    async fn delete(&self, _id: &str) -> Result<bool, DbError> {
        Ok(false)
    }
    async fn delete_for_user(&self, _user_id: &str, id: &str) -> Result<bool, DbError> {
        self.delete(id).await
    }
}

/// Metadata repo used by custom-workspace skill-link tests. It models the
/// builtin Claude ACP row whose native skill directory is `.claude/skills`.
struct ClaudeNativeSkillMetadataRepo;

fn claude_metadata_row() -> AgentMetadataRow {
    AgentMetadataRow {
        id: "agent-claude".into(),
        user_id: None,
        icon: None,
        name: "Claude Code".into(),
        name_i18n: None,
        description: None,
        description_i18n: None,
        backend: Some("claude".into()),
        agent_type: "acp".into(),
        agent_source: "builtin".into(),
        agent_source_info: Some("{}".into()),
        enabled: true,
        command: Some("claude".into()),
        args: Some("[]".into()),
        env: Some("[]".into()),
        native_skills_dirs: Some(r#"[".claude/skills"]"#.into()),
        skill_delivery: None,
        behavior_policy: Some("{}".into()),
        yolo_id: Some("bypassPermissions".into()),
        agent_capabilities: None,
        auth_methods: None,
        config_options: None,
        available_modes: None,
        available_models: None,
        available_commands: None,
        sort_order: 0,
        last_check_status: None,
        last_check_kind: None,
        last_check_error_code: None,
        last_check_error_message: None,
        last_check_guidance: None,
        last_check_latency_ms: None,
        last_check_at: None,
        last_success_at: None,
        last_failure_at: None,
        command_override: None,
        env_override: None,
        created_at: 1,
        updated_at: 1,
    }
}

#[async_trait::async_trait]
impl IAgentMetadataRepository for ClaudeNativeSkillMetadataRepo {
    async fn list_all(&self) -> Result<Vec<AgentMetadataRow>, DbError> {
        Ok(vec![claude_metadata_row()])
    }
    async fn list_all_for_user(&self, _user_id: &str) -> Result<Vec<AgentMetadataRow>, DbError> {
        self.list_all().await
    }
    async fn get(&self, id: &str) -> Result<Option<AgentMetadataRow>, DbError> {
        Ok((id == "agent-claude").then(claude_metadata_row))
    }
    async fn get_for_user(&self, _user_id: &str, id: &str) -> Result<Option<AgentMetadataRow>, DbError> {
        self.get(id).await
    }
    async fn find_by_source_and_name(
        &self,
        agent_source: &str,
        name: &str,
    ) -> Result<Option<AgentMetadataRow>, DbError> {
        Ok((agent_source == "builtin" && name == "Claude Code").then(claude_metadata_row))
    }
    async fn find_by_source_and_name_for_user(
        &self,
        _user_id: &str,
        agent_source: &str,
        name: &str,
    ) -> Result<Option<AgentMetadataRow>, DbError> {
        self.find_by_source_and_name(agent_source, name).await
    }
    async fn find_builtin_by_backend(&self, backend: &str) -> Result<Option<AgentMetadataRow>, DbError> {
        Ok((backend == "claude").then(claude_metadata_row))
    }
    async fn find_builtin_by_backend_for_user(
        &self,
        _user_id: &str,
        backend: &str,
    ) -> Result<Option<AgentMetadataRow>, DbError> {
        self.find_builtin_by_backend(backend).await
    }
    async fn upsert(&self, _params: &UpsertAgentMetadataParams<'_>) -> Result<AgentMetadataRow, DbError> {
        Err(DbError::Init("stub".into()))
    }
    async fn upsert_for_user(
        &self,
        _user_id: &str,
        params: &UpsertAgentMetadataParams<'_>,
    ) -> Result<AgentMetadataRow, DbError> {
        self.upsert(params).await
    }
    async fn apply_handshake(
        &self,
        _id: &str,
        _params: &UpdateAgentHandshakeParams<'_>,
    ) -> Result<Option<AgentMetadataRow>, DbError> {
        Ok(None)
    }
    async fn apply_handshake_for_user(
        &self,
        _user_id: &str,
        id: &str,
        params: &UpdateAgentHandshakeParams<'_>,
    ) -> Result<Option<AgentMetadataRow>, DbError> {
        self.apply_handshake(id, params).await
    }
    async fn update_availability_snapshot(
        &self,
        _id: &str,
        _params: &UpdateAgentAvailabilitySnapshotParams<'_>,
    ) -> Result<Option<AgentMetadataRow>, DbError> {
        Ok(None)
    }
    async fn update_availability_snapshot_for_user(
        &self,
        _user_id: &str,
        id: &str,
        params: &UpdateAgentAvailabilitySnapshotParams<'_>,
    ) -> Result<Option<AgentMetadataRow>, DbError> {
        self.update_availability_snapshot(id, params).await
    }
    async fn update_agent_overrides(
        &self,
        _id: &str,
        _command_override: Option<&str>,
        _env_override: Option<&str>,
    ) -> Result<(), DbError> {
        Ok(())
    }
    async fn update_agent_overrides_for_user(
        &self,
        _user_id: &str,
        id: &str,
        command_override: Option<&str>,
        env_override: Option<&str>,
    ) -> Result<(), DbError> {
        self.update_agent_overrides(id, command_override, env_override).await
    }
    async fn set_enabled(&self, _id: &str, _enabled: bool) -> Result<bool, DbError> {
        Ok(false)
    }
    async fn set_enabled_for_user(&self, _user_id: &str, id: &str, enabled: bool) -> Result<bool, DbError> {
        self.set_enabled(id, enabled).await
    }
    async fn delete(&self, _id: &str) -> Result<bool, DbError> {
        Ok(false)
    }
    async fn delete_for_user(&self, _user_id: &str, id: &str) -> Result<bool, DbError> {
        self.delete(id).await
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct RuntimeStateSaveCall {
    conversation_id: String,
    current_mode_id: Option<Option<String>>,
    current_model_id: Option<Option<String>>,
    config_selections_json: Option<Option<String>>,
}

#[derive(Default)]
struct StubAcpSessionRepo {
    create_calls: Mutex<Vec<CreateAcpSessionCall>>,
    runtime_state_saves: Mutex<Vec<RuntimeStateSaveCall>>,
    session_id: Mutex<Option<String>>,
    runtime_state: Mutex<Option<PersistedSessionState>>,
}

impl StubAcpSessionRepo {
    fn create_calls(&self) -> Vec<CreateAcpSessionCall> {
        self.create_calls.lock().unwrap().clone()
    }

    fn with_session_id(session_id: impl Into<String>) -> Self {
        Self {
            create_calls: Mutex::new(Vec::new()),
            runtime_state_saves: Mutex::new(Vec::new()),
            session_id: Mutex::new(Some(session_id.into())),
            runtime_state: Mutex::new(None),
        }
    }

    fn with_runtime_state(state: PersistedSessionState) -> Self {
        Self {
            create_calls: Mutex::new(Vec::new()),
            runtime_state_saves: Mutex::new(Vec::new()),
            session_id: Mutex::new(None),
            runtime_state: Mutex::new(Some(state)),
        }
    }

    fn runtime_state_saves(&self) -> Vec<RuntimeStateSaveCall> {
        self.runtime_state_saves.lock().unwrap().clone()
    }

    fn row_for(&self, conversation_id: &str) -> AcpSessionRow {
        AcpSessionRow {
            conversation_id: conversation_id.to_owned(),
            agent_source: "builtin".into(),
            agent_id: "codex".into(),
            session_id: self.session_id.lock().unwrap().clone(),
            session_status: "idle".into(),
            session_config: "{}".into(),
            last_active_at: None,
            suspended_at: None,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct CreateAcpSessionCall {
    user_id: String,
    conversation_id: String,
    agent_source: String,
    agent_id: String,
}

#[async_trait::async_trait]
impl IAcpSessionRepository for StubAcpSessionRepo {
    async fn get_for_user(&self, _user_id: &str, conversation_id: &str) -> Result<Option<AcpSessionRow>, DbError> {
        Ok(Some(self.row_for(conversation_id)))
    }
    async fn create(&self, params: &CreateAcpSessionParams<'_>) -> Result<AcpSessionRow, DbError> {
        self.create_calls.lock().unwrap().push(CreateAcpSessionCall {
            user_id: params.user_id.to_owned(),
            conversation_id: params.conversation_id.to_owned(),
            agent_source: params.agent_source.to_owned(),
            agent_id: params.agent_id.to_owned(),
        });
        // Return a synthetic row so `ConversationService::create` can
        // succeed for ACP conversations in unit tests.
        Ok(AcpSessionRow {
            conversation_id: params.conversation_id.to_owned(),
            agent_source: params.agent_source.to_owned(),
            agent_id: params.agent_id.to_owned(),
            session_id: self.session_id.lock().unwrap().clone(),
            session_status: "idle".into(),
            session_config: "{}".into(),
            last_active_at: None,
            suspended_at: None,
        })
    }
    async fn update_session_id_for_user(
        &self,
        _user_id: &str,
        _conversation_id: &str,
        session_id: &str,
    ) -> Result<bool, DbError> {
        *self.session_id.lock().unwrap() = Some(session_id.to_owned());
        Ok(true)
    }
    async fn clear_session_id_for_user(&self, _user_id: &str, _conversation_id: &str) -> Result<bool, DbError> {
        *self.session_id.lock().unwrap() = None;
        Ok(true)
    }
    async fn delete_for_user(&self, _user_id: &str, _conversation_id: &str) -> Result<bool, DbError> {
        Ok(false)
    }
    async fn load_runtime_state_for_user(
        &self,
        _user_id: &str,
        _conversation_id: &str,
    ) -> Result<Option<PersistedSessionState>, DbError> {
        Ok(Some(self.runtime_state.lock().unwrap().clone().unwrap_or(
            PersistedSessionState {
                current_model_id: Some("deepseek-v4-pro".to_owned()),
                ..Default::default()
            },
        )))
    }
    async fn save_runtime_state_for_user(
        &self,
        _user_id: &str,
        conversation_id: &str,
        params: &SaveRuntimeStateParams<'_>,
    ) -> Result<bool, DbError> {
        self.runtime_state_saves.lock().unwrap().push(RuntimeStateSaveCall {
            conversation_id: conversation_id.to_owned(),
            current_mode_id: params.current_mode_id.map(|outer| outer.map(ToOwned::to_owned)),
            current_model_id: params.current_model_id.map(|outer| outer.map(ToOwned::to_owned)),
            config_selections_json: params.config_selections_json.map(|outer| outer.map(ToOwned::to_owned)),
        });
        Ok(true)
    }
}

#[tokio::test]
async fn clear_acp_context_anchor_drops_only_the_resume_anchor() {
    let runtime_state = PersistedSessionState {
        current_mode_id: Some("full_auto".to_owned()),
        current_model_id: Some("model-preserved".to_owned()),
        ..Default::default()
    };
    let acp_session_repo = Arc::new(StubAcpSessionRepo {
        create_calls: Mutex::new(Vec::new()),
        runtime_state_saves: Mutex::new(Vec::new()),
        session_id: Mutex::new(Some("session-to-clear".to_owned())),
        runtime_state: Mutex::new(Some(runtime_state.clone())),
    });
    let (service, _broadcaster, _repo, _task_manager) = make_service_with_resolver_and_acp_session_repo(
        Arc::new(FixedSkillResolver { names: vec![] }),
        acp_session_repo.clone(),
    );
    let conversation = service.create("user_1", make_create_req()).await.unwrap();

    assert!(
        service
            .supports_acp_context_reset("user_1", &conversation.id)
            .await
            .unwrap()
    );
    assert!(
        service
            .clear_acp_context_anchor("user_1", &conversation.id)
            .await
            .unwrap()
    );
    assert_eq!(*acp_session_repo.session_id.lock().unwrap(), None);
    assert_eq!(*acp_session_repo.runtime_state.lock().unwrap(), Some(runtime_state));
}

#[tokio::test]
async fn qianjirs_conversation_does_not_support_acp_context_reset() {
    let (service, _broadcaster, _repo, _task_manager) = make_service();
    let request = serde_json::from_value(json!({
        "type": "qianjirs",
        "extra": { "workspace": ensure_test_workspace_path() }
    }))
    .unwrap();
    let conversation = service.create("user_1", request).await.unwrap();

    assert!(
        !service
            .supports_acp_context_reset("user_1", &conversation.id)
            .await
            .unwrap()
    );
}

fn make_service() -> (
    ConversationService,
    Arc<MockBroadcaster>,
    Arc<MockRepo>,
    Arc<dyn IWorkerTaskManager>,
) {
    make_service_with_resolver(Arc::new(FixedSkillResolver { names: vec![] }))
}

fn make_service_with_resolver(
    skill_resolver: Arc<dyn crate::skill_resolver::SkillResolver>,
) -> (
    ConversationService,
    Arc<MockBroadcaster>,
    Arc<MockRepo>,
    Arc<dyn IWorkerTaskManager>,
) {
    make_service_with_resolver_and_acp_session_repo(skill_resolver, Arc::new(StubAcpSessionRepo::default()))
}

fn make_service_with_resolver_and_acp_session_repo(
    skill_resolver: Arc<dyn crate::skill_resolver::SkillResolver>,
    acp_session_repo: Arc<dyn IAcpSessionRepository>,
) -> (
    ConversationService,
    Arc<MockBroadcaster>,
    Arc<MockRepo>,
    Arc<dyn IWorkerTaskManager>,
) {
    let repo = Arc::new(MockRepo::new());
    let broadcaster = Arc::new(MockBroadcaster::new());
    let agent_metadata_repo: Arc<dyn IAgentMetadataRepository> = Arc::new(StubAgentMetadataRepo);
    let task_mgr: Arc<dyn IWorkerTaskManager> = Arc::new(MockTaskManager::new());
    let svc = ConversationService::new(
        std::env::temp_dir(),
        broadcaster.clone(),
        skill_resolver,
        task_mgr.clone(),
        repo.clone(),
        agent_metadata_repo,
        acp_session_repo,
    );
    (svc, broadcaster, repo, task_mgr)
}

fn make_service_with_workspace_root(
    workspace_root: PathBuf,
) -> (
    ConversationService,
    Arc<MockBroadcaster>,
    Arc<MockRepo>,
    Arc<dyn IWorkerTaskManager>,
) {
    let repo = Arc::new(MockRepo::new());
    let broadcaster = Arc::new(MockBroadcaster::new());
    let agent_metadata_repo: Arc<dyn IAgentMetadataRepository> = Arc::new(StubAgentMetadataRepo);
    let task_mgr: Arc<dyn IWorkerTaskManager> = Arc::new(MockTaskManager::new());
    let svc = ConversationService::new(
        workspace_root,
        broadcaster.clone(),
        Arc::new(FixedSkillResolver { names: vec![] }),
        task_mgr.clone(),
        repo.clone(),
        agent_metadata_repo,
        Arc::new(StubAcpSessionRepo::default()),
    );
    (svc, broadcaster, repo, task_mgr)
}

fn make_service_with_resolver_and_agent_metadata_repo(
    skill_resolver: Arc<dyn crate::skill_resolver::SkillResolver>,
    agent_metadata_repo: Arc<dyn IAgentMetadataRepository>,
) -> (
    ConversationService,
    Arc<MockBroadcaster>,
    Arc<MockRepo>,
    Arc<dyn IWorkerTaskManager>,
) {
    let repo = Arc::new(MockRepo::new());
    let broadcaster = Arc::new(MockBroadcaster::new());
    let task_mgr: Arc<dyn IWorkerTaskManager> = Arc::new(MockTaskManager::new());
    let svc = ConversationService::new(
        std::env::temp_dir(),
        broadcaster.clone(),
        skill_resolver,
        task_mgr.clone(),
        repo.clone(),
        agent_metadata_repo,
        Arc::new(StubAcpSessionRepo::default()),
    );
    (svc, broadcaster, repo, task_mgr)
}

fn make_service_with_mock_task_manager(
    task_mgr: Arc<MockTaskManager>,
) -> (ConversationService, Arc<MockBroadcaster>, Arc<MockRepo>) {
    let repo = Arc::new(MockRepo::new());
    let broadcaster = Arc::new(MockBroadcaster::new());
    let agent_metadata_repo: Arc<dyn IAgentMetadataRepository> = Arc::new(StubAgentMetadataRepo);
    let task_mgr_dyn: Arc<dyn IWorkerTaskManager> = task_mgr;
    let svc = ConversationService::new(
        std::env::temp_dir(),
        broadcaster.clone(),
        Arc::new(FixedSkillResolver { names: vec![] }),
        task_mgr_dyn,
        repo.clone(),
        agent_metadata_repo,
        Arc::new(StubAcpSessionRepo::default()),
    );
    (svc, broadcaster, repo)
}

async fn make_service_with_mock_task_manager_and_assistant_support(
    task_mgr: Arc<MockTaskManager>,
) -> (
    ConversationService,
    Arc<MockBroadcaster>,
    Arc<MockRepo>,
    Arc<SqliteAssistantDefinitionRepository>,
    Arc<SqliteAssistantOverlayRepository>,
    Arc<dyn IAssistantPreferenceRepository>,
) {
    let (svc, broadcaster, repo) = make_service_with_mock_task_manager(task_mgr);
    let db = init_database_memory().await.unwrap();
    seed_test_user(db.pool(), "user-1").await;
    seed_test_user(db.pool(), "user_1").await;
    let definition_repo = Arc::new(SqliteAssistantDefinitionRepository::new(db.pool().clone()));
    let overlay_repo = Arc::new(SqliteAssistantOverlayRepository::new(db.pool().clone()));
    let preference_repo: Arc<dyn IAssistantPreferenceRepository> =
        Arc::new(SqliteAssistantPreferenceRepository::new(db.pool().clone()));

    svc.with_assistant_definition_repo(definition_repo.clone());
    svc.with_assistant_state_repo(overlay_repo.clone());
    svc.with_assistant_preference_repo(preference_repo.clone());

    (svc, broadcaster, repo, definition_repo, overlay_repo, preference_repo)
}

async fn make_service_with_assistant_support(
    skill_resolver: Arc<dyn crate::skill_resolver::SkillResolver>,
    dispatcher: Arc<dyn AssistantRuleDispatcher>,
) -> (
    ConversationService,
    Arc<MockBroadcaster>,
    Arc<MockRepo>,
    Arc<SqliteAssistantDefinitionRepository>,
    Arc<SqliteAssistantOverlayRepository>,
    Arc<dyn IAssistantPreferenceRepository>,
) {
    let (svc, broadcaster, repo, _task_mgr) = make_service_with_resolver(skill_resolver);
    let db = init_database_memory().await.unwrap();
    seed_test_user(db.pool(), "user-1").await;
    seed_test_user(db.pool(), "user_1").await;
    let definition_repo = Arc::new(SqliteAssistantDefinitionRepository::new(db.pool().clone()));
    let state_repo = Arc::new(SqliteAssistantOverlayRepository::new(db.pool().clone()));
    let preference_repo: Arc<dyn IAssistantPreferenceRepository> =
        Arc::new(SqliteAssistantPreferenceRepository::new(db.pool().clone()));

    svc.with_assistant_definition_repo(definition_repo.clone());
    svc.with_assistant_state_repo(state_repo.clone());
    svc.with_assistant_preference_repo(preference_repo.clone());
    svc.with_assistant_dispatcher(dispatcher);

    (svc, broadcaster, repo, definition_repo, state_repo, preference_repo)
}

async fn make_service_with_assistant_support_and_acp_session_repo(
    skill_resolver: Arc<dyn crate::skill_resolver::SkillResolver>,
    dispatcher: Arc<dyn AssistantRuleDispatcher>,
    acp_session_repo: Arc<StubAcpSessionRepo>,
) -> (
    ConversationService,
    Arc<MockBroadcaster>,
    Arc<MockRepo>,
    Arc<SqliteAssistantDefinitionRepository>,
    Arc<SqliteAssistantOverlayRepository>,
    Arc<dyn IAssistantPreferenceRepository>,
    Arc<StubAcpSessionRepo>,
) {
    let (svc, broadcaster, repo, _task_mgr) =
        make_service_with_resolver_and_acp_session_repo(skill_resolver, acp_session_repo.clone());
    let db = init_database_memory().await.unwrap();
    seed_test_user(db.pool(), "user-1").await;
    seed_test_user(db.pool(), "user_1").await;
    let definition_repo = Arc::new(SqliteAssistantDefinitionRepository::new(db.pool().clone()));
    let state_repo = Arc::new(SqliteAssistantOverlayRepository::new(db.pool().clone()));
    let preference_repo: Arc<dyn IAssistantPreferenceRepository> =
        Arc::new(SqliteAssistantPreferenceRepository::new(db.pool().clone()));

    svc.with_assistant_definition_repo(definition_repo.clone());
    svc.with_assistant_state_repo(state_repo.clone());
    svc.with_assistant_preference_repo(preference_repo.clone());
    svc.with_assistant_dispatcher(dispatcher);

    (
        svc,
        broadcaster,
        repo,
        definition_repo,
        state_repo,
        preference_repo,
        acp_session_repo,
    )
}

async fn seed_test_user(pool: &sqlx::SqlitePool, user_id: &str) {
    let now = qianji_common::now_ms();
    sqlx::query(
        "INSERT OR IGNORE INTO users (
            id, user_type, username, password_hash, status, session_generation, created_at, updated_at
         ) VALUES (?, 'local', ?, 'hash', 'active', 0, ?, ?)",
    )
    .bind(user_id)
    .bind(user_id)
    .bind(now)
    .bind(now)
    .execute(pool)
    .await
    .unwrap();
}

fn make_create_req() -> CreateConversationRequest {
    let workspace = ensure_test_workspace_path();
    serde_json::from_value(json!({
        "type": "acp",
        "extra": { "workspace": workspace }
    }))
    .unwrap()
}

fn make_create_req_with_backend(backend: &str) -> CreateConversationRequest {
    let workspace = ensure_test_workspace_path();
    serde_json::from_value(json!({
        "type": "acp",
        "extra": {
            "workspace": workspace,
            "custom_workspace": true,
            "backend": backend
        }
    }))
    .unwrap()
}

fn ensure_test_workspace_path() -> String {
    let workspace = std::env::temp_dir().join("qianji-conversation-service-test-project");
    std::fs::create_dir_all(&workspace).unwrap();
    workspace.to_string_lossy().to_string()
}

fn unique_test_workspace_path(label: &str) -> PathBuf {
    let workspace = std::env::temp_dir()
        .join(format!("qianji-conversation-service-test-{label}"))
        .join(ConversationService::mint_msg_id());
    std::fs::create_dir_all(&workspace).unwrap();
    workspace
}

fn assert_dated_workspace_path(workspace_root: &Path, workspace: &Path, expected_file_name: &str) {
    // Per-user, type-first layout: conversations/users/{user_dir}/{Y}/{M}/{D}/{leaf}
    let relative = workspace
        .strip_prefix(workspace_root.join("conversations"))
        .expect("workspace should be under the conversations root");
    let parts = relative
        .iter()
        .map(|part| part.to_str().expect("workspace path should be utf-8"))
        .collect::<Vec<_>>();

    assert_eq!(
        parts.len(),
        6,
        "expected conversations/users/{{dir}}/Y/M/D/leaf, got {parts:?}"
    );
    assert_eq!(parts[0], "users");
    assert!(!parts[1].is_empty(), "user dir segment must be present");
    assert_eq!(parts[2].len(), 4);
    assert_eq!(parts[3].len(), 2);
    assert_eq!(parts[4].len(), 2);
    assert!(parts[2].chars().all(|ch| ch.is_ascii_digit()));
    assert!(parts[3].chars().all(|ch| ch.is_ascii_digit()));
    assert!(parts[4].chars().all(|ch| ch.is_ascii_digit()));
    assert_eq!(parts[5], expected_file_name);
}

async fn upsert_test_assistant_definition(
    repo: &SqliteAssistantDefinitionRepository,
    definition_id: &str,
    assistant_id: &str,
    agent_id: &str,
    default_model_mode: &str,
    default_permission_mode: &str,
) {
    upsert_test_assistant_definition_with_thought_level(
        repo,
        definition_id,
        assistant_id,
        agent_id,
        default_model_mode,
        default_permission_mode,
        "auto",
    )
    .await;
}

async fn upsert_test_assistant_definition_with_thought_level(
    repo: &SqliteAssistantDefinitionRepository,
    definition_id: &str,
    assistant_id: &str,
    agent_id: &str,
    default_model_mode: &str,
    default_permission_mode: &str,
    default_thought_level_mode: &str,
) {
    repo.upsert(&UpsertAssistantDefinitionParams {
        id: definition_id,
        assistant_id,
        source: "builtin",
        owner_type: "system",
        source_ref: Some(assistant_id),
        name: assistant_id,
        name_i18n: "{}",
        description: Some("desc"),
        description_i18n: "{}",
        avatar_type: "emoji",
        avatar_value: Some("🤖"),
        agent_id,
        rule_resource_type: "builtin_asset",
        rule_resource_ref: Some(assistant_id),
        recommended_prompts: "[]",
        recommended_prompts_i18n: "{}",
        default_model_mode,
        default_model_value: None,
        default_permission_mode,
        default_permission_value: None,
        default_thought_level_mode,
        default_thought_level_value: None,
        default_skills_mode: "auto",
        default_skill_ids: "[]",
        custom_skill_names: "[]",
        default_disabled_builtin_skill_ids: "[]",
        default_mcps_mode: "auto",
        default_mcp_ids: "[]",
    })
    .await
    .unwrap();
}

async fn create_assistant_backed_conversation(
    svc: &ConversationService,
    user_id: &str,
    conversation_type: Option<&str>,
    backend: &str,
    assistant_id: &str,
) -> ConversationResponse {
    let workspace = ensure_test_workspace_path();
    let mut payload = json!({
        "name": "assistant conversation",
        "assistant": {
            "id": assistant_id,
            "locale": "en-US"
        },
        "extra": {
            "workspace": workspace,
            "backend": backend
        }
    });

    if let Some(conversation_type) = conversation_type {
        payload["type"] = json!(conversation_type);
    }

    if conversation_type == Some("qianjirs") {
        payload["model"] = json!({
            "provider_id": "provider-1",
            "model": "model-a",
            "use_model": "model-a"
        });
    }

    let req: CreateConversationRequest = serde_json::from_value(payload).unwrap();
    svc.create(user_id, req).await.unwrap()
}

async fn insert_conversation_with_type(repo: &Arc<MockRepo>, user_id: &str, agent_type: AgentType) -> ConversationRow {
    let id = format!(
        "legacy-{}-{}",
        agent_type.serde_name(),
        qianji_common::generate_short_id()
    );
    let row = ConversationRow {
        id,
        user_id: user_id.to_owned(),
        name: format!("legacy {}", agent_type.serde_name()),
        r#type: agent_type.serde_name().to_owned(),
        extra: json!({
            "workspace": ensure_test_workspace_path()
        })
        .to_string(),
        model: None,
        status: Some("finished".into()),
        source: Some("qianji".into()),
        channel_chat_id: None,
        pinned: false,
        pinned_at: None,
        created_at: 1,
        updated_at: 1,
        project_id: None,
        folder_id: None,
        name_source: None,
    };
    repo.create(&row).await.unwrap();
    row
}

// ── apply_agent_title guard matrix ─────────────────────────────────

async fn seed_titled_conversation(
    repo: &Arc<MockRepo>,
    user_id: &str,
    name: &str,
    name_source: Option<&str>,
) -> String {
    let mut row = insert_conversation_with_type(repo, user_id, AgentType::Acp).await;
    row.name = name.to_owned();
    row.name_source = name_source.map(str::to_owned);
    // MockRepo::create pushed the original row; rewrite it via update.
    repo.update(
        user_id,
        &row.id,
        &ConversationRowUpdate {
            name: Some(row.name.clone()),
            name_source: row.name_source.clone(),
            ..Default::default()
        },
    )
    .await
    .unwrap();
    row.id
}

async fn get_row(repo: &Arc<MockRepo>, user_id: &str, id: &str) -> ConversationRow {
    use qianji_db::IConversationRepository as _;
    repo.get(user_id, id).await.unwrap().unwrap()
}

#[tokio::test]
async fn agent_title_applies_to_default_named_conversation() {
    let repo = Arc::new(MockRepo::new());
    let broadcaster = Arc::new(MockBroadcaster::new());
    let id = seed_titled_conversation(&repo, "user_1", "first message placeholder", None).await;

    let repo_dyn: Arc<dyn IConversationRepository> = repo.clone();
    let broadcaster_dyn: Arc<dyn EventBroadcaster> = broadcaster.clone();
    let applied =
        crate::service::apply_agent_title(&repo_dyn, &broadcaster_dyn, "user_1", &id, "Fix login bug", "test")
            .await
            .unwrap();

    assert!(applied);
    let row = get_row(&repo, "user_1", &id).await;
    assert_eq!(row.name, "Fix login bug");
    assert_eq!(row.name_source.as_deref(), Some("agent"));

    let events = broadcaster.take_events();
    let event = events
        .iter()
        .find(|e| e.name == "conversation.nameUpdated")
        .expect("nameUpdated event broadcast");
    assert_eq!(event.data["conversation_id"], id);
    assert_eq!(event.data["name"], "Fix login bug");
    assert_eq!(event.data["user_id"], "user_1");
}

#[tokio::test]
async fn agent_title_overwrites_previous_agent_title() {
    let repo = Arc::new(MockRepo::new());
    let broadcaster = Arc::new(MockBroadcaster::new());
    let id = seed_titled_conversation(&repo, "user_1", "Old agent title", Some("agent")).await;

    let repo_dyn: Arc<dyn IConversationRepository> = repo.clone();
    let broadcaster_dyn: Arc<dyn EventBroadcaster> = broadcaster.clone();
    let applied =
        crate::service::apply_agent_title(&repo_dyn, &broadcaster_dyn, "user_1", &id, "Newer agent title", "test")
            .await
            .unwrap();

    assert!(applied);
    assert_eq!(get_row(&repo, "user_1", &id).await.name, "Newer agent title");
}

#[tokio::test]
async fn agent_title_never_overwrites_user_rename() {
    let repo = Arc::new(MockRepo::new());
    let broadcaster = Arc::new(MockBroadcaster::new());
    let id = seed_titled_conversation(&repo, "user_1", "My careful name", Some("user")).await;

    let repo_dyn: Arc<dyn IConversationRepository> = repo.clone();
    let broadcaster_dyn: Arc<dyn EventBroadcaster> = broadcaster.clone();
    let applied = crate::service::apply_agent_title(&repo_dyn, &broadcaster_dyn, "user_1", &id, "Agent title", "test")
        .await
        .unwrap();

    assert!(!applied);
    let row = get_row(&repo, "user_1", &id).await;
    assert_eq!(row.name, "My careful name");
    assert_eq!(row.name_source.as_deref(), Some("user"));
    assert!(
        !broadcaster
            .take_events()
            .iter()
            .any(|e| e.name == "conversation.nameUpdated"),
        "discarded title must not broadcast"
    );
}

#[tokio::test]
async fn agent_title_unchanged_is_noop() {
    let repo = Arc::new(MockRepo::new());
    let broadcaster = Arc::new(MockBroadcaster::new());
    let id = seed_titled_conversation(&repo, "user_1", "Same title", Some("agent")).await;

    let repo_dyn: Arc<dyn IConversationRepository> = repo.clone();
    let broadcaster_dyn: Arc<dyn EventBroadcaster> = broadcaster.clone();
    let applied = crate::service::apply_agent_title(&repo_dyn, &broadcaster_dyn, "user_1", &id, "Same title", "test")
        .await
        .unwrap();

    assert!(!applied);
    assert!(
        !broadcaster
            .take_events()
            .iter()
            .any(|e| e.name == "conversation.nameUpdated")
    );
}

#[tokio::test]
async fn agent_title_ignores_unknown_conversation() {
    let repo = Arc::new(MockRepo::new());
    let broadcaster = Arc::new(MockBroadcaster::new());

    let repo_dyn: Arc<dyn IConversationRepository> = repo.clone();
    let broadcaster_dyn: Arc<dyn EventBroadcaster> = broadcaster.clone();
    let applied = crate::service::apply_agent_title(&repo_dyn, &broadcaster_dyn, "user_1", "missing", "Title", "test")
        .await
        .unwrap();

    assert!(!applied);
}

// ── update_conversation name_source intent ─────────────────────────

#[tokio::test]
async fn update_name_without_source_marks_user() {
    let (svc, _broadcaster, repo, task_mgr) = make_service();
    let row = insert_conversation_with_type(&repo, "user_1", AgentType::Acp).await;

    let req: UpdateConversationRequest = serde_json::from_value(json!({ "name": "Renamed by hand" })).unwrap();
    svc.update("user_1", &row.id, req, &task_mgr).await.unwrap();

    let updated = get_row(&repo, "user_1", &row.id).await;
    assert_eq!(updated.name, "Renamed by hand");
    assert_eq!(updated.name_source.as_deref(), Some("user"));
}

#[tokio::test]
async fn update_name_with_auto_source_keeps_origin() {
    let (svc, _broadcaster, repo, task_mgr) = make_service();
    let row = insert_conversation_with_type(&repo, "user_1", AgentType::Acp).await;

    let req: UpdateConversationRequest =
        serde_json::from_value(json!({ "name": "Derived title", "name_source": "auto" })).unwrap();
    svc.update("user_1", &row.id, req, &task_mgr).await.unwrap();

    let updated = get_row(&repo, "user_1", &row.id).await;
    assert_eq!(updated.name, "Derived title");
    assert_eq!(updated.name_source, None, "auto rename must stay agent-overwritable");
}

#[tokio::test]
async fn update_without_name_leaves_name_source_untouched() {
    let (svc, _broadcaster, repo, task_mgr) = make_service();
    let id = seed_titled_conversation(&repo, "user_1", "Agent title", Some("agent")).await;

    let req: UpdateConversationRequest = serde_json::from_value(json!({ "pinned": true })).unwrap();
    svc.update("user_1", &id, req, &task_mgr).await.unwrap();

    assert_eq!(
        get_row(&repo, "user_1", &id).await.name_source.as_deref(),
        Some("agent")
    );
}

// ── Create tests ───────────────────────────────────────────────────

#[tokio::test]
async fn create_returns_conversation_with_defaults() {
    let (svc, broadcaster, _repo, _task_mgr) = make_service();
    let workspace = ensure_test_workspace_path();

    let resp = svc.create("user_1", make_create_req()).await.unwrap();

    assert!(!resp.id.is_empty());
    assert_eq!(resp.r#type, AgentType::Acp);
    assert_eq!(resp.status, ConversationStatus::Pending);
    assert_eq!(resp.source, Some(ConversationSource::Qianji));
    assert!(!resp.pinned);
    assert!(resp.pinned_at.is_none());
    assert_eq!(resp.extra["workspace"], workspace);
    assert!(resp.created_at > 0);
    assert_eq!(resp.created_at, resp.modified_at);

    // Should have broadcast a listChanged(created) event
    let events = broadcaster.take_events();
    assert_eq!(events.len(), 1);
    assert_eq!(events[0].name, "conversation.listChanged");
    assert_eq!(events[0].data["action"], "created");
    assert_eq!(events[0].data["conversation_id"], resp.id);
    assert_eq!(events[0].data["source"], "qianji");
}

// ── Project-bind side branch tests ─────────────────────────────────

async fn make_injected_project_service(temp_root: &std::path::Path) -> std::sync::Arc<qianji_project::ProjectService> {
    // A real store on an in-memory DB; temp_root mirrors the app wiring
    // (`work_dir/conversations`) so classification matches production. The
    // Database handle is leaked so the shared in-memory pool outlives the test.
    let db = qianji_db::init_database_memory().await.unwrap();
    // The project tables carry a users(id) FK; seed the owner these tests act
    // as, mirroring production where the owner always exists.
    sqlx::query(
        "INSERT INTO users (id, user_type, username, password_hash, status, session_generation, created_at, updated_at) \
         VALUES ('user_1', 'local', 'user_1', 'hash', 'active', 0, 1, 1)",
    )
    .execute(db.pool())
    .await
    .unwrap();
    let store: std::sync::Arc<dyn qianji_db::IProjectStore> =
        std::sync::Arc::new(qianji_db::SqliteProjectStore::new(db.pool().clone()));
    std::mem::forget(db);
    std::sync::Arc::new(qianji_project::ProjectService::new(
        store,
        temp_root.join("conversations"),
    ))
}

#[tokio::test]
async fn create_side_branch_backfills_project_binding_when_injected() {
    let work_root = tempfile::tempdir().unwrap();
    let (svc, _bc, repo, _task_mgr) = make_service_with_workspace_root(work_root.path().to_path_buf());
    svc.with_project_service(make_injected_project_service(work_root.path()).await);

    // Custom workspace outside temp_root → classified standard.
    let ws = tempfile::tempdir().unwrap();
    let mut req = make_create_req();
    req.extra = json!({ "workspace": ws.path().to_string_lossy(), "backend": "claude" });

    let resp = svc.create("user_1", req).await.unwrap();

    let row = repo.get("user_1", &resp.id).await.unwrap().unwrap();
    assert!(
        row.project_id.is_some(),
        "create side branch should backfill project_id"
    );
    assert!(row.folder_id.is_some(), "create side branch should backfill folder_id");
    // The transitional workspace string must be untouched by the side branch.
    assert_eq!(resp.extra["workspace"], ws.path().to_string_lossy().as_ref());
}

#[tokio::test]
async fn create_without_project_service_leaves_binding_null() {
    // Best-effort contract: no ProjectService injected → binding stays NULL and
    // create still succeeds (the side branch is a pure no-op).
    let (svc, _bc, repo, _task_mgr) = make_service();
    let resp = svc.create("user_1", make_create_req()).await.unwrap();
    let row = repo.get("user_1", &resp.id).await.unwrap().unwrap();
    assert!(row.project_id.is_none());
    assert!(row.folder_id.is_none());
}

#[tokio::test]
async fn list_does_not_backfill_but_get_does() {
    let work_root = tempfile::tempdir().unwrap();
    let (svc, _bc, repo, _task_mgr) = make_service_with_workspace_root(work_root.path().to_path_buf());

    // Create WITHOUT the project service so the row starts unbound.
    let ws = tempfile::tempdir().unwrap();
    let mut req = make_create_req();
    req.extra = json!({ "workspace": ws.path().to_string_lossy(), "backend": "claude" });
    let resp = svc.create("user_1", req).await.unwrap();
    assert!(
        repo.get("user_1", &resp.id)
            .await
            .unwrap()
            .unwrap()
            .project_id
            .is_none()
    );

    svc.with_project_service(make_injected_project_service(work_root.path()).await);

    // Narrowed contract: list is a pure read — it must NOT backfill, so the
    // conversation list stays fast and side-effect free.
    let _ = svc.list("user_1", ListConversationsQuery::default()).await.unwrap();
    assert!(
        repo.get("user_1", &resp.id)
            .await
            .unwrap()
            .unwrap()
            .project_id
            .is_none(),
        "list must not backfill"
    );

    // Opening the single conversation via get → lazy backfill.
    let _ = svc.get("user_1", &resp.id).await.unwrap();
    let row = repo.get("user_1", &resp.id).await.unwrap().unwrap();
    assert!(row.project_id.is_some(), "get should lazily backfill project_id");
    assert!(row.folder_id.is_some());
}

#[tokio::test]
async fn create_rejects_deprecated_agent_types_for_new_conversations() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();

    for agent_type in [
        AgentType::Gemini,
        AgentType::Codex,
        AgentType::OpenclawGateway,
        AgentType::Nanobot,
        AgentType::Remote,
    ] {
        let mut req = make_create_req();
        req.r#type = Some(agent_type);
        req.model = None;
        req.extra = json!({
            "workspace": ensure_test_workspace_path()
        });

        let err = svc.create("user_1", req).await.unwrap_err();
        assert_eq!(err.error_code(), "BAD_REQUEST");
        assert!(
            err.to_string()
                .contains("This agent type is no longer supported for new conversations."),
            "unexpected error for {}: {err}",
            agent_type.serde_name()
        );
    }
}

#[tokio::test]
async fn create_auto_provisions_workspace_under_date_partition() {
    let temp = tempfile::tempdir().unwrap();
    let workspace_root = temp.path().join("qianji-data");
    let (svc, _broadcaster, _repo, _task_mgr) = make_service_with_workspace_root(workspace_root.clone());
    let req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "acp",
        "extra": {}
    }))
    .unwrap();

    let conv = svc.create("user_1", req).await.unwrap();
    let workspace = Path::new(conv.extra["workspace"].as_str().unwrap());

    assert_dated_workspace_path(&workspace_root, workspace, &format!("acp-temp-{}", conv.id));
    assert!(workspace.is_dir());
}

#[test]
fn create_team_temp_workspace_uses_date_partition() {
    let temp = tempfile::tempdir().unwrap();
    let workspace_root = temp.path().join("qianji-data");
    let (svc, _broadcaster, _repo, _task_mgr) = make_service_with_workspace_root(workspace_root.clone());

    let workspace = svc.create_team_temp_workspace("user_1", "team_1").unwrap();

    let workspace = Path::new(&workspace);
    assert_dated_workspace_path(&workspace_root, workspace, "team-temp-team_1");
    assert!(workspace.is_dir());
}

#[tokio::test]
async fn create_rejects_unavailable_workspace_with_trailing_whitespace_in_request() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let dir = std::env::temp_dir().join(format!("qianji-test-{}", qianji_common::generate_short_id()));
    std::fs::create_dir(&dir).unwrap();
    let workspace = dir.join("workspace");
    std::fs::create_dir(&workspace).unwrap();
    let workspace_with_trailing_space = format!("{} ", workspace.to_string_lossy());

    let req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "acp",
        "extra": { "workspace": workspace_with_trailing_space }
    }))
    .unwrap();
    let err = svc.create("user_1", req).await.unwrap_err();
    assert!(matches!(
        err,
        ConversationError::WorkspacePathUnavailable { path }
            if path == workspace_with_trailing_space
    ));
    let _ = std::fs::remove_dir_all(&dir);
}

#[tokio::test]
async fn create_accepts_existing_workspace_with_trailing_whitespace_in_name() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let dir = std::env::temp_dir().join(format!("qianji-test-{}", qianji_common::generate_short_id()));
    std::fs::create_dir(&dir).unwrap();
    let workspace = dir.join("workspace ");
    std::fs::create_dir(&workspace).unwrap();

    let req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "acp",
        "extra": { "workspace": workspace.to_string_lossy() }
    }))
    .unwrap();
    let resp = svc.create("user_1", req).await.unwrap();
    assert_eq!(resp.extra["workspace"], workspace.to_string_lossy().to_string());
    let _ = std::fs::remove_dir_all(&dir);
}

#[tokio::test]
async fn create_accepts_workspace_with_whitespace_in_any_path_segment() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let dir = std::env::temp_dir().join(format!("qianji-test-{}", qianji_common::generate_short_id()));
    std::fs::create_dir(&dir).unwrap();
    let workspace = dir.join("my project").join("workspace");
    std::fs::create_dir(dir.join("my project")).unwrap();
    std::fs::create_dir(&workspace).unwrap();

    let req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "acp",
        "extra": { "workspace": workspace.to_string_lossy() }
    }))
    .unwrap();
    let resp = svc.create("user_1", req).await.unwrap();
    assert_eq!(resp.extra["workspace"], workspace.to_string_lossy().to_string());
    let _ = std::fs::remove_dir_all(&dir);
}

#[tokio::test]
async fn create_with_custom_name_and_source() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();

    let req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "acp",
        "name": "Custom Name",
        "source": "telegram",
        "channel_chat_id": "chat:123",
        "extra": {}
    }))
    .unwrap();

    let resp = svc.create("user_1", req).await.unwrap();

    assert_eq!(resp.name, "Custom Name");
    assert_eq!(resp.r#type, AgentType::Acp);
    assert_eq!(resp.source, Some(ConversationSource::Telegram));
    assert_eq!(resp.channel_chat_id.as_deref(), Some("chat:123"));
}

#[tokio::test]
async fn create_stores_model_as_json() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let workspace = ensure_test_workspace_path();

    // Top-level model is only valid for qianjirs conversations.
    let req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "qianjirs",
        "model": { "provider_id": "p1", "model": "m1" },
        "extra": { "workspace": workspace }
    }))
    .unwrap();
    let resp = svc.create("user_1", req).await.unwrap();

    let model = resp.model.unwrap();
    assert_eq!(model.provider_id, "p1");
    assert_eq!(model.model, "m1");
}

#[tokio::test]
async fn create_derives_qianjirs_type_from_assistant_backend_when_type_is_missing() {
    let resolver = Arc::new(FixedSkillResolver { names: vec![] });
    let dispatcher = Arc::new(StaticAssistantDispatcher {
        rules: std::collections::HashMap::new(),
    });
    let (svc, _broadcaster, repo, definition_repo, overlay_repo, _preference_repo) =
        make_service_with_assistant_support(resolver, dispatcher).await;

    upsert_test_assistant_definition(
        &definition_repo,
        "asstdef_qianjirs_missing_type",
        "assistant-qianjirs-missing-type",
        "qianjirs",
        "auto",
        "auto",
    )
    .await;
    overlay_repo
        .upsert(&UpsertAssistantOverlayParams {
            assistant_definition_id: "asstdef_qianjirs_missing_type",
            enabled: true,
            sort_order: 0,
            agent_id_override: None,
            last_used_at: None,
        })
        .await
        .unwrap();

    let workspace = ensure_test_workspace_path();
    let req: CreateConversationRequest = serde_json::from_value(json!({
        "assistant": {
            "id": "assistant-qianjirs-missing-type",
            "locale": "en-US"
        },
        "model": {
            "provider_id": "provider-1",
            "model": "model-a",
            "use_model": "model-a"
        },
        "extra": {
            "workspace": workspace
        }
    }))
    .unwrap();

    let resp = svc.create("user_1", req).await.unwrap();
    assert_eq!(resp.r#type, AgentType::Qianjirs);
    assert!(repo.get_assistant_snapshot("user_1", &resp.id).await.unwrap().is_some());
}

#[tokio::test]
async fn create_derives_acp_type_from_assistant_backend_when_type_is_missing() {
    let resolver = Arc::new(FixedSkillResolver { names: vec![] });
    let dispatcher = Arc::new(StaticAssistantDispatcher {
        rules: std::collections::HashMap::new(),
    });
    let (svc, _broadcaster, repo, definition_repo, overlay_repo, _preference_repo) =
        make_service_with_assistant_support(resolver, dispatcher).await;

    upsert_test_assistant_definition(
        &definition_repo,
        "asstdef_acp_missing_type",
        "assistant-acp-missing-type",
        "codex",
        "auto",
        "auto",
    )
    .await;
    overlay_repo
        .upsert(&UpsertAssistantOverlayParams {
            assistant_definition_id: "asstdef_acp_missing_type",
            enabled: true,
            sort_order: 0,
            agent_id_override: None,
            last_used_at: None,
        })
        .await
        .unwrap();

    let workspace = ensure_test_workspace_path();
    let req: CreateConversationRequest = serde_json::from_value(json!({
        "assistant": {
            "id": "assistant-acp-missing-type",
            "locale": "en-US"
        },
        "extra": {
            "workspace": workspace
        }
    }))
    .unwrap();

    let resp = svc.create("user_1", req).await.unwrap();
    assert_eq!(resp.r#type, AgentType::Acp);
    assert!(repo.get_assistant_snapshot("user_1", &resp.id).await.unwrap().is_some());
}

#[tokio::test]
async fn create_derives_acp_type_from_openclaw_agent_metadata_when_type_is_missing() {
    let resolver = Arc::new(FixedSkillResolver { names: vec![] });
    let dispatcher = Arc::new(StaticAssistantDispatcher {
        rules: std::collections::HashMap::new(),
    });
    let (svc, _broadcaster, repo, definition_repo, overlay_repo, _preference_repo) =
        make_service_with_assistant_support(resolver, dispatcher).await;

    upsert_test_assistant_definition(
        &definition_repo,
        "asstdef_openclaw_missing_type",
        "assistant-openclaw-missing-type",
        "b7e8a9c4",
        "auto",
        "auto",
    )
    .await;
    overlay_repo
        .upsert(&UpsertAssistantOverlayParams {
            assistant_definition_id: "asstdef_openclaw_missing_type",
            enabled: true,
            sort_order: 0,
            agent_id_override: None,
            last_used_at: None,
        })
        .await
        .unwrap();

    let workspace = ensure_test_workspace_path();
    let req: CreateConversationRequest = serde_json::from_value(json!({
        "assistant": {
            "id": "assistant-openclaw-missing-type",
            "locale": "en-US"
        },
        "extra": {
            "workspace": workspace
        }
    }))
    .unwrap();

    let resp = svc.create("user_1", req).await.unwrap();
    assert_eq!(resp.r#type, AgentType::Acp);
    assert_eq!(resp.extra["agent_id"], json!("b7e8a9c4"));
    assert_eq!(resp.extra["backend"], json!("openclaw"));
    assert!(repo.get_assistant_snapshot("user_1", &resp.id).await.unwrap().is_some());
}

#[tokio::test]
async fn create_derives_acp_type_from_custom_agent_metadata_when_type_is_missing() {
    let resolver = Arc::new(FixedSkillResolver { names: vec![] });
    let dispatcher = Arc::new(StaticAssistantDispatcher {
        rules: std::collections::HashMap::new(),
    });
    let (svc, _broadcaster, repo, definition_repo, overlay_repo, _preference_repo) =
        make_service_with_assistant_support(resolver, dispatcher).await;

    upsert_test_assistant_definition(
        &definition_repo,
        "asstdef_custom_acp_missing_type",
        "assistant-custom-acp-missing-type",
        "custom-acp-1",
        "auto",
        "auto",
    )
    .await;
    overlay_repo
        .upsert(&UpsertAssistantOverlayParams {
            assistant_definition_id: "asstdef_custom_acp_missing_type",
            enabled: true,
            sort_order: 0,
            agent_id_override: None,
            last_used_at: None,
        })
        .await
        .unwrap();

    let workspace = ensure_test_workspace_path();
    let req: CreateConversationRequest = serde_json::from_value(json!({
        "assistant": {
            "id": "assistant-custom-acp-missing-type",
            "locale": "en-US"
        },
        "extra": {
            "workspace": workspace
        }
    }))
    .unwrap();

    let resp = svc.create("user_1", req).await.unwrap();
    assert_eq!(resp.r#type, AgentType::Acp);
    assert_eq!(resp.extra["agent_id"], json!("custom-acp-1"));
    assert_eq!(resp.extra["agent_source"], json!("custom"));
    assert_eq!(resp.extra["backend"], json!("acp"));
    assert!(repo.get_assistant_snapshot("user_1", &resp.id).await.unwrap().is_some());
}

#[tokio::test]
async fn create_rejects_assistant_bound_to_deprecated_agent_metadata() {
    let resolver = Arc::new(FixedSkillResolver { names: vec![] });
    let dispatcher = Arc::new(StaticAssistantDispatcher {
        rules: std::collections::HashMap::new(),
    });
    let (svc, _broadcaster, _repo, definition_repo, overlay_repo, _preference_repo) =
        make_service_with_assistant_support(resolver, dispatcher).await;

    upsert_test_assistant_definition(
        &definition_repo,
        "asstdef_openclaw_gateway_deprecated",
        "assistant-openclaw-gateway-deprecated",
        "f9f61666",
        "auto",
        "auto",
    )
    .await;
    overlay_repo
        .upsert(&UpsertAssistantOverlayParams {
            assistant_definition_id: "asstdef_openclaw_gateway_deprecated",
            enabled: true,
            sort_order: 0,
            agent_id_override: None,
            last_used_at: None,
        })
        .await
        .unwrap();

    let workspace = ensure_test_workspace_path();
    let req: CreateConversationRequest = serde_json::from_value(json!({
        "assistant": {
            "id": "assistant-openclaw-gateway-deprecated",
            "locale": "en-US"
        },
        "extra": {
            "workspace": workspace
        }
    }))
    .unwrap();

    let err = svc.create("user_1", req).await.unwrap_err();
    assert_eq!(err.error_code(), "BAD_REQUEST");
    assert!(
        err.to_string()
            .contains("This agent type is no longer supported for new conversations."),
        "unexpected error: {err}"
    );
}

#[tokio::test]
async fn create_rejects_assistant_with_unregistered_agent_metadata() {
    let resolver = Arc::new(FixedSkillResolver { names: vec![] });
    let dispatcher = Arc::new(StaticAssistantDispatcher {
        rules: std::collections::HashMap::new(),
    });
    let (svc, _broadcaster, _repo, definition_repo, overlay_repo, _preference_repo) =
        make_service_with_assistant_support(resolver, dispatcher).await;

    upsert_test_assistant_definition(
        &definition_repo,
        "asstdef_missing_agent",
        "assistant-missing-agent",
        "missing-agent",
        "auto",
        "auto",
    )
    .await;
    overlay_repo
        .upsert(&UpsertAssistantOverlayParams {
            assistant_definition_id: "asstdef_missing_agent",
            enabled: true,
            sort_order: 0,
            agent_id_override: None,
            last_used_at: None,
        })
        .await
        .unwrap();

    let workspace = ensure_test_workspace_path();
    let req: CreateConversationRequest = serde_json::from_value(json!({
        "assistant": {
            "id": "assistant-missing-agent",
            "locale": "en-US"
        },
        "extra": {
            "workspace": workspace
        }
    }))
    .unwrap();

    let err = svc.create("user_1", req).await.unwrap_err();
    assert_eq!(err.error_code(), "BAD_REQUEST");
    assert!(
        err.to_string()
            .contains("assistant agent `missing-agent` is not registered in agent_metadata"),
        "unexpected error: {err}"
    );
}

// ── Get tests ──────────────────────────────────────────────────────

#[tokio::test]
async fn get_existing_conversation() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let created = svc.create("user_1", make_create_req()).await.unwrap();

    let fetched = svc.get("user_1", &created.id).await.unwrap();
    assert_eq!(fetched.id, created.id);
    assert_eq!(fetched.name, created.name);
    assert!(fetched.runtime.is_some());
}

#[tokio::test]
async fn get_reports_idle_runtime_when_only_persisted_status_is_running() {
    let (svc, _broadcaster, repo, _task_mgr) = make_service();
    let created = svc.create("user_1", make_create_req()).await.unwrap();
    repo.update(
        "user_1",
        &created.id,
        &ConversationRowUpdate {
            status: Some("running".into()),
            ..Default::default()
        },
    )
    .await
    .unwrap();

    let fetched = svc.get("user_1", &created.id).await.unwrap();
    let runtime = fetched.runtime.expect("runtime summary should be present");

    assert_eq!(fetched.status, ConversationStatus::Running);
    assert_eq!(runtime.state, qianji_api_types::ConversationRuntimeStateKind::Idle);
    assert!(runtime.can_send_message);
}

#[tokio::test]
async fn get_not_found() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let err = svc.get("user_1", "non-existent").await.unwrap_err();
    assert!(matches!(err, ConversationError::NotFound { .. }));
}

// ── List tests ─────────────────────────────────────────────────────

#[tokio::test]
async fn list_empty() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let result = svc.list("user_1", ListConversationsQuery::default()).await.unwrap();
    assert!(result.items.is_empty());
    assert_eq!(result.total, 0);
    assert!(!result.has_more);
}

#[tokio::test]
async fn list_returns_created_conversations() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    svc.create("user_1", make_create_req()).await.unwrap();
    svc.create("user_1", make_create_req()).await.unwrap();

    let result = svc.list("user_1", ListConversationsQuery::default()).await.unwrap();
    assert_eq!(result.items.len(), 2);
    assert_eq!(result.total, 2);
}

#[tokio::test]
async fn list_filters_by_user() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    svc.create("user_1", make_create_req()).await.unwrap();
    svc.create("user_2", make_create_req()).await.unwrap();

    let result = svc.list("user_1", ListConversationsQuery::default()).await.unwrap();
    assert_eq!(result.items.len(), 1);
}

#[tokio::test]
async fn list_with_source_filter() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    svc.create("user_1", make_create_req()).await.unwrap();

    let telegram_req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "acp",
        "source": "telegram",
        "extra": {}
    }))
    .unwrap();
    svc.create("user_1", telegram_req).await.unwrap();

    let query = ListConversationsQuery {
        source: Some("telegram".into()),
        ..Default::default()
    };
    let result = svc.list("user_1", query).await.unwrap();
    assert_eq!(result.items.len(), 1);
    assert_eq!(result.items[0].source, Some(ConversationSource::Telegram));
}

#[tokio::test]
async fn list_with_pinned_filter() {
    let (svc, _broadcaster, _repo, task_mgr) = make_service();
    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    svc.create("user_1", make_create_req()).await.unwrap();

    // Pin the first one
    let update_req: UpdateConversationRequest = serde_json::from_value(json!({ "pinned": true })).unwrap();
    svc.update("user_1", &conv.id, update_req, &task_mgr).await.unwrap();

    let query = ListConversationsQuery {
        pinned: Some(true),
        ..Default::default()
    };
    let result = svc.list("user_1", query).await.unwrap();
    assert_eq!(result.items.len(), 1);
    assert!(result.items[0].pinned);
}

// ── Update tests ───────────────────────────────────────────────────

#[tokio::test]
async fn update_name() {
    let (svc, broadcaster, _repo, task_mgr) = make_service();
    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    broadcaster.take_events(); // clear create event

    let req: UpdateConversationRequest = serde_json::from_value(json!({ "name": "New Name" })).unwrap();
    let updated = svc.update("user_1", &conv.id, req, &task_mgr).await.unwrap();

    assert_eq!(updated.name, "New Name");
    assert!(updated.modified_at >= conv.modified_at);

    let events = broadcaster.take_events();
    assert_eq!(events.len(), 1);
    assert_eq!(events[0].data["action"], "updated");
}

#[tokio::test]
async fn update_pin() {
    let (svc, _broadcaster, _repo, task_mgr) = make_service();
    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    assert!(!conv.pinned);

    let req: UpdateConversationRequest = serde_json::from_value(json!({ "pinned": true })).unwrap();
    let updated = svc.update("user_1", &conv.id, req, &task_mgr).await.unwrap();
    assert!(updated.pinned);
    assert!(updated.pinned_at.is_some());
}

#[tokio::test]
async fn update_unpin_clears_pinned_at() {
    let (svc, _broadcaster, _repo, task_mgr) = make_service();
    let conv = svc.create("user_1", make_create_req()).await.unwrap();

    // Pin first
    let pin_req: UpdateConversationRequest = serde_json::from_value(json!({ "pinned": true })).unwrap();
    let pinned = svc.update("user_1", &conv.id, pin_req, &task_mgr).await.unwrap();
    assert!(pinned.pinned);
    assert!(pinned.pinned_at.is_some());

    // Unpin
    let unpin_req: UpdateConversationRequest = serde_json::from_value(json!({ "pinned": false })).unwrap();
    let unpinned = svc.update("user_1", &conv.id, unpin_req, &task_mgr).await.unwrap();
    assert!(!unpinned.pinned);
    assert!(unpinned.pinned_at.is_none());
}

#[tokio::test]
async fn update_extra_merge() {
    let (svc, _broadcaster, _repo, task_mgr) = make_service();
    let dir = std::env::temp_dir().join(format!(
        "qianji-conversation-update-extra-merge-{}",
        qianji_common::generate_short_id()
    ));
    let old_workspace = dir.join("old-workspace");
    let new_workspace = dir.join("new-workspace");
    std::fs::create_dir_all(&old_workspace).unwrap();
    std::fs::create_dir_all(&new_workspace).unwrap();

    let req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "acp",
        "extra": { "workspace": old_workspace.to_string_lossy(), "contextFileName": "ctx.md" }
    }))
    .unwrap();
    let conv = svc.create("user_1", req).await.unwrap();

    // Update only workspace — contextFileName should be preserved
    let update_req: UpdateConversationRequest =
        serde_json::from_value(json!({ "extra": { "workspace": new_workspace.to_string_lossy() } })).unwrap();
    let updated = svc.update("user_1", &conv.id, update_req, &task_mgr).await.unwrap();

    assert_eq!(updated.extra["workspace"], new_workspace.to_string_lossy().to_string());
    assert_eq!(updated.extra["contextFileName"], "ctx.md");
}

#[tokio::test]
async fn update_model() {
    let (svc, _broadcaster, _repo, task_mgr) = make_service();
    let workspace = ensure_test_workspace_path();

    // Top-level model updates are only valid on qianjirs conversations
    // (Task 8 enforces the qianjirs-only rule in update).
    let create_req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "qianjirs",
        "model": { "provider_id": "p1", "model": "m1" },
        "extra": { "workspace": workspace }
    }))
    .unwrap();
    let conv = svc.create("user_1", create_req).await.unwrap();

    let req: UpdateConversationRequest = serde_json::from_value(json!({
        "model": { "provider_id": "p2", "model": "new-model" }
    }))
    .unwrap();
    let updated = svc.update("user_1", &conv.id, req, &task_mgr).await.unwrap();

    let model = updated.model.unwrap();
    assert_eq!(model.provider_id, "p2");
    assert_eq!(model.model, "new-model");
}

#[tokio::test]
async fn update_not_found() {
    let (svc, _broadcaster, _repo, task_mgr) = make_service();
    let req: UpdateConversationRequest = serde_json::from_value(json!({ "name": "x" })).unwrap();
    let err = svc.update("user_1", "non-existent", req, &task_mgr).await.unwrap_err();
    assert!(matches!(err, ConversationError::NotFound { .. }));
}

// ── Delete tests ───────────────────────────────────────────────────

#[tokio::test]
async fn delete_conversation() {
    let (svc, broadcaster, _repo, _task_mgr) = make_service();
    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    broadcaster.take_events();

    svc.delete("user_1", &conv.id).await.unwrap();

    // Should be gone
    let err = svc.get("user_1", &conv.id).await.unwrap_err();
    assert!(matches!(err, ConversationError::NotFound { .. }));

    // Should broadcast deleted
    let events = broadcaster.take_events();
    assert_eq!(events.len(), 1);
    assert_eq!(events[0].data["action"], "deleted");
    assert_eq!(events[0].data["conversation_id"], conv.id);
}

#[tokio::test]
async fn delete_not_found() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let err = svc.delete("user_1", "non-existent").await.unwrap_err();
    assert!(matches!(err, ConversationError::NotFound { .. }));
}

#[tokio::test]
async fn delete_invokes_registered_hook() {
    use qianji_common::OnConversationDelete;

    struct RecordingHook(Mutex<Vec<String>>);
    #[async_trait::async_trait]
    impl OnConversationDelete for RecordingHook {
        async fn on_conversation_deleted(&self, user_id: &str, conversation_id: &str) {
            self.0.lock().unwrap().push(format!("{user_id}:{conversation_id}"));
        }
    }

    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let hook = Arc::new(RecordingHook(Mutex::new(vec![])));
    svc.with_delete_hook(hook.clone());

    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    svc.delete("user_1", &conv.id).await.unwrap();

    let calls = hook.0.lock().unwrap();
    assert_eq!(calls.as_slice(), &[format!("user_1:{}", conv.id)]);
}

#[tokio::test]
async fn delete_invokes_registered_hook_before_row_delete() {
    use qianji_common::OnConversationDelete;

    struct RowVisibleHook {
        repo: Arc<MockRepo>,
        observations: Mutex<Vec<bool>>,
    }

    #[async_trait::async_trait]
    impl OnConversationDelete for RowVisibleHook {
        async fn on_conversation_deleted(&self, user_id: &str, conversation_id: &str) {
            let exists = self.repo.get(user_id, conversation_id).await.unwrap().is_some();
            self.observations.lock().unwrap().push(exists);
        }
    }

    let (svc, _broadcaster, repo, _task_mgr) = make_service();
    let hook = Arc::new(RowVisibleHook {
        repo: repo.clone(),
        observations: Mutex::new(vec![]),
    });
    svc.with_delete_hook(hook.clone());

    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    svc.delete("user_1", &conv.id).await.unwrap();

    {
        let observations = hook.observations.lock().unwrap();
        assert_eq!(observations.as_slice(), &[true]);
    }
    assert!(repo.get("user_1", &conv.id).await.unwrap().is_none());
}

#[tokio::test]
async fn delete_removes_auto_provisioned_workspace_directory() {
    let temp = tempfile::tempdir().unwrap();
    let workspace_root = temp.path().join("qianji-data");
    let (svc, _broadcaster, _repo, _task_mgr) = make_service_with_workspace_root(workspace_root);
    let req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "acp",
        "extra": {}
    }))
    .unwrap();

    let conv = svc.create("user_1", req).await.unwrap();
    let workspace = conv.extra["workspace"].as_str().unwrap();
    assert!(Path::new(workspace).is_dir());

    svc.delete("user_1", &conv.id).await.unwrap();

    assert!(!Path::new(workspace).exists());
}

#[tokio::test]
async fn delete_removes_empty_date_workspace_parents() {
    let temp = tempfile::tempdir().unwrap();
    let workspace_root = temp.path().join("qianji-data");
    let (svc, _broadcaster, _repo, _task_mgr) = make_service_with_workspace_root(workspace_root);
    let make_req = || {
        serde_json::from_value::<CreateConversationRequest>(json!({
            "type": "acp",
            "extra": {}
        }))
        .unwrap()
    };

    let first = svc.create("user_1", make_req()).await.unwrap();
    let second = svc.create("user_1", make_req()).await.unwrap();
    let first_workspace = PathBuf::from(first.extra["workspace"].as_str().unwrap());
    let second_workspace = PathBuf::from(second.extra["workspace"].as_str().unwrap());
    let day_dir = first_workspace.parent().unwrap().to_path_buf();
    let month_dir = day_dir.parent().unwrap().to_path_buf();
    let year_dir = month_dir.parent().unwrap().to_path_buf();

    svc.delete("user_1", &first.id).await.unwrap();

    assert!(day_dir.is_dir());
    assert!(second_workspace.is_dir());

    svc.delete("user_1", &second.id).await.unwrap();

    assert!(!day_dir.exists());
    assert!(!month_dir.exists());
    assert!(!year_dir.exists());
}

#[tokio::test]
async fn delete_preserves_user_supplied_workspace_directory() {
    let temp = tempfile::tempdir().unwrap();
    let workspace_root = temp.path().join("qianji-data");
    let user_workspace = temp.path().join("user-project");
    std::fs::create_dir_all(&user_workspace).unwrap();
    let (svc, _broadcaster, _repo, _task_mgr) = make_service_with_workspace_root(workspace_root);
    let req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "acp",
        "extra": {
            "workspace": user_workspace,
            "custom_workspace": true
        }
    }))
    .unwrap();

    let conv = svc.create("user_1", req).await.unwrap();
    svc.delete("user_1", &conv.id).await.unwrap();

    assert!(user_workspace.is_dir());
}

// ── Broadcast payload tests ────────────────────────────────────────

#[tokio::test]
async fn broadcast_includes_source_on_delete() {
    let (svc, broadcaster, _repo, _task_mgr) = make_service();

    let req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "acp",
        "source": "telegram",
        "extra": {}
    }))
    .unwrap();
    let conv = svc.create("user_1", req).await.unwrap();
    broadcaster.take_events();

    svc.delete("user_1", &conv.id).await.unwrap();
    let events = broadcaster.take_events();
    assert_eq!(events[0].data["source"], "telegram");
}

#[tokio::test]
async fn all_crud_operations_broadcast() {
    let (svc, broadcaster, _repo, task_mgr) = make_service();

    // Create
    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    let events = broadcaster.take_events();
    assert_eq!(events[0].data["action"], "created");

    // Update
    let req: UpdateConversationRequest = serde_json::from_value(json!({ "name": "x" })).unwrap();
    svc.update("user_1", &conv.id, req, &task_mgr).await.unwrap();
    let events = broadcaster.take_events();
    assert_eq!(events[0].data["action"], "updated");

    // Delete
    svc.delete("user_1", &conv.id).await.unwrap();
    let events = broadcaster.take_events();
    assert_eq!(events[0].data["action"], "deleted");
}

// ── Ownership tests (M-3) ─────────────────────────────────────────

#[tokio::test]
async fn get_wrong_user_returns_not_found() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let conv = svc.create("user_1", make_create_req()).await.unwrap();

    let err = svc.get("user_2", &conv.id).await.unwrap_err();
    assert!(matches!(err, ConversationError::NotFound { .. }));
}

#[tokio::test]
async fn update_wrong_user_returns_not_found() {
    let (svc, _broadcaster, _repo, task_mgr) = make_service();
    let conv = svc.create("user_1", make_create_req()).await.unwrap();

    let req: UpdateConversationRequest = serde_json::from_value(json!({ "name": "hacked" })).unwrap();
    let err = svc.update("user_2", &conv.id, req, &task_mgr).await.unwrap_err();
    assert!(matches!(err, ConversationError::NotFound { .. }));

    // Original should be unchanged
    let original = svc.get("user_1", &conv.id).await.unwrap();
    assert_ne!(original.name, "hacked");
}

#[tokio::test]
async fn delete_wrong_user_returns_not_found() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let conv = svc.create("user_1", make_create_req()).await.unwrap();

    let err = svc.delete("user_2", &conv.id).await.unwrap_err();
    assert!(matches!(err, ConversationError::NotFound { .. }));

    // Should still exist
    let still_exists = svc.get("user_1", &conv.id).await.unwrap();
    assert_eq!(still_exists.id, conv.id);
}

// ── Clone tests ───────────────────────────────────────────────────

#[tokio::test]
async fn clone_without_source_creates_new() {
    let (svc, broadcaster, _repo, _task_mgr) = make_service();
    let workspace = ensure_test_workspace_path();

    let req: CloneConversationRequest = serde_json::from_value(json!({
        "conversation": {
            "type": "acp",
            "name": "Cloned",
            "extra": { "workspace": workspace }
        }
    }))
    .unwrap();

    let resp = svc.clone_create("user_1", req).await.unwrap();
    assert_eq!(resp.name, "Cloned");
    assert_eq!(resp.extra["workspace"], workspace);

    let events = broadcaster.take_events();
    assert_eq!(events.len(), 1);
    assert_eq!(events[0].data["action"], "created");
}

// ── Reset tests ───────────────────────────────────────────────────

#[tokio::test]
async fn reset_sets_status_to_pending() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let conv = svc.create("user_1", make_create_req()).await.unwrap();

    svc.reset("user_1", &conv.id).await.unwrap();

    let fetched = svc.get("user_1", &conv.id).await.unwrap();
    assert_eq!(fetched.status, ConversationStatus::Pending);
}

#[tokio::test]
async fn reset_clears_conversation_artifacts() {
    let (svc, _broadcaster, repo, _task_mgr) = make_service();
    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    repo.upsert_artifact(
        "user_1",
        &ConversationArtifactRow {
            id: format!("{}:skill_suggest:cron_1", conv.id),
            conversation_id: conv.id.clone(),
            cron_job_id: Some("cron_1".into()),
            kind: "skill_suggest".into(),
            status: "pending".into(),
            payload: json!({ "cron_job_id": "cron_1", "name": "daily-report" }).to_string(),
            created_at: 1000,
            updated_at: 1000,
        },
    )
    .await
    .unwrap();

    svc.reset("user_1", &conv.id).await.unwrap();

    let artifacts = repo.list_artifacts("user_1", &conv.id).await.unwrap();
    assert!(artifacts.is_empty());
}

#[tokio::test]
async fn list_artifacts_includes_legacy_cron_trigger_messages() {
    let (svc, _broadcaster, repo, _task_mgr) = make_service();
    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    repo.insert_message(
        "user_1",
        &MessageRow {
            id: "legacy-msg-1".into(),
            conversation_id: conv.id.clone(),
            msg_id: Some("legacy-trigger-1".into()),
            r#type: "cron_trigger".into(),
            content: json!({
                "cron_job_id": "cron_1",
                "cron_job_name": "Daily Report",
                "triggered_at": 1234
            })
            .to_string(),
            position: Some("center".into()),
            status: Some("finish".into()),
            hidden: false,
            created_at: 1234,
            backend_turn_id: None,
        },
    )
    .await
    .unwrap();

    let artifacts = svc.list_artifacts("user_1", &conv.id).await.unwrap();

    assert_eq!(artifacts.len(), 1);
    assert_eq!(artifacts[0].kind, ConversationArtifactKind::CronTrigger);
    assert_eq!(artifacts[0].payload["cron_job_id"], "cron_1");
    assert_eq!(artifacts[0].payload["cron_job_name"], "Daily Report");
}

#[tokio::test]
async fn reset_not_found() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let err = svc.reset("user_1", "no-such-id").await.unwrap_err();
    assert!(matches!(err, ConversationError::NotFound { .. }));
}

#[tokio::test]
async fn reset_wrong_user() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let conv = svc.create("user_1", make_create_req()).await.unwrap();

    let err = svc.reset("user_2", &conv.id).await.unwrap_err();
    assert!(matches!(err, ConversationError::NotFound { .. }));
}

// ── Search validation tests ───────────────────────────────────────

#[tokio::test]
async fn search_messages_empty_keyword_returns_bad_request() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();

    let query = SearchMessagesQuery {
        keyword: "".into(),
        page: None,
        page_size: None,
    };
    let err = svc.search_messages("user_1", query).await.unwrap_err();
    assert!(matches!(err, ConversationError::BadRequest { .. }));
}

#[tokio::test]
async fn search_messages_whitespace_keyword_returns_bad_request() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();

    let query = SearchMessagesQuery {
        keyword: "   ".into(),
        page: None,
        page_size: None,
    };
    let err = svc.search_messages("user_1", query).await.unwrap_err();
    assert!(matches!(err, ConversationError::BadRequest { .. }));
}

// ── Mock Agent ───────────────────────────────────────────────────

struct MockAgent {
    conversation_id: String,
    event_tx: broadcast::Sender<AgentStreamEvent>,
    stopped: Mutex<bool>,
    mode: Mutex<String>,
    model_id: Mutex<String>,
    config_options: Arc<Mutex<Vec<AcpConfigOptionDto>>>,
    set_config_option_calls: Arc<Mutex<Vec<(String, String)>>>,
    set_config_option_error: Arc<Mutex<Option<AgentError>>>,
    set_config_option_response: Arc<Mutex<Option<SetConfigOptionResponse>>>,
    confirmations: Mutex<Vec<Confirmation>>,
    approval_memory: Mutex<std::collections::HashMap<String, bool>>,
    allow_direct_confirm: bool,
    /// Optional workspace override; falls back to "/tmp/test" when `None`.
    workspace_override: Option<String>,
}

impl MockAgent {
    fn build_model_response(current: &str) -> GetModelInfoResponse {
        GetModelInfoResponse {
            model_info: Some(ModelInfoPayload {
                current_model_id: Some(current.to_owned()),
                current_model_label: Some(current.to_owned()),
                available_models: vec![
                    ModelInfoEntry {
                        id: "model-a".to_owned(),
                        label: "Model A".to_owned(),
                    },
                    ModelInfoEntry {
                        id: "model-b".to_owned(),
                        label: "Model B".to_owned(),
                    },
                ],
            }),
        }
    }

    fn new(conversation_id: &str) -> Self {
        let (event_tx, _) = broadcast::channel(64);
        Self {
            conversation_id: conversation_id.to_owned(),
            event_tx,
            stopped: Mutex::new(false),
            mode: Mutex::new("default".to_owned()),
            model_id: Mutex::new("model-a".to_owned()),
            config_options: Arc::new(Mutex::new(Vec::new())),
            set_config_option_calls: Arc::new(Mutex::new(Vec::new())),
            set_config_option_error: Arc::new(Mutex::new(None)),
            set_config_option_response: Arc::new(Mutex::new(None)),
            confirmations: Mutex::new(vec![]),
            approval_memory: Mutex::new(std::collections::HashMap::new()),
            allow_direct_confirm: false,
            workspace_override: None,
        }
    }

    fn with_confirmations(conversation_id: &str, confirmations: Vec<Confirmation>) -> Self {
        let (event_tx, _) = broadcast::channel(64);
        Self {
            conversation_id: conversation_id.to_owned(),
            event_tx,
            stopped: Mutex::new(false),
            mode: Mutex::new("default".to_owned()),
            model_id: Mutex::new("model-a".to_owned()),
            config_options: Arc::new(Mutex::new(Vec::new())),
            set_config_option_calls: Arc::new(Mutex::new(Vec::new())),
            set_config_option_error: Arc::new(Mutex::new(None)),
            set_config_option_response: Arc::new(Mutex::new(None)),
            confirmations: Mutex::new(confirmations),
            approval_memory: Mutex::new(std::collections::HashMap::new()),
            allow_direct_confirm: false,
            workspace_override: None,
        }
    }

    fn with_direct_confirm(conversation_id: &str) -> Self {
        let (event_tx, _) = broadcast::channel(64);
        Self {
            conversation_id: conversation_id.to_owned(),
            event_tx,
            stopped: Mutex::new(false),
            mode: Mutex::new("default".to_owned()),
            model_id: Mutex::new("model-a".to_owned()),
            config_options: Arc::new(Mutex::new(Vec::new())),
            set_config_option_calls: Arc::new(Mutex::new(Vec::new())),
            set_config_option_error: Arc::new(Mutex::new(None)),
            set_config_option_response: Arc::new(Mutex::new(None)),
            confirmations: Mutex::new(vec![]),
            approval_memory: Mutex::new(std::collections::HashMap::new()),
            allow_direct_confirm: true,
            workspace_override: None,
        }
    }

    fn with_config_options(self, options: Vec<AcpConfigOptionDto>) -> Self {
        *self.config_options.lock().unwrap() = options;
        self
    }

    fn with_mode(self, mode: &str) -> Self {
        *self.mode.lock().unwrap() = mode.to_owned();
        self
    }

    fn with_set_config_option_response(self, response: SetConfigOptionResponse) -> Self {
        *self.set_config_option_response.lock().unwrap() = Some(response);
        self
    }

    fn with_set_config_option_error(self, error: AgentError) -> Self {
        *self.set_config_option_error.lock().unwrap() = Some(error);
        self
    }
}

#[async_trait::async_trait]
impl IAgentTask for MockAgent {
    fn agent_type(&self) -> AgentType {
        AgentType::Acp
    }
    fn conversation_id(&self) -> &str {
        &self.conversation_id
    }
    fn workspace(&self) -> &str {
        self.workspace_override.as_deref().unwrap_or("/tmp/test")
    }
    fn status(&self) -> Option<ConversationStatus> {
        None
    }
    fn last_activity_at(&self) -> TimestampMs {
        0
    }
    fn subscribe(&self) -> broadcast::Receiver<AgentStreamEvent> {
        self.event_tx.subscribe()
    }
    async fn send_message(&self, _data: SendMessageData) -> Result<(), AgentSendError> {
        // Emit finish event so the relay task completes
        let _ = self.event_tx.send(AgentStreamEvent::Finish(
            qianji_ai_agent::protocol::events::FinishEventData::default(),
        ));
        Ok(())
    }
    async fn cancel(&self) -> Result<(), AgentError> {
        *self.stopped.lock().unwrap() = true;
        Ok(())
    }
    fn kill(&self, _reason: Option<AgentKillReason>) -> Result<(), AgentError> {
        Ok(())
    }
}

#[async_trait::async_trait]
impl IMockAgent for MockAgent {
    fn get_confirmations(&self) -> Vec<Confirmation> {
        self.confirmations.lock().unwrap().clone()
    }
    fn check_approval(&self, action: &str, command_type: Option<&str>) -> bool {
        let key = match command_type {
            Some(ct) => format!("{action}:{ct}"),
            None => action.to_owned(),
        };
        self.approval_memory.lock().unwrap().get(&key).copied().unwrap_or(false)
    }
    fn confirm(
        &self,
        _msg_id: &str,
        call_id: &str,
        _data: serde_json::Value,
        always_allow: bool,
    ) -> Result<(), AgentError> {
        let mut confs = self.confirmations.lock().unwrap();
        let existed = confs.iter().any(|c| c.call_id == call_id);
        if !existed && !self.allow_direct_confirm {
            return Err(AgentError::not_found(format!("Confirmation {call_id} not found")));
        }
        if always_allow && let Some(conf) = confs.iter().find(|c| c.call_id == call_id) {
            let key = match (conf.action.as_deref(), conf.command_type.as_deref()) {
                (Some(a), Some(ct)) => format!("{a}:{ct}"),
                (Some(a), None) => a.to_owned(),
                _ => String::new(),
            };
            self.approval_memory.lock().unwrap().insert(key, true);
        }
        confs.retain(|c| c.call_id != call_id);
        Ok(())
    }

    async fn mode(&self) -> Result<AgentModeResponse, AgentError> {
        Ok(AgentModeResponse {
            mode: self.mode.lock().unwrap().clone(),
            initialized: true,
        })
    }

    async fn get_model(&self) -> Result<GetModelInfoResponse, AgentError> {
        let current = self.model_id.lock().unwrap().clone();
        Ok(Self::build_model_response(&current))
    }

    async fn get_config_options(&self) -> Result<GetConfigOptionsResponse, AgentError> {
        Ok(GetConfigOptionsResponse {
            config_options: self.config_options.lock().unwrap().clone(),
        })
    }

    async fn set_config_option(&self, option_id: &str, value: &str) -> Result<SetConfigOptionResponse, AgentError> {
        self.set_config_option_calls
            .lock()
            .unwrap()
            .push((option_id.to_owned(), value.to_owned()));
        if option_id == "mode" {
            *self.mode.lock().unwrap() = value.to_owned();
        }
        if let Some(error) = self.set_config_option_error.lock().unwrap().take() {
            return Err(error);
        }
        if let Some(response) = self.set_config_option_response.lock().unwrap().clone() {
            if let Some(config_options) = response.config_options.as_ref() {
                let _ = self.event_tx.send(AgentStreamEvent::AcpConfigOption(json!({
                    "config_options": config_options,
                })));
            }
            return Ok(response);
        }
        let response = SetConfigOptionResponse {
            confirmation: ConfigOptionConfirmation::Observed,
            config_options: Some(self.config_options.lock().unwrap().clone()),
        };
        if let Some(config_options) = response.config_options.as_ref() {
            let _ = self.event_tx.send(AgentStreamEvent::AcpConfigOption(json!({
                "config_options": config_options,
            })));
        }
        Ok(response)
    }
}

struct BlockingCancelAgent {
    conversation_id: String,
    agent_type: AgentType,
    event_tx: broadcast::Sender<AgentStreamEvent>,
    send_started: Notify,
    finish_notify: Notify,
    cancel_count: AtomicUsize,
    cancel_error: bool,
}

impl BlockingCancelAgent {
    fn new(conversation_id: &str) -> Self {
        Self::new_with_type(conversation_id, AgentType::Acp)
    }

    fn new_with_type(conversation_id: &str, agent_type: AgentType) -> Self {
        let (event_tx, _) = broadcast::channel(64);
        Self {
            conversation_id: conversation_id.to_owned(),
            agent_type,
            event_tx,
            send_started: Notify::new(),
            finish_notify: Notify::new(),
            cancel_count: AtomicUsize::new(0),
            cancel_error: false,
        }
    }

    fn new_with_cancel_error(conversation_id: &str) -> Self {
        let mut agent = Self::new(conversation_id);
        agent.cancel_error = true;
        agent
    }

    async fn wait_until_send_started(&self) {
        self.send_started.notified().await;
    }

    fn release_finish(&self) {
        self.finish_notify.notify_waiters();
    }
}

#[async_trait::async_trait]
impl IAgentTask for BlockingCancelAgent {
    fn agent_type(&self) -> AgentType {
        self.agent_type
    }

    fn conversation_id(&self) -> &str {
        &self.conversation_id
    }

    fn workspace(&self) -> &str {
        "/tmp/test"
    }

    fn status(&self) -> Option<ConversationStatus> {
        Some(ConversationStatus::Running)
    }

    fn last_activity_at(&self) -> TimestampMs {
        0
    }

    fn subscribe(&self) -> broadcast::Receiver<AgentStreamEvent> {
        self.event_tx.subscribe()
    }

    async fn send_message(&self, _data: SendMessageData) -> Result<(), AgentSendError> {
        self.send_started.notify_waiters();
        self.finish_notify.notified().await;
        let _ = self.event_tx.send(AgentStreamEvent::Finish(FinishEventData::default()));
        Ok(())
    }

    async fn cancel(&self) -> Result<(), AgentError> {
        self.cancel_count.fetch_add(1, Ordering::SeqCst);
        if self.cancel_error {
            return Err(AgentError::bad_gateway("cancel failed"));
        }
        Ok(())
    }

    fn kill(&self, _reason: Option<AgentKillReason>) -> Result<(), AgentError> {
        Ok(())
    }
}

impl IMockAgent for BlockingCancelAgent {}

// ── Mock WorkerTaskManager ──────────────────────────────────────

struct MockTaskManager {
    agents: Mutex<std::collections::HashMap<String, AgentInstance>>,
    kill_records: Mutex<Vec<(String, Option<AgentKillReason>)>>,
    kill_count: AtomicUsize,
}

impl MockTaskManager {
    fn new() -> Self {
        Self {
            agents: Mutex::new(std::collections::HashMap::new()),
            kill_records: Mutex::new(Vec::new()),
            kill_count: AtomicUsize::new(0),
        }
    }

    fn insert_agent(&self, conversation_id: &str, agent: AgentInstance) {
        self.agents.lock().unwrap().insert(conversation_id.to_owned(), agent);
    }

    fn kill_count(&self) -> usize {
        self.kill_count.load(Ordering::SeqCst)
    }

    fn kill_records(&self) -> Vec<(String, Option<AgentKillReason>)> {
        self.kill_records.lock().unwrap().clone()
    }
}

struct RebuildingScriptedTaskManager {
    agents: Mutex<VecDeque<AgentInstance>>,
    build_count: AtomicUsize,
    kill_count: AtomicUsize,
    captured_options: Mutex<Vec<BuildTaskOptions>>,
}

impl RebuildingScriptedTaskManager {
    fn new(agents: Vec<AgentInstance>) -> Self {
        Self {
            agents: Mutex::new(agents.into()),
            build_count: AtomicUsize::new(0),
            kill_count: AtomicUsize::new(0),
            captured_options: Mutex::new(Vec::new()),
        }
    }

    fn build_count(&self) -> usize {
        self.build_count.load(Ordering::SeqCst)
    }

    fn kill_count(&self) -> usize {
        self.kill_count.load(Ordering::SeqCst)
    }

    fn captured_options(&self) -> Vec<BuildTaskOptions> {
        self.captured_options.lock().unwrap().clone()
    }
}

#[async_trait::async_trait]
impl IWorkerTaskManager for RebuildingScriptedTaskManager {
    fn get_task(&self, _conversation_id: &str) -> Option<AgentInstance> {
        None
    }

    async fn get_or_build_task(
        &self,
        _conversation_id: &str,
        options: BuildTaskOptions,
    ) -> Result<AgentInstance, AgentError> {
        self.build_count.fetch_add(1, Ordering::SeqCst);
        self.captured_options.lock().unwrap().push(options);
        self.agents
            .lock()
            .unwrap()
            .pop_front()
            .ok_or_else(|| AgentError::bad_gateway("no scripted agent left"))
    }

    fn kill(&self, _conversation_id: &str, _reason: Option<AgentKillReason>) -> Result<(), AgentError> {
        self.kill_count.fetch_add(1, Ordering::SeqCst);
        Ok(())
    }

    fn kill_and_wait(
        &self,
        conversation_id: &str,
        reason: Option<AgentKillReason>,
    ) -> std::pin::Pin<Box<dyn std::future::Future<Output = ()> + Send>> {
        let _ = self.kill(conversation_id, reason);
        Box::pin(std::future::ready(()))
    }

    async fn clear(&self) {}

    fn active_count(&self) -> usize {
        0
    }

    fn collect_idle(&self, _idle_threshold_ms: TimestampMs) -> Vec<String> {
        Vec::new()
    }
}

struct FailingBuildTaskManager {
    error: String,
}

impl FailingBuildTaskManager {
    fn new(error: impl Into<String>) -> Self {
        Self { error: error.into() }
    }
}

struct AgentErrorFailingBuildTaskManager {
    error: Mutex<Option<AgentError>>,
}

impl AgentErrorFailingBuildTaskManager {
    fn new(error: AgentError) -> Self {
        Self {
            error: Mutex::new(Some(error)),
        }
    }
}

struct DelayedFailingBuildTaskManager {
    delay: Duration,
    error: String,
}

impl DelayedFailingBuildTaskManager {
    fn new(delay: Duration, error: impl Into<String>) -> Self {
        Self {
            delay,
            error: error.into(),
        }
    }
}

#[async_trait::async_trait]
impl IWorkerTaskManager for AgentErrorFailingBuildTaskManager {
    fn get_task(&self, _conversation_id: &str) -> Option<AgentInstance> {
        None
    }

    async fn get_or_build_task(
        &self,
        _conversation_id: &str,
        _options: BuildTaskOptions,
    ) -> Result<AgentInstance, AgentError> {
        Err(self
            .error
            .lock()
            .unwrap()
            .take()
            .expect("test build error should be consumed once"))
    }

    fn kill(&self, _conversation_id: &str, _reason: Option<AgentKillReason>) -> Result<(), AgentError> {
        Ok(())
    }

    fn kill_and_wait(
        &self,
        _conversation_id: &str,
        _reason: Option<AgentKillReason>,
    ) -> std::pin::Pin<Box<dyn std::future::Future<Output = ()> + Send>> {
        Box::pin(std::future::ready(()))
    }

    async fn clear(&self) {}

    fn active_count(&self) -> usize {
        0
    }

    fn collect_idle(&self, _idle_threshold_ms: TimestampMs) -> Vec<String> {
        vec![]
    }
}

#[async_trait::async_trait]
impl IWorkerTaskManager for DelayedFailingBuildTaskManager {
    fn get_task(&self, _conversation_id: &str) -> Option<AgentInstance> {
        None
    }

    async fn get_or_build_task(
        &self,
        _conversation_id: &str,
        _options: BuildTaskOptions,
    ) -> Result<AgentInstance, AgentError> {
        tokio::time::sleep(self.delay).await;
        Err(AgentError::bad_gateway(self.error.clone()))
    }

    fn kill(&self, _conversation_id: &str, _reason: Option<AgentKillReason>) -> Result<(), AgentError> {
        Ok(())
    }

    fn kill_and_wait(
        &self,
        _conversation_id: &str,
        _reason: Option<AgentKillReason>,
    ) -> std::pin::Pin<Box<dyn std::future::Future<Output = ()> + Send>> {
        Box::pin(std::future::ready(()))
    }

    async fn clear(&self) {}

    fn active_count(&self) -> usize {
        0
    }

    fn collect_idle(&self, _idle_threshold_ms: TimestampMs) -> Vec<String> {
        vec![]
    }
}

#[async_trait::async_trait]
impl IWorkerTaskManager for FailingBuildTaskManager {
    fn get_task(&self, _conversation_id: &str) -> Option<AgentInstance> {
        None
    }

    async fn get_or_build_task(
        &self,
        _conversation_id: &str,
        _options: BuildTaskOptions,
    ) -> Result<AgentInstance, AgentError> {
        Err(AgentError::bad_gateway(self.error.clone()))
    }

    fn kill(&self, _conversation_id: &str, _reason: Option<AgentKillReason>) -> Result<(), AgentError> {
        Ok(())
    }

    fn kill_and_wait(
        &self,
        _conversation_id: &str,
        _reason: Option<AgentKillReason>,
    ) -> std::pin::Pin<Box<dyn std::future::Future<Output = ()> + Send>> {
        Box::pin(std::future::ready(()))
    }

    async fn clear(&self) {}

    fn active_count(&self) -> usize {
        0
    }

    fn collect_idle(&self, _idle_threshold_ms: TimestampMs) -> Vec<String> {
        vec![]
    }
}

#[async_trait::async_trait]
impl IWorkerTaskManager for MockTaskManager {
    fn get_task(&self, conversation_id: &str) -> Option<AgentInstance> {
        self.agents.lock().unwrap().get(conversation_id).cloned()
    }

    async fn get_or_build_task(
        &self,
        conversation_id: &str,
        _options: BuildTaskOptions,
    ) -> Result<AgentInstance, AgentError> {
        let mut agents = self.agents.lock().unwrap();
        if let Some(existing) = agents.get(conversation_id) {
            return Ok(existing.clone());
        }
        let instance = AgentInstance::Mock(Arc::new(MockAgent::new(conversation_id)));
        agents.insert(conversation_id.to_owned(), instance.clone());
        Ok(instance)
    }

    fn kill(&self, conversation_id: &str, _reason: Option<AgentKillReason>) -> Result<(), AgentError> {
        self.kill_count.fetch_add(1, Ordering::SeqCst);
        self.kill_records
            .lock()
            .unwrap()
            .push((conversation_id.to_owned(), _reason));
        self.agents.lock().unwrap().remove(conversation_id);
        Ok(())
    }

    fn kill_and_wait(
        &self,
        conversation_id: &str,
        reason: Option<AgentKillReason>,
    ) -> std::pin::Pin<Box<dyn std::future::Future<Output = ()> + Send>> {
        let _ = self.kill(conversation_id, reason);
        Box::pin(std::future::ready(()))
    }

    async fn clear(&self) {
        self.agents.lock().unwrap().clear();
    }

    fn active_count(&self) -> usize {
        self.agents.lock().unwrap().len()
    }

    fn active_conversation_ids(&self) -> Vec<String> {
        self.agents.lock().unwrap().keys().cloned().collect()
    }

    fn collect_idle(&self, _idle_threshold_ms: TimestampMs) -> Vec<String> {
        vec![]
    }
}

struct SlowBuildTaskManager {
    delay: Duration,
    built: AtomicBool,
}

struct SlowRestartTaskManager {
    delay: Duration,
    agent: Mutex<Option<AgentInstance>>,
    rebuilt: AtomicBool,
}

impl SlowRestartTaskManager {
    fn new(delay: Duration) -> Self {
        Self {
            delay,
            agent: Mutex::new(None),
            rebuilt: AtomicBool::new(false),
        }
    }

    fn insert_agent(&self, conversation_id: &str) {
        self.agent
            .lock()
            .unwrap()
            .replace(AgentInstance::Mock(Arc::new(MockAgent::new(conversation_id))));
    }

    fn was_rebuilt(&self) -> bool {
        self.rebuilt.load(Ordering::SeqCst)
    }
}

#[async_trait::async_trait]
impl IWorkerTaskManager for SlowRestartTaskManager {
    fn get_task(&self, _conversation_id: &str) -> Option<AgentInstance> {
        self.agent.lock().unwrap().clone()
    }

    async fn get_or_build_task(
        &self,
        conversation_id: &str,
        _options: BuildTaskOptions,
    ) -> Result<AgentInstance, AgentError> {
        tokio::time::sleep(self.delay).await;
        let agent = AgentInstance::Mock(Arc::new(MockAgent::new(conversation_id)));
        self.agent.lock().unwrap().replace(agent.clone());
        self.rebuilt.store(true, Ordering::SeqCst);
        Ok(agent)
    }

    fn kill(&self, _conversation_id: &str, _reason: Option<AgentKillReason>) -> Result<(), AgentError> {
        self.agent.lock().unwrap().take();
        Ok(())
    }

    fn kill_and_wait(
        &self,
        conversation_id: &str,
        reason: Option<AgentKillReason>,
    ) -> std::pin::Pin<Box<dyn std::future::Future<Output = ()> + Send>> {
        let _ = self.kill(conversation_id, reason);
        Box::pin(std::future::ready(()))
    }

    async fn clear(&self) {
        self.agent.lock().unwrap().take();
    }

    fn active_count(&self) -> usize {
        usize::from(self.agent.lock().unwrap().is_some())
    }

    fn collect_idle(&self, _idle_threshold_ms: TimestampMs) -> Vec<String> {
        Vec::new()
    }
}

impl SlowBuildTaskManager {
    fn new(delay: Duration) -> Self {
        Self {
            delay,
            built: AtomicBool::new(false),
        }
    }

    fn was_built(&self) -> bool {
        self.built.load(Ordering::SeqCst)
    }
}

#[async_trait::async_trait]
impl IWorkerTaskManager for SlowBuildTaskManager {
    fn get_task(&self, _conversation_id: &str) -> Option<AgentInstance> {
        None
    }

    async fn get_or_build_task(
        &self,
        conversation_id: &str,
        _options: BuildTaskOptions,
    ) -> Result<AgentInstance, AgentError> {
        tokio::time::sleep(self.delay).await;
        self.built.store(true, Ordering::SeqCst);
        Ok(AgentInstance::Mock(Arc::new(MockAgent::new(conversation_id))))
    }

    fn kill(&self, _conversation_id: &str, _reason: Option<AgentKillReason>) -> Result<(), AgentError> {
        Ok(())
    }

    fn kill_and_wait(
        &self,
        _conversation_id: &str,
        _reason: Option<AgentKillReason>,
    ) -> std::pin::Pin<Box<dyn std::future::Future<Output = ()> + Send>> {
        Box::pin(std::future::ready(()))
    }

    async fn clear(&self) {}

    fn active_count(&self) -> usize {
        usize::from(self.was_built())
    }

    fn collect_idle(&self, _idle_threshold_ms: TimestampMs) -> Vec<String> {
        vec![]
    }
}

/// A variant of MockTaskManager that always builds agents with a specific workspace.
struct MockTaskManagerWithWorkspace {
    workspace: String,
    agents: Mutex<std::collections::HashMap<String, AgentInstance>>,
}

impl MockTaskManagerWithWorkspace {
    fn new(workspace: &str) -> Self {
        Self {
            workspace: workspace.to_owned(),
            agents: Mutex::new(std::collections::HashMap::new()),
        }
    }
}

#[async_trait::async_trait]
impl IWorkerTaskManager for MockTaskManagerWithWorkspace {
    fn get_task(&self, conversation_id: &str) -> Option<AgentInstance> {
        self.agents.lock().unwrap().get(conversation_id).cloned()
    }

    async fn get_or_build_task(
        &self,
        conversation_id: &str,
        _options: BuildTaskOptions,
    ) -> Result<AgentInstance, AgentError> {
        let workspace = self.workspace.clone();
        let mut agents = self.agents.lock().unwrap();
        if let Some(existing) = agents.get(conversation_id) {
            return Ok(existing.clone());
        }
        let mut agent = MockAgent::new(conversation_id);
        agent.workspace_override = Some(workspace);
        let instance = AgentInstance::Mock(Arc::new(agent));
        agents.insert(conversation_id.to_owned(), instance.clone());
        Ok(instance)
    }

    fn kill(&self, conversation_id: &str, _reason: Option<AgentKillReason>) -> Result<(), AgentError> {
        self.agents.lock().unwrap().remove(conversation_id);
        Ok(())
    }

    fn kill_and_wait(
        &self,
        conversation_id: &str,
        reason: Option<AgentKillReason>,
    ) -> std::pin::Pin<Box<dyn std::future::Future<Output = ()> + Send>> {
        let _ = self.kill(conversation_id, reason);
        Box::pin(std::future::ready(()))
    }

    async fn clear(&self) {
        self.agents.lock().unwrap().clear();
    }

    fn active_count(&self) -> usize {
        self.agents.lock().unwrap().len()
    }

    fn active_conversation_ids(&self) -> Vec<String> {
        self.agents.lock().unwrap().keys().cloned().collect()
    }

    fn collect_idle(&self, _idle_threshold_ms: TimestampMs) -> Vec<String> {
        vec![]
    }
}

struct ScriptedAgent {
    conversation_id: String,
    agent_type: AgentType,
    status: Option<ConversationStatus>,
    event_tx: broadcast::Sender<AgentStreamEvent>,
    scripts: Mutex<VecDeque<Vec<AgentStreamEvent>>>,
    sent_contents: Mutex<Vec<String>>,
    send_error: Option<AgentSendError>,
}

impl ScriptedAgent {
    fn new(conversation_id: &str, scripts: Vec<Vec<AgentStreamEvent>>) -> Self {
        let (event_tx, _) = broadcast::channel(64);
        Self {
            conversation_id: conversation_id.to_owned(),
            agent_type: AgentType::Acp,
            status: Some(ConversationStatus::Finished),
            event_tx,
            scripts: Mutex::new(VecDeque::from(scripts)),
            sent_contents: Mutex::new(vec![]),
            send_error: None,
        }
    }

    fn with_agent_type(mut self, agent_type: AgentType) -> Self {
        self.agent_type = agent_type;
        self
    }

    fn with_status(mut self, status: Option<ConversationStatus>) -> Self {
        self.status = status;
        self
    }

    fn with_send_error(mut self, error: AgentSendError) -> Self {
        self.send_error = Some(error);
        self
    }

    fn sent_contents(&self) -> Vec<String> {
        self.sent_contents.lock().unwrap().clone()
    }
}

#[async_trait::async_trait]
impl IAgentTask for ScriptedAgent {
    fn agent_type(&self) -> AgentType {
        self.agent_type
    }

    fn conversation_id(&self) -> &str {
        &self.conversation_id
    }

    fn workspace(&self) -> &str {
        "/tmp/test"
    }

    fn status(&self) -> Option<ConversationStatus> {
        self.status
    }

    fn last_activity_at(&self) -> TimestampMs {
        0
    }

    fn subscribe(&self) -> broadcast::Receiver<AgentStreamEvent> {
        self.event_tx.subscribe()
    }

    async fn send_message(&self, data: SendMessageData) -> Result<(), AgentSendError> {
        self.sent_contents.lock().unwrap().push(data.content);
        let script = self
            .scripts
            .lock()
            .unwrap()
            .pop_front()
            .unwrap_or_else(|| vec![AgentStreamEvent::Finish(FinishEventData::default())]);
        for event in script {
            let _ = self.event_tx.send(event);
        }
        if let Some(error) = &self.send_error {
            return Err(error.clone());
        }
        Ok(())
    }

    async fn cancel(&self) -> Result<(), AgentError> {
        Ok(())
    }

    fn kill(&self, _reason: Option<AgentKillReason>) -> Result<(), AgentError> {
        Ok(())
    }
}

impl IMockAgent for ScriptedAgent {}

// ── send_message tests ──────────────────────────────────────────

fn make_send_req() -> SendMessageRequest {
    serde_json::from_value(json!({
        "content": "Hello"
    }))
    .unwrap()
}

fn assert_conversation_runtime_context(options: &BuildTaskOptions, user_id: &str, conversation_id: &str) {
    assert!(
        options
            .context
            .runtime_env
            .contains(&("QIANJI_USER_ID".to_owned(), user_id.to_owned())),
        "runtime env should include QIANJI_USER_ID"
    );
    assert!(
        options
            .context
            .runtime_env
            .contains(&("QIANJI_CONVERSATION_ID".to_owned(), conversation_id.to_owned())),
        "runtime env should include QIANJI_CONVERSATION_ID"
    );
    assert_eq!(
        options.runtime_capabilities.conversation_runtime_context_version,
        Some(CONVERSATION_RUNTIME_CONTEXT_VERSION)
    );
}

async fn wait_for_turn_released(svc: &ConversationService, conversation_id: &str) {
    tokio::time::timeout(Duration::from_secs(2), async {
        loop {
            if !svc.runtime_state().is_claimed(conversation_id) {
                break;
            }
            tokio::time::sleep(Duration::from_millis(10)).await;
        }
    })
    .await
    .expect("turn should release runtime claim");
}

#[tokio::test]
async fn send_message_returns_accepted() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let task_mgr: Arc<dyn IWorkerTaskManager> = Arc::new(MockTaskManager::new());

    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    let response = svc
        .send_message("user_1", &conv.id, make_send_req(), &task_mgr)
        .await
        .unwrap();

    assert!(!response.msg_id.is_empty(), "msg_id must be non-empty");
    assert_eq!(response.msg_id.len(), 8, "msg_id should be an 8-char short hex ID");
    assert!(response.turn_id.starts_with("turn_"), "turn_id must use turn_ prefix");
    assert_ne!(response.msg_id, response.turn_id, "turn_id must not reuse msg_id");
}

/// B5 test double: a mid-turn-capable agent that records `deliver_midturn`
/// calls; `scripted_error` lets a test replay a steer rejection. `held_claim`
/// (when set) is dropped BEFORE the rejection returns — modelling the live
/// race where codex's turn ends (claim released) between the routing check and
/// the steer write, so the fallback's fresh claim succeeds deterministically.
struct MidturnMockAgent {
    conversation_id: String,
    event_tx: broadcast::Sender<AgentStreamEvent>,
    delivered: Mutex<Vec<SendMessageData>>,
    scripted_error: Mutex<Option<AgentSendError>>,
    held_claim: Mutex<Option<crate::runtime_state::TurnClaim>>,
    /// Pending permission confirmations (spec §4.6 gate): while non-empty the
    /// mid-turn routing branch must fall through to the 409 claim path.
    confirmations: Mutex<Vec<Confirmation>>,
}

impl MidturnMockAgent {
    fn new(conversation_id: &str) -> Self {
        let (event_tx, _) = broadcast::channel(16);
        Self {
            conversation_id: conversation_id.to_owned(),
            event_tx,
            delivered: Mutex::new(Vec::new()),
            scripted_error: Mutex::new(None),
            held_claim: Mutex::new(None),
            confirmations: Mutex::new(Vec::new()),
        }
    }
}

#[async_trait::async_trait]
impl IAgentTask for MidturnMockAgent {
    fn agent_type(&self) -> AgentType {
        AgentType::Acp
    }
    fn conversation_id(&self) -> &str {
        &self.conversation_id
    }
    fn workspace(&self) -> &str {
        "/tmp/test"
    }
    fn status(&self) -> Option<ConversationStatus> {
        None
    }
    fn last_activity_at(&self) -> qianji_common::TimestampMs {
        qianji_common::now_ms()
    }
    fn subscribe(&self) -> broadcast::Receiver<AgentStreamEvent> {
        self.event_tx.subscribe()
    }
    fn supports_midturn_delivery(&self) -> bool {
        true
    }
    async fn send_message(&self, _data: SendMessageData) -> Result<(), AgentSendError> {
        // Emit finish so a fallback-opened normal turn's relay completes.
        let _ = self.event_tx.send(AgentStreamEvent::Finish(FinishEventData::default()));
        Ok(())
    }
    async fn cancel(&self) -> Result<(), AgentError> {
        Ok(())
    }
    fn kill(&self, _reason: Option<AgentKillReason>) -> Result<(), AgentError> {
        Ok(())
    }
}

#[async_trait::async_trait]
impl IMockAgent for MidturnMockAgent {
    fn get_confirmations(&self) -> Vec<Confirmation> {
        self.confirmations.lock().unwrap().clone()
    }
    async fn deliver_midturn(&self, data: SendMessageData) -> Result<(), AgentSendError> {
        if let Some(err) = self.scripted_error.lock().unwrap().take() {
            // The turn "ended": release the held claim so the fallback's
            // fresh claim succeeds (deterministic stand-in for the live race).
            self.held_claim.lock().unwrap().take();
            return Err(err);
        }
        self.delivered.lock().unwrap().push(data);
        Ok(())
    }
}

/// B5 routing (spec §4.3): an ACTIVE turn + a supporting backend → the message
/// is delivered mid-turn (no 409, no new turn id), persisted with the
/// pending-receipt status, and `message.userCreated` carries the correlation
/// id.
#[tokio::test]
async fn midturn_send_delivers_into_the_active_turn() {
    let (svc, broadcaster, repo, _d) = make_service();
    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    let _claim = svc
        .runtime_state()
        .try_claim_turn(&conv.id, "turn_active")
        .expect("claim the active turn");
    let agent = Arc::new(MidturnMockAgent::new(&conv.id));
    let task_mgr = Arc::new(MockTaskManager::new());
    task_mgr.insert_agent(&conv.id, AgentInstance::Mock(agent.clone()));
    let task_mgr_dyn: Arc<dyn IWorkerTaskManager> = task_mgr;
    broadcaster.take_events();

    let response = svc
        .send_message("user_1", &conv.id, make_send_req(), &task_mgr_dyn)
        .await
        .expect("mid-turn send must not 409");

    assert_eq!(response.turn_id, "turn_active", "response carries the ACTIVE turn id");
    assert!(response.delivered_midturn, "response flags the mid-turn delivery");
    let delivered = agent.delivered.lock().unwrap().clone();
    assert_eq!(delivered.len(), 1, "delivered through the mid-turn path exactly once");
    assert_eq!(delivered[0].content, "Hello");
    assert_eq!(
        delivered[0].msg_id, response.msg_id,
        "the wire correlation id IS the persisted msg_id"
    );
    assert_eq!(delivered[0].turn_id.as_deref(), Some("turn_active"));
    // The active claim was never stolen and no new turn id was minted.
    assert_eq!(
        svc.runtime_state().active_turn_id_for(&conv.id).as_deref(),
        Some("turn_active")
    );
    // userCreated carries the correlation id + pending-receipt status.
    let events = broadcaster.take_events();
    let created = events
        .iter()
        .find(|e| e.name == "message.userCreated")
        .expect("userCreated broadcast");
    assert_eq!(created.data["client_msg_id"], response.msg_id.as_str());
    assert_eq!(created.data["status"], "pending");
    // Persisted with the pending-receipt status.
    let rows: Vec<_> = repo
        .messages
        .lock()
        .unwrap()
        .iter()
        .filter(|m| m.msg_id.as_deref() == Some(response.msg_id.as_str()))
        .cloned()
        .collect();
    assert_eq!(rows.len(), 1, "persisted exactly once");
    assert_eq!(rows[0].status.as_deref(), Some("pending"));
}

/// B5 fallback (spec §6甲.1): codex rejected the steer because the turn ended
/// → the send falls back to opening a NEW turn; the already-persisted message
/// is reused (no duplicate row) and its status leaves the pending state.
#[tokio::test]
async fn midturn_steer_rejection_turn_ended_falls_back_to_a_new_turn() {
    let (svc, _broadcaster, repo, _d) = make_service();
    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    let claim = svc
        .runtime_state()
        .try_claim_turn(&conv.id, "turn_active")
        .expect("claim the active turn");
    let agent = Arc::new(MidturnMockAgent::new(&conv.id));
    // codex wording verbatim (locked): both rejections are -32600; only the
    // message text distinguishes them.
    *agent.scripted_error.lock().unwrap() = Some(AgentSendError::from_agent_error(AgentError::bad_gateway(
        "backend transport error: no active turn to steer",
    )));
    *agent.held_claim.lock().unwrap() = Some(claim);
    let task_mgr = Arc::new(MockTaskManager::new());
    task_mgr.insert_agent(&conv.id, AgentInstance::Mock(agent.clone()));
    let task_mgr_dyn: Arc<dyn IWorkerTaskManager> = task_mgr;

    let response = svc
        .send_message("user_1", &conv.id, make_send_req(), &task_mgr_dyn)
        .await
        .expect("the fallback must open a new turn, not fail");

    assert_ne!(response.turn_id, "turn_active", "a NEW turn id is minted on fallback");
    assert!(response.turn_id.starts_with("turn_"));
    assert!(
        !response.delivered_midturn,
        "a fallback send is an ordinary new-turn send"
    );
    assert!(
        agent.delivered.lock().unwrap().is_empty(),
        "nothing was delivered mid-turn"
    );
    // Exactly ONE persisted user row (reused, not duplicated), no longer pending.
    let rows: Vec<_> = repo
        .messages
        .lock()
        .unwrap()
        .iter()
        .filter(|m| m.msg_id.as_deref() == Some(response.msg_id.as_str()))
        .cloned()
        .collect();
    assert_eq!(rows.len(), 1, "the fallback must reuse the row, not duplicate it");
    assert_eq!(rows[0].status.as_deref(), Some("finish"));
    wait_for_turn_released(&svc, &conv.id).await;
}

/// §4.6 (review fix): a turn blocked on a pending permission confirmation
/// must NOT be steered into, even for a supporting backend — the mid-turn
/// branch falls through to the claim, restoring the exact pre-B5 409 at the
/// HTTP API (the frontend gate alone does not bind direct API clients).
#[tokio::test]
async fn midturn_send_during_pending_confirmation_stays_409() {
    let (svc, broadcaster, repo, _d) = make_service();
    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    let _claim = svc
        .runtime_state()
        .try_claim_turn(&conv.id, "turn_active")
        .expect("claim the active turn");
    let agent = Arc::new(MidturnMockAgent::new(&conv.id));
    *agent.confirmations.lock().unwrap() = vec![Confirmation {
        id: "c1".into(),
        call_id: "call-1".into(),
        title: Some("Allow file edit".into()),
        action: Some("edit_file".into()),
        description: "Edit main.rs".into(),
        command_type: Some("bash".into()),
        questions: None,
        options: vec![],
    }];
    let task_mgr = Arc::new(MockTaskManager::new());
    task_mgr.insert_agent(&conv.id, AgentInstance::Mock(agent.clone()));
    let task_mgr_dyn: Arc<dyn IWorkerTaskManager> = task_mgr;
    broadcaster.take_events();

    let err = svc
        .send_message("user_1", &conv.id, make_send_req(), &task_mgr_dyn)
        .await
        .expect_err("a send during requires_action must be rejected");
    assert!(
        err.to_string().contains("already running"),
        "the pre-B5 running-conversation conflict is preserved, got: {err}"
    );
    // Nothing was delivered, persisted, or broadcast.
    assert!(
        agent.delivered.lock().unwrap().is_empty(),
        "no mid-turn delivery may happen while a confirmation is pending"
    );
    assert!(
        repo.messages.lock().unwrap().is_empty(),
        "the rejected message must not be persisted"
    );
    let events = broadcaster.take_events();
    assert!(
        !events
            .iter()
            .any(|e| e.name == "message.userCreated" || e.name == "message.statusChanged"),
        "no message events for a rejected send, got: {:?}",
        events.iter().map(|e| e.name.clone()).collect::<Vec<_>>()
    );
}

/// The §6甲.1 message-text classification is load-bearing — lock it so a codex
/// wording change (or an error-mapping change that drops the text) fails here
/// instead of silently degrading every turn-ended fallback into a hard error.
#[test]
fn steer_rejection_classifier_matches_only_the_turn_ended_text() {
    let turn_ended = AgentSendError::from_agent_error(AgentError::bad_gateway(
        "backend transport error: no active turn to steer",
    ));
    assert!(crate::service::steer_rejection_is_turn_ended(&turn_ended));
    let other = AgentSendError::from_agent_error(AgentError::bad_gateway(
        "backend transport error: turn/steer rejected: expected active turn id `a` but found `b`",
    ));
    assert!(!crate::service::steer_rejection_is_turn_ended(&other));
    let unrelated = AgentSendError::from_agent_error(AgentError::bad_gateway("boom"));
    assert!(!crate::service::steer_rejection_is_turn_ended(&unrelated));
}

#[tokio::test]
async fn send_message_injects_conversation_runtime_context() {
    let (svc, _broadcaster, _repo, _default_task_mgr) = make_service();
    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    let task_mgr = Arc::new(RebuildingScriptedTaskManager::new(vec![AgentInstance::Mock(Arc::new(
        MockAgent::new(&conv.id),
    ))]));
    let task_mgr_dyn: Arc<dyn IWorkerTaskManager> = task_mgr.clone();

    svc.send_message("user_1", &conv.id, make_send_req(), &task_mgr_dyn)
        .await
        .unwrap();
    wait_for_turn_released(&svc, &conv.id).await;

    let options = task_mgr.captured_options();
    assert_eq!(options.len(), 1);
    assert_conversation_runtime_context(&options[0], "user_1", &conv.id);
}

#[tokio::test]
async fn send_message_injects_configured_runtime_helper_context() {
    let (svc, _broadcaster, _repo, _default_task_mgr) = make_service();
    let svc = svc.with_runtime_helper_context(
        "/Applications/Qianji/qianjicore".to_owned(),
        "http://127.0.0.1:51234".to_owned(),
    );
    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    let task_mgr = Arc::new(RebuildingScriptedTaskManager::new(vec![AgentInstance::Mock(Arc::new(
        MockAgent::new(&conv.id),
    ))]));
    let task_mgr_dyn: Arc<dyn IWorkerTaskManager> = task_mgr.clone();

    svc.send_message("user_1", &conv.id, make_send_req(), &task_mgr_dyn)
        .await
        .unwrap();
    wait_for_turn_released(&svc, &conv.id).await;

    let options = task_mgr.captured_options();
    assert_eq!(options.len(), 1);
    assert!(
        options[0].context.runtime_env.contains(&(
            QIANJI_HELPER_BIN_ENV.to_owned(),
            "/Applications/Qianji/qianjicore".to_owned()
        )),
        "runtime env should include QIANJI_HELPER_BIN"
    );
    assert!(
        options[0]
            .context
            .runtime_env
            .contains(&(QIANJI_BASE_URL_ENV.to_owned(), "http://127.0.0.1:51234".to_owned())),
        "runtime env should include QIANJI_BASE_URL"
    );
}

#[tokio::test]
async fn run_agent_turn_injects_conversation_runtime_context() {
    let task_mgr = Arc::new(RebuildingScriptedTaskManager::new(vec![AgentInstance::Mock(Arc::new(
        MockAgent::new("placeholder"),
    ))]));
    let task_mgr_dyn: Arc<dyn IWorkerTaskManager> = task_mgr.clone();
    let repo = Arc::new(MockRepo::new());
    let service = ConversationService::new(
        std::env::temp_dir(),
        Arc::new(MockBroadcaster::new()),
        Arc::new(FixedSkillResolver { names: vec![] }),
        task_mgr_dyn,
        repo,
        Arc::new(StubAgentMetadataRepo),
        Arc::new(StubAcpSessionRepo::default()),
    );
    let conv = service.create("user_1", make_create_req()).await.unwrap();

    let outcome = service
        .run_agent_turn(ConversationAgentTurnRequest {
            user_id: "user_1".into(),
            conversation_id: conv.id.clone(),
            content: "run scheduled task".into(),
            files: Vec::new(),
            inject_skills: Vec::new(),
            required_runtime_mode: None,
            persist_user_message: true,
            user_message_hidden: true,
            on_started: None,
        })
        .await
        .unwrap();

    assert_eq!(outcome.status, ConversationAgentTurnStatus::Completed);
    let options = task_mgr.captured_options();
    assert_eq!(options.len(), 1);
    assert_conversation_runtime_context(&options[0], "user_1", &conv.id);
}

#[tokio::test]
async fn send_message_returns_msg_id_and_turn_id_and_summary_tracks_turn() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let slow_task_mgr = Arc::new(SlowBuildTaskManager::new(Duration::from_millis(500)));
    let task_mgr: Arc<dyn IWorkerTaskManager> = slow_task_mgr.clone();

    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    let response = svc
        .send_message("user_1", &conv.id, make_send_req(), &task_mgr)
        .await
        .unwrap();

    assert!(!response.msg_id.is_empty(), "msg_id must be non-empty");
    assert!(response.turn_id.starts_with("turn_"), "turn_id must use turn_ prefix");
    assert_ne!(response.msg_id, response.turn_id, "turn_id must not reuse msg_id");
    assert_eq!(
        response.runtime.turn_id.as_deref(),
        Some(response.turn_id.as_str()),
        "send response runtime must identify the accepted turn"
    );
    assert!(response.runtime.is_processing);
    assert!(!response.runtime.can_send_message);

    let runtime = svc.runtime_summary_for(&conv.id).await;
    assert_eq!(response.runtime, runtime);
    assert_eq!(runtime.turn_id.as_deref(), Some(response.turn_id.as_str()));
    assert!(runtime.is_processing);
    assert!(!runtime.can_send_message);
}

/// Bugfix: `supports_midturn_delivery` is a STATIC property of the
/// conversation's backend type, not of agent liveness. A fresh (pre-ensure)
/// or dormant claude conversation must still report `true`, otherwise the
/// frontend hydrate fetch races the send accept and gates the whole first
/// turn into the client queue panel.
#[tokio::test]
async fn runtime_summary_reports_backend_static_midturn_bit_without_live_agent() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();

    // No runtime/ensure has run: MockTaskManager holds no task for any of
    // these conversations, so the bit must come from the backend identity.
    for (backend, expected) in [
        ("claude", true),
        ("codex", true),
        ("antigravity", false),
        ("gemini", false),
    ] {
        let conv = svc
            .create("user_1", make_create_req_with_backend(backend))
            .await
            .unwrap();
        let runtime = svc.runtime_summary_for(&conv.id).await;
        assert!(!runtime.has_task, "precondition: no live agent for {backend}");
        assert_eq!(
            runtime.supports_midturn_delivery, expected,
            "backend {backend} must report static supports_midturn_delivery={expected} without a live agent"
        );
    }

    // No backend identity at all (legacy/unknown row) → conservative false.
    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    let runtime = svc.runtime_summary_for(&conv.id).await;
    assert!(!runtime.supports_midturn_delivery);

    // Unknown conversation id → conservative false, no panic.
    let runtime = svc.runtime_summary_for("conv-does-not-exist").await;
    assert!(!runtime.supports_midturn_delivery);
}

#[tokio::test]
async fn send_message_rejects_legacy_runtime_conversations_as_archived() {
    let (svc, _broadcaster, repo, _task_mgr) = make_service();
    let task_mgr: Arc<dyn IWorkerTaskManager> = Arc::new(MockTaskManager::new());

    for agent_type in [
        AgentType::Gemini,
        AgentType::Codex,
        AgentType::OpenclawGateway,
        AgentType::Nanobot,
        AgentType::Remote,
    ] {
        let conv = insert_conversation_with_type(&repo, "user_1", agent_type).await;

        let err = svc
            .send_message("user_1", &conv.id, make_send_req(), &task_mgr)
            .await
            .unwrap_err();

        assert_eq!(err.error_code(), "CONVERSATION_ARCHIVED");
        assert!(
            err.to_string()
                .contains("This historical conversation can no longer be continued. Please start a new conversation."),
            "unexpected archived message for {}: {err}",
            agent_type.serde_name()
        );
    }
}

#[tokio::test]
async fn get_config_options_returns_active_agent_snapshot() {
    let task_mgr = Arc::new(MockTaskManager::new());
    let (svc, _broadcaster, _repo) = make_service_with_mock_task_manager(task_mgr.clone());
    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    let agent = MockAgent::new(&conv.id).with_config_options(vec![AcpConfigOptionDto {
        id: "model".to_owned(),
        name: Some("Model".to_owned()),
        label: None,
        description: None,
        category: Some("model".to_owned()),
        option_type: "select".to_owned(),
        current_value: Some("gpt-5.5".to_owned()),
        options: Vec::new(),
    }]);
    task_mgr.insert_agent(&conv.id, AgentInstance::Mock(Arc::new(agent)));

    let result = svc.get_config_options("user_1", &conv.id).await.unwrap();

    assert_eq!(result.config_options[0].id, "model");
    assert_eq!(result.config_options[0].current_value.as_deref(), Some("gpt-5.5"));
}

#[tokio::test]
async fn get_config_options_rejects_cross_user_active_task() {
    let task_mgr = Arc::new(MockTaskManager::new());
    let (svc, _broadcaster, _repo) = make_service_with_mock_task_manager(task_mgr.clone());
    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    let agent = MockAgent::new(&conv.id);
    task_mgr.insert_agent(&conv.id, AgentInstance::Mock(Arc::new(agent)));

    let err = svc.get_config_options("user_2", &conv.id).await.unwrap_err();

    assert!(matches!(err, ConversationError::NotFound { id } if id == conv.id));
}

#[tokio::test]
async fn active_count_for_user_counts_only_owned_active_tasks() {
    let task_mgr = Arc::new(MockTaskManager::new());
    let (svc, _broadcaster, _repo) = make_service_with_mock_task_manager(task_mgr.clone());
    let user_1_conv = svc.create("user_1", make_create_req()).await.unwrap();
    let user_2_conv = svc.create("user_2", make_create_req()).await.unwrap();
    task_mgr.insert_agent(
        &user_1_conv.id,
        AgentInstance::Mock(Arc::new(MockAgent::new(&user_1_conv.id))),
    );
    task_mgr.insert_agent(
        &user_2_conv.id,
        AgentInstance::Mock(Arc::new(MockAgent::new(&user_2_conv.id))),
    );

    assert_eq!(svc.active_count_for_user("user_1").await.unwrap(), 1);
    assert_eq!(svc.active_count_for_user("user_2").await.unwrap(), 1);
    assert_eq!(svc.active_count_for_user("user_3").await.unwrap(), 0);
}

#[tokio::test]
async fn terminate_runtime_for_user_kills_only_owned_active_tasks() {
    let task_mgr = Arc::new(MockTaskManager::new());
    let (svc, _broadcaster, _repo) = make_service_with_mock_task_manager(task_mgr.clone());
    let user_1_conv = svc.create("user_1", make_create_req()).await.unwrap();
    let user_2_conv = svc.create("user_2", make_create_req()).await.unwrap();
    task_mgr.insert_agent(
        &user_1_conv.id,
        AgentInstance::Mock(Arc::new(MockAgent::new(&user_1_conv.id))),
    );
    task_mgr.insert_agent(
        &user_2_conv.id,
        AgentInstance::Mock(Arc::new(MockAgent::new(&user_2_conv.id))),
    );
    let runtime_state = svc.runtime_state();
    let _claim = runtime_state
        .try_claim_turn(&user_1_conv.id, "turn-1")
        .expect("claim should be created");
    runtime_state.mark_cancelling(&user_1_conv.id);

    let terminated = svc.terminate_runtime_for_user("user_1").await.unwrap();

    assert_eq!(terminated, 1);
    assert_eq!(
        task_mgr.kill_records(),
        vec![(user_1_conv.id.clone(), Some(AgentKillReason::SessionRevoked))]
    );
    assert!(!runtime_state.is_claimed(&user_1_conv.id));
    assert!(!runtime_state.is_cancelling(&user_1_conv.id));
    assert_eq!(task_mgr.active_count(), 1);
    assert!(task_mgr.get_task(&user_2_conv.id).is_some());
}

#[tokio::test]
async fn ensure_runtime_recovers_missing_agent_and_returns_snapshot() {
    let task_mgr = Arc::new(MockTaskManager::new());
    let (svc, _broadcaster, _repo) = make_service_with_mock_task_manager(task_mgr.clone());
    let conv = svc.create("user_1", make_create_req()).await.unwrap();

    let result = svc
        .ensure_runtime("user_1", &conv.id, &(task_mgr.clone() as Arc<dyn IWorkerTaskManager>))
        .await
        .unwrap();

    assert!(result.recovered);
    assert!(result.runtime.has_task);
    assert!(task_mgr.get_task(&conv.id).is_some());
    assert!(result.config_options.is_empty());
}

#[tokio::test]
async fn ensure_runtime_rejects_team_owned_conversation() {
    let task_mgr = Arc::new(MockTaskManager::new());
    let (svc, _broadcaster, _repo) = make_service_with_mock_task_manager(task_mgr.clone());
    let mut req = make_create_req();
    req.extra = serde_json::json!({
        "teamId": "team-1",
        "slot_id": "slot-1",
        "role": "lead"
    });
    let conv = svc.create("user_1", req).await.unwrap();

    let err = svc
        .ensure_runtime("user_1", &conv.id, &(task_mgr.clone() as Arc<dyn IWorkerTaskManager>))
        .await
        .unwrap_err();

    assert!(
        matches!(
            &err,
            ConversationError::TeamRuntimeRequired {
                conversation_id,
                team_id,
            } if conversation_id == &conv.id && team_id == "team-1"
        ),
        "unexpected error: {err:?}"
    );
    assert!(
        task_mgr.get_task(&conv.id).is_none(),
        "standalone ensure must not build team-owned conversation runtime"
    );
}

#[tokio::test]
async fn ensure_runtime_uses_existing_agent_snapshot_without_recovery() {
    let task_mgr = Arc::new(MockTaskManager::new());
    let (svc, _broadcaster, _repo) = make_service_with_mock_task_manager(task_mgr.clone());
    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    let agent = MockAgent::new(&conv.id).with_config_options(vec![AcpConfigOptionDto {
        id: "model".to_owned(),
        name: Some("Model".to_owned()),
        label: None,
        description: None,
        category: Some("model".to_owned()),
        option_type: "select".to_owned(),
        current_value: Some("gpt-5.5".to_owned()),
        options: Vec::new(),
    }]);
    task_mgr.insert_agent(&conv.id, AgentInstance::Mock(Arc::new(agent)));

    let result = svc
        .ensure_runtime("user_1", &conv.id, &(task_mgr.clone() as Arc<dyn IWorkerTaskManager>))
        .await
        .unwrap();

    assert!(!result.recovered);
    assert!(result.runtime.has_task);
    assert_eq!(result.config_options[0].id, "model");
    assert_eq!(result.config_options[0].current_value.as_deref(), Some("gpt-5.5"));
}

#[tokio::test]
async fn restart_runtime_without_existing_task_is_rejected() {
    let task_mgr = Arc::new(MockTaskManager::new());
    let (svc, _broadcaster, _repo) = make_service_with_mock_task_manager(task_mgr.clone());
    let conv = svc.create("user_1", make_create_req()).await.unwrap();

    let error = svc
        .restart_runtime("user_1", &conv.id, &(task_mgr.clone() as Arc<dyn IWorkerTaskManager>))
        .await
        .unwrap_err();

    assert!(matches!(
        error,
        ConversationError::Busy { reason }
            if reason == format!("conversation {} runtime is not ready to restart", conv.id)
    ));
    assert_eq!(task_mgr.kill_count(), 0);
    assert!(task_mgr.get_task(&conv.id).is_none());
}

#[tokio::test]
async fn restart_runtime_evicts_existing_task_before_rebuild() {
    let task_mgr = Arc::new(MockTaskManager::new());
    let (svc, _broadcaster, _repo) = make_service_with_mock_task_manager(task_mgr.clone());
    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    let old_agent = MockAgent::new(&conv.id).with_config_options(vec![AcpConfigOptionDto {
        id: "model".to_owned(),
        name: Some("Old Model".to_owned()),
        label: None,
        description: None,
        category: Some("model".to_owned()),
        option_type: "select".to_owned(),
        current_value: Some("old-model".to_owned()),
        options: Vec::new(),
    }]);
    task_mgr.insert_agent(&conv.id, AgentInstance::Mock(Arc::new(old_agent)));

    let result = svc
        .restart_runtime("user_1", &conv.id, &(task_mgr.clone() as Arc<dyn IWorkerTaskManager>))
        .await
        .unwrap();

    assert_eq!(task_mgr.kill_count(), 1);
    assert_eq!(
        task_mgr.kill_records(),
        vec![(conv.id.clone(), Some(AgentKillReason::RuntimeRestart))]
    );
    assert!(result.recovered);
    assert!(result.runtime.has_task);
    assert!(
        result.config_options.is_empty(),
        "response must come from the newly built task, not the evicted instance"
    );
}

#[tokio::test]
async fn restart_runtime_cancels_active_turn_before_rebuild() {
    let task_mgr = Arc::new(MockTaskManager::new());
    let (svc, _broadcaster, _repo) = make_service_with_mock_task_manager(task_mgr.clone());
    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    let old_agent = Arc::new(BlockingCancelAgent::new(&conv.id));
    task_mgr.insert_agent(&conv.id, AgentInstance::Mock(old_agent.clone()));
    let _turn_claim = svc
        .runtime_state()
        .try_claim_turn(&conv.id, "turn-before-restart")
        .unwrap();

    let result = svc
        .restart_runtime("user_1", &conv.id, &(task_mgr.clone() as Arc<dyn IWorkerTaskManager>))
        .await
        .unwrap();

    assert_eq!(old_agent.cancel_count.load(Ordering::SeqCst), 1);
    assert_eq!(task_mgr.kill_count(), 1);
    assert!(result.runtime.has_task);
    assert!(!svc.runtime_state().is_claimed(&conv.id));
}

#[tokio::test]
async fn restart_runtime_blocks_duplicate_restart_send_and_config_until_ready() {
    let repo = Arc::new(MockRepo::new());
    let broadcaster = Arc::new(MockBroadcaster::new());
    let task_mgr = Arc::new(SlowRestartTaskManager::new(Duration::from_millis(150)));
    let task_mgr_dyn: Arc<dyn IWorkerTaskManager> = task_mgr.clone();
    let svc = ConversationService::new(
        std::env::temp_dir(),
        broadcaster,
        Arc::new(FixedSkillResolver { names: vec![] }),
        task_mgr_dyn.clone(),
        repo,
        Arc::new(StubAgentMetadataRepo),
        Arc::new(StubAcpSessionRepo::default()),
    );
    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    task_mgr.insert_agent(&conv.id);

    let restart_service = svc.clone();
    let restart_conversation_id = conv.id.clone();
    let restart_task_manager = task_mgr_dyn.clone();
    let restart = tokio::spawn(async move {
        restart_service
            .restart_runtime("user_1", &restart_conversation_id, &restart_task_manager)
            .await
    });

    tokio::time::timeout(Duration::from_secs(1), async {
        while !svc.runtime_state().is_restarting(&conv.id) {
            tokio::task::yield_now().await;
        }
    })
    .await
    .expect("restart gate should become observable");

    let summary = svc.runtime_summary_for(&conv.id).await;
    assert_eq!(
        summary.state,
        qianji_api_types::ConversationRuntimeStateKind::Restarting
    );

    // All three gates report the SAME coded error, so a client has one rule to
    // retry on rather than having to match each entry point's message text.
    let duplicate = svc
        .restart_runtime("user_1", &conv.id, &task_mgr_dyn)
        .await
        .expect_err("duplicate restart must fail");
    assert!(matches!(duplicate, ConversationError::RuntimeRestarting { .. }));
    assert_eq!(duplicate.error_code(), "runtime_restarting");

    let send = svc
        .send_message("user_1", &conv.id, make_send_req(), &task_mgr_dyn)
        .await
        .expect_err("send must fail at the backend gate while restart is in progress");
    assert!(matches!(send, ConversationError::RuntimeRestarting { .. }));
    assert_eq!(send.error_code(), "runtime_restarting");

    let config = svc
        .get_config_options("user_1", &conv.id)
        .await
        .expect_err("config access must fail while restart is in progress");
    assert!(matches!(config, ConversationError::RuntimeRestarting { .. }));
    assert_eq!(config.error_code(), "runtime_restarting");

    let response = restart.await.expect("restart task should not panic").unwrap();
    assert!(task_mgr.was_rebuilt());
    assert_eq!(
        response.runtime.state,
        qianji_api_types::ConversationRuntimeStateKind::Idle
    );
    assert!(!svc.runtime_state().is_restarting(&conv.id));
}

#[tokio::test]
async fn restart_runtime_preserves_persisted_messages() {
    let task_mgr = Arc::new(MockTaskManager::new());
    let (svc, _broadcaster, repo) = make_service_with_mock_task_manager(task_mgr.clone());
    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    task_mgr.insert_agent(&conv.id, AgentInstance::Mock(Arc::new(MockAgent::new(&conv.id))));
    repo.insert_message(
        "user_1",
        &MessageRow {
            id: "message-before-restart".into(),
            conversation_id: conv.id.clone(),
            msg_id: Some("message-before-restart".into()),
            r#type: "user".into(),
            content: json!({ "text": "keep me" }).to_string(),
            position: Some("right".into()),
            status: Some("finish".into()),
            hidden: false,
            created_at: 1234,
            backend_turn_id: None,
        },
    )
    .await
    .unwrap();

    svc.restart_runtime("user_1", &conv.id, &(task_mgr.clone() as Arc<dyn IWorkerTaskManager>))
        .await
        .unwrap();

    let messages = repo_messages_asc(&repo, &conv.id, 10).await;
    assert_eq!(messages.len(), 1);
    assert_eq!(messages[0].id, "message-before-restart");
}

#[tokio::test]
async fn restart_runtime_not_found_does_not_touch_task_manager() {
    let task_mgr = Arc::new(MockTaskManager::new());
    let (svc, _broadcaster, _repo) = make_service_with_mock_task_manager(task_mgr.clone());

    let error = svc
        .restart_runtime(
            "user_1",
            "missing-conversation",
            &(task_mgr.clone() as Arc<dyn IWorkerTaskManager>),
        )
        .await
        .unwrap_err();

    assert!(matches!(error, ConversationError::NotFound { .. }));
    assert_eq!(task_mgr.kill_count(), 0);
}

#[tokio::test]
async fn restart_runtime_rejects_cross_user_access_without_eviction() {
    let task_mgr = Arc::new(MockTaskManager::new());
    let (svc, _broadcaster, _repo) = make_service_with_mock_task_manager(task_mgr.clone());
    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    task_mgr.insert_agent(&conv.id, AgentInstance::Mock(Arc::new(MockAgent::new(&conv.id))));

    let error = svc
        .restart_runtime("user_2", &conv.id, &(task_mgr.clone() as Arc<dyn IWorkerTaskManager>))
        .await
        .unwrap_err();

    assert!(matches!(error, ConversationError::NotFound { .. }));
    assert_eq!(task_mgr.kill_count(), 0);
    assert!(task_mgr.get_task(&conv.id).is_some());
}

#[tokio::test]
async fn set_config_option_returns_observed_confirmation() {
    let task_mgr = Arc::new(MockTaskManager::new());
    let (svc, _broadcaster, _repo) = make_service_with_mock_task_manager(task_mgr.clone());
    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    let agent = Arc::new(MockAgent::new(&conv.id).with_config_options(vec![AcpConfigOptionDto {
        id: "reasoning_effort".to_owned(),
        name: Some("Reasoning Effort".to_owned()),
        label: None,
        description: None,
        category: Some("thought_level".to_owned()),
        option_type: "select".to_owned(),
        current_value: Some("high".to_owned()),
        options: Vec::new(),
    }]));
    task_mgr.insert_agent(&conv.id, AgentInstance::Mock(agent.clone()));

    let result = svc
        .set_config_option(
            "user_1",
            &conv.id,
            "reasoning_effort",
            SetConfigOptionRequest {
                value: "high".to_owned(),
            },
        )
        .await
        .unwrap();

    assert_eq!(result.confirmation, ConfigOptionConfirmation::Observed);
    assert_eq!(
        agent.set_config_option_calls.lock().unwrap().as_slice(),
        &[("reasoning_effort".to_owned(), "high".to_owned())]
    );
}

#[tokio::test]
async fn save_acp_runtime_mode_updates_runtime_mode_config_selection() {
    let acp_repo = Arc::new(StubAcpSessionRepo::with_runtime_state(PersistedSessionState {
        current_mode_id: Some("read-only".to_owned()),
        current_model_id: Some("gpt-5.3-codex".to_owned()),
        config_selections_json: Some(
            serde_json::json!({
                "mode": "read-only",
                "model": "gpt-5.3-codex",
                "reasoning_effort": "low"
            })
            .to_string(),
        ),
        context_usage_json: None,
    }));
    let (svc, _, repo, _) = make_service_with_resolver_and_acp_session_repo(
        Arc::new(FixedSkillResolver { names: vec![] }),
        acp_repo.clone(),
    );
    let conv = insert_conversation_with_type(&repo, "user_1", AgentType::Acp).await;

    svc.save_acp_runtime_mode("user_1", &conv.id, "full-access")
        .await
        .unwrap();

    let saves = acp_repo.runtime_state_saves();
    assert_eq!(saves.len(), 1);
    assert_eq!(saves[0].current_mode_id, Some(Some("full-access".to_owned())));
    let selections: serde_json::Value =
        serde_json::from_str(saves[0].config_selections_json.as_ref().unwrap().as_ref().unwrap()).unwrap();
    assert_eq!(selections["mode"], "full-access");
    assert_eq!(selections["model"], "gpt-5.3-codex");
    assert_eq!(selections["reasoning_effort"], "low");
}

#[tokio::test]
async fn save_acp_runtime_mode_rejects_wrong_user() {
    let acp_repo = Arc::new(StubAcpSessionRepo::with_runtime_state(PersistedSessionState {
        current_mode_id: Some("read-only".to_owned()),
        ..Default::default()
    }));
    let (svc, _, repo, _) = make_service_with_resolver_and_acp_session_repo(
        Arc::new(FixedSkillResolver { names: vec![] }),
        acp_repo.clone(),
    );
    let conv = insert_conversation_with_type(&repo, "user_1", AgentType::Acp).await;

    let err = svc
        .save_acp_runtime_mode("user_2", &conv.id, "full-access")
        .await
        .unwrap_err();

    assert!(matches!(err, ConversationError::NotFound { .. }));
    assert!(acp_repo.runtime_state_saves().is_empty());
}

#[tokio::test]
async fn run_agent_turn_applies_required_runtime_mode_after_stream_subscription() {
    let task_mgr = Arc::new(MockTaskManager::new());
    let (svc, broadcaster, _repo) = make_service_with_mock_task_manager(task_mgr.clone());
    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    broadcaster.take_events();

    let agent = Arc::new(
        MockAgent::new(&conv.id)
            .with_mode("yolo")
            .with_config_options(vec![AcpConfigOptionDto {
                id: "mode".to_owned(),
                name: Some("Mode".to_owned()),
                label: None,
                description: None,
                category: Some("mode".to_owned()),
                option_type: "select".to_owned(),
                current_value: Some("yolo".to_owned()),
                options: Vec::new(),
            }]),
    );
    task_mgr.insert_agent(&conv.id, AgentInstance::Mock(agent.clone()));

    let outcome = svc
        .run_agent_turn(ConversationAgentTurnRequest {
            user_id: "user_1".to_owned(),
            conversation_id: conv.id.clone(),
            content: "run scheduled task".to_owned(),
            files: Vec::new(),
            inject_skills: Vec::new(),
            required_runtime_mode: Some("yolo".to_owned()),
            persist_user_message: true,
            user_message_hidden: true,
            on_started: None,
        })
        .await
        .unwrap();

    assert_eq!(outcome.status, ConversationAgentTurnStatus::Completed);
    assert_eq!(
        agent.set_config_option_calls.lock().unwrap().as_slice(),
        &[("mode".to_owned(), "yolo".to_owned())]
    );
    let events = broadcaster.take_events();
    let config_event = events
        .iter()
        .find(|event| event.name == "message.stream" && event.data["type"] == "acp_config_option")
        .expect("runtime mode switch should broadcast config option snapshot");
    assert_eq!(config_event.data["conversation_id"], conv.id);
    assert_eq!(config_event.data["data"]["config_options"][0]["id"], "mode");
    assert_eq!(config_event.data["data"]["config_options"][0]["current_value"], "yolo");
}

#[tokio::test]
async fn set_config_option_evicts_task_when_acp_protocol_is_not_connected() {
    let task_mgr = Arc::new(MockTaskManager::new());
    let (svc, _broadcaster, _repo) = make_service_with_mock_task_manager(task_mgr.clone());
    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    let agent =
        Arc::new(MockAgent::new(&conv.id).with_set_config_option_error(AgentError::Acp(AcpError::NotConnected)));
    task_mgr.insert_agent(&conv.id, AgentInstance::Mock(agent));

    let err = svc
        .set_config_option(
            "user_1",
            &conv.id,
            "model",
            SetConfigOptionRequest {
                value: "gpt-5".to_owned(),
            },
        )
        .await
        .expect_err("set_config_option must surface ACP NotConnected");

    assert!(
        matches!(err, ConversationError::Acp(AcpError::NotConnected)),
        "expected ACP NotConnected, got {err:?}"
    );
    assert_eq!(
        task_mgr.kill_records(),
        vec![(conv.id.clone(), Some(AgentKillReason::AgentErrorRecovery))]
    );
}

#[tokio::test]
async fn command_ack_does_not_persist_assistant_preference_in_core_service() {
    let task_mgr = Arc::new(MockTaskManager::new());
    let (svc, _broadcaster, _repo) = make_service_with_mock_task_manager(task_mgr.clone());
    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    let agent = Arc::new(
        MockAgent::new(&conv.id).with_set_config_option_response(SetConfigOptionResponse {
            confirmation: ConfigOptionConfirmation::CommandAck,
            config_options: None,
        }),
    );
    task_mgr.insert_agent(&conv.id, AgentInstance::Mock(agent));

    let result = svc
        .set_config_option(
            "user_1",
            &conv.id,
            "model",
            SetConfigOptionRequest {
                value: "gpt-5.5".to_owned(),
            },
        )
        .await
        .unwrap();

    assert_eq!(result.confirmation, ConfigOptionConfirmation::CommandAck);
    let refreshed = svc.get("user_1", &conv.id).await.unwrap();
    assert!(refreshed.extra.get("current_model_id").is_none());
}

/// A deferred switch is still the user's choice and must be remembered.
///
/// `PendingNextTurn` says "the agent applies this from the next turn", not "the request
/// was refused" -- unlike `CommandAck`, which says nothing landed either way. Gating the
/// preference write-back on `Observed` alone would silently strip preference memory from
/// every codex conversation, since codex reports a mode switch as next-turn
/// unconditionally (its schema documents `permissions` as being "for subsequent turns").
#[tokio::test]
async fn pending_next_turn_still_persists_the_users_choice() {
    let task_mgr = Arc::new(MockTaskManager::new());
    let (svc, _broadcaster, repo, definition_repo, overlay_repo, preference_repo) =
        make_service_with_mock_task_manager_and_assistant_support(task_mgr.clone()).await;

    upsert_test_assistant_definition(
        &definition_repo,
        "asstdef_acp_auto",
        "assistant-acp-auto",
        "codex",
        "auto",
        "auto",
    )
    .await;
    overlay_repo
        .upsert(&UpsertAssistantOverlayParams {
            assistant_definition_id: "asstdef_acp_auto",
            enabled: true,
            sort_order: 0,
            agent_id_override: None,
            last_used_at: None,
        })
        .await
        .unwrap();

    let conv = create_assistant_backed_conversation(&svc, "user_1", Some("acp"), "codex", "assistant-acp-auto").await;
    let agent = Arc::new(
        MockAgent::new(&conv.id).with_set_config_option_response(SetConfigOptionResponse {
            confirmation: ConfigOptionConfirmation::PendingNextTurn,
            config_options: Some(vec![AcpConfigOptionDto {
                id: "mode".to_owned(),
                name: None,
                label: None,
                description: None,
                category: Some("mode".to_owned()),
                option_type: "select".to_owned(),
                // Deliberately still the OLD mode: a deferred switch reports what is in
                // force, not what was requested.
                current_value: Some("default".to_owned()),
                options: vec![],
            }]),
        }),
    );
    task_mgr.insert_agent(&conv.id, AgentInstance::Mock(agent));

    let result = svc
        .set_config_option(
            "user_1",
            &conv.id,
            "mode",
            SetConfigOptionRequest {
                value: "plan".to_owned(),
            },
        )
        .await
        .unwrap();
    assert_eq!(result.confirmation, ConfigOptionConfirmation::PendingNextTurn);

    let pref = preference_repo
        .get_for_user("user_1", "asstdef_acp_auto")
        .await
        .unwrap()
        .unwrap();
    assert_eq!(
        pref.last_permission_value.as_deref(),
        Some("plan"),
        "a deferred switch is still the user's settled choice and must be remembered"
    );
    let snapshot = repo.get_assistant_snapshot("user_1", &conv.id).await.unwrap().unwrap();
    assert_eq!(snapshot.resolved_permission_value.as_deref(), Some("plan"));
}

#[tokio::test]
async fn set_config_option_persists_runtime_model_into_assistant_preference_when_observed() {
    let task_mgr = Arc::new(MockTaskManager::new());
    let (svc, _broadcaster, repo, definition_repo, overlay_repo, preference_repo) =
        make_service_with_mock_task_manager_and_assistant_support(task_mgr.clone()).await;

    upsert_test_assistant_definition(
        &definition_repo,
        "asstdef_acp_auto",
        "assistant-acp-auto",
        "codex",
        "auto",
        "auto",
    )
    .await;
    overlay_repo
        .upsert(&UpsertAssistantOverlayParams {
            assistant_definition_id: "asstdef_acp_auto",
            enabled: true,
            sort_order: 0,
            agent_id_override: None,
            last_used_at: None,
        })
        .await
        .unwrap();
    preference_repo
        .upsert_for_user(
            "user_1",
            &UpsertAssistantPreferenceParams {
                assistant_definition_id: "asstdef_acp_auto",
                last_model_id: Some("legacy-acp-model"),
                last_permission_value: Some("legacy-mode"),
                last_thought_level_value: Some("legacy-low"),
                last_skill_ids: "[]",
                last_disabled_builtin_skill_ids: "[]",
                last_mcp_ids: "[]",
            },
        )
        .await
        .unwrap();

    let conv = create_assistant_backed_conversation(&svc, "user_1", Some("acp"), "codex", "assistant-acp-auto").await;

    let agent = Arc::new(MockAgent::new(&conv.id));
    task_mgr.insert_agent(&conv.id, AgentInstance::Mock(agent));

    let result = svc
        .set_config_option(
            "user_1",
            &conv.id,
            "model",
            SetConfigOptionRequest {
                value: "gpt-5.5".to_owned(),
            },
        )
        .await
        .unwrap();
    assert_eq!(result.confirmation, ConfigOptionConfirmation::Observed);

    let pref_after_model = preference_repo
        .get_for_user("user_1", "asstdef_acp_auto")
        .await
        .unwrap()
        .unwrap();
    assert_eq!(pref_after_model.last_model_id.as_deref(), Some("gpt-5.5"));
    assert_eq!(pref_after_model.last_permission_value.as_deref(), Some("legacy-mode"));
    let snapshot_after_model = repo.get_assistant_snapshot("user_1", &conv.id).await.unwrap().unwrap();
    assert_eq!(snapshot_after_model.resolved_model_id.as_deref(), Some("gpt-5.5"));

    svc.set_config_option(
        "user_1",
        &conv.id,
        "mode",
        SetConfigOptionRequest {
            value: "plan".to_owned(),
        },
    )
    .await
    .unwrap();
    let pref_after_mode = preference_repo
        .get_for_user("user_1", "asstdef_acp_auto")
        .await
        .unwrap()
        .unwrap();
    assert_eq!(pref_after_mode.last_model_id.as_deref(), Some("gpt-5.5"));
    assert_eq!(pref_after_mode.last_permission_value.as_deref(), Some("plan"));
    let snapshot_after_mode = repo.get_assistant_snapshot("user_1", &conv.id).await.unwrap().unwrap();
    assert_eq!(snapshot_after_mode.resolved_permission_value.as_deref(), Some("plan"));

    // Thought-level config options follow the same auto-default writeback
    // contract as model and permission defaults.
    svc.set_config_option(
        "user_1",
        &conv.id,
        "reasoning_effort",
        SetConfigOptionRequest {
            value: "high".to_owned(),
        },
    )
    .await
    .unwrap();
    let pref_after_thought = preference_repo
        .get_for_user("user_1", "asstdef_acp_auto")
        .await
        .unwrap()
        .unwrap();
    assert_eq!(pref_after_thought.last_model_id.as_deref(), Some("gpt-5.5"));
    assert_eq!(pref_after_thought.last_permission_value.as_deref(), Some("plan"));
    assert_eq!(pref_after_thought.last_thought_level_value.as_deref(), Some("high"));
    let snapshot_after_thought = repo.get_assistant_snapshot("user_1", &conv.id).await.unwrap().unwrap();
    assert_eq!(
        snapshot_after_thought.resolved_thought_level_value.as_deref(),
        Some("high")
    );
}

#[tokio::test]
async fn set_config_option_does_not_persist_preference_on_error() {
    let task_mgr = Arc::new(MockTaskManager::new());
    let (svc, _broadcaster, _repo, definition_repo, overlay_repo, preference_repo) =
        make_service_with_mock_task_manager_and_assistant_support(task_mgr.clone()).await;

    upsert_test_assistant_definition(
        &definition_repo,
        "asstdef_acp_auto",
        "assistant-acp-auto",
        "codex",
        "auto",
        "auto",
    )
    .await;
    overlay_repo
        .upsert(&UpsertAssistantOverlayParams {
            assistant_definition_id: "asstdef_acp_auto",
            enabled: true,
            sort_order: 0,
            agent_id_override: None,
            last_used_at: None,
        })
        .await
        .unwrap();
    preference_repo
        .upsert_for_user(
            "user_1",
            &UpsertAssistantPreferenceParams {
                assistant_definition_id: "asstdef_acp_auto",
                last_model_id: Some("original-model"),
                last_permission_value: Some("original-mode"),
                last_thought_level_value: Some("original-low"),
                last_skill_ids: "[]",
                last_disabled_builtin_skill_ids: "[]",
                last_mcp_ids: "[]",
            },
        )
        .await
        .unwrap();

    let conv = create_assistant_backed_conversation(&svc, "user_1", Some("acp"), "codex", "assistant-acp-auto").await;

    // Agent reports a session-change conflict (mirrors the legacy ACK-then-
    // session-changed race): the service must return the error and leave the
    // persisted preference untouched.
    let agent = Arc::new(
        MockAgent::new(&conv.id).with_set_config_option_error(AgentError::conflict(
            "Active ACP session changed while applying config option",
        )),
    );
    task_mgr.insert_agent(&conv.id, AgentInstance::Mock(agent));

    let result = svc
        .set_config_option(
            "user_1",
            &conv.id,
            "model",
            SetConfigOptionRequest {
                value: "gpt-5.5".to_owned(),
            },
        )
        .await;
    assert!(result.is_err(), "conflict from agent must surface as error");

    let pref_after = preference_repo
        .get_for_user("user_1", "asstdef_acp_auto")
        .await
        .unwrap()
        .unwrap();
    assert_eq!(
        pref_after.last_model_id.as_deref(),
        Some("original-model"),
        "preference must not be written when set_config_option errors"
    );
}

#[tokio::test]
async fn set_config_option_skips_preference_write_back_when_default_mode_is_fixed() {
    let task_mgr = Arc::new(MockTaskManager::new());
    let (svc, _broadcaster, repo, definition_repo, overlay_repo, preference_repo) =
        make_service_with_mock_task_manager_and_assistant_support(task_mgr.clone()).await;

    upsert_test_assistant_definition_with_thought_level(
        &definition_repo,
        "asstdef_acp_fixed",
        "assistant-acp-fixed",
        "codex",
        "fixed",
        "fixed",
        "fixed",
    )
    .await;
    overlay_repo
        .upsert(&UpsertAssistantOverlayParams {
            assistant_definition_id: "asstdef_acp_fixed",
            enabled: true,
            sort_order: 0,
            agent_id_override: None,
            last_used_at: None,
        })
        .await
        .unwrap();
    preference_repo
        .upsert_for_user(
            "user_1",
            &UpsertAssistantPreferenceParams {
                assistant_definition_id: "asstdef_acp_fixed",
                last_model_id: Some("legacy-fixed-model"),
                last_permission_value: Some("legacy-fixed-mode"),
                last_thought_level_value: None,
                last_skill_ids: "[]",
                last_disabled_builtin_skill_ids: "[]",
                last_mcp_ids: "[]",
            },
        )
        .await
        .unwrap();

    let conv = create_assistant_backed_conversation(&svc, "user_1", Some("acp"), "codex", "assistant-acp-fixed").await;
    let agent = Arc::new(MockAgent::new(&conv.id));
    task_mgr.insert_agent(&conv.id, AgentInstance::Mock(agent));

    svc.set_config_option(
        "user_1",
        &conv.id,
        "model",
        SetConfigOptionRequest {
            value: "transient-model".to_owned(),
        },
    )
    .await
    .unwrap();
    svc.set_config_option(
        "user_1",
        &conv.id,
        "mode",
        SetConfigOptionRequest {
            value: "transient-mode".to_owned(),
        },
    )
    .await
    .unwrap();
    svc.set_config_option(
        "user_1",
        &conv.id,
        "reasoning_effort",
        SetConfigOptionRequest {
            value: "transient-high".to_owned(),
        },
    )
    .await
    .unwrap();

    let pref = preference_repo
        .get_for_user("user_1", "asstdef_acp_fixed")
        .await
        .unwrap()
        .unwrap();
    assert_eq!(pref.last_model_id.as_deref(), Some("legacy-fixed-model"));
    assert_eq!(pref.last_permission_value.as_deref(), Some("legacy-fixed-mode"));
    assert_eq!(pref.last_thought_level_value.as_deref(), None);
    // The snapshot still tracks the runtime override so the active session reflects it,
    // even though the persisted assistant preference must not change for fixed defaults.
    let snapshot = repo.get_assistant_snapshot("user_1", &conv.id).await.unwrap().unwrap();
    assert_eq!(snapshot.resolved_model_id.as_deref(), Some("transient-model"));
    assert_eq!(snapshot.resolved_permission_value.as_deref(), Some("transient-mode"));
    assert_eq!(snapshot.resolved_thought_level_value.as_deref(), Some("transient-high"));
}

#[tokio::test]
async fn set_config_option_command_ack_does_not_persist_assistant_preference() {
    let task_mgr = Arc::new(MockTaskManager::new());
    let (svc, _broadcaster, repo, definition_repo, overlay_repo, preference_repo) =
        make_service_with_mock_task_manager_and_assistant_support(task_mgr.clone()).await;

    upsert_test_assistant_definition(
        &definition_repo,
        "asstdef_acp_ack",
        "assistant-acp-ack",
        "codex",
        "auto",
        "auto",
    )
    .await;
    overlay_repo
        .upsert(&UpsertAssistantOverlayParams {
            assistant_definition_id: "asstdef_acp_ack",
            enabled: true,
            sort_order: 0,
            agent_id_override: None,
            last_used_at: None,
        })
        .await
        .unwrap();
    preference_repo
        .upsert_for_user(
            "user_1",
            &UpsertAssistantPreferenceParams {
                assistant_definition_id: "asstdef_acp_ack",
                last_model_id: Some("legacy-ack-model"),
                last_permission_value: Some("legacy-ack-mode"),
                last_thought_level_value: Some("legacy-ack-thought"),
                last_skill_ids: "[]",
                last_disabled_builtin_skill_ids: "[]",
                last_mcp_ids: "[]",
            },
        )
        .await
        .unwrap();

    let conv = create_assistant_backed_conversation(&svc, "user_1", Some("acp"), "codex", "assistant-acp-ack").await;
    let agent = Arc::new(
        MockAgent::new(&conv.id).with_set_config_option_response(SetConfigOptionResponse {
            confirmation: ConfigOptionConfirmation::CommandAck,
            config_options: None,
        }),
    );
    task_mgr.insert_agent(&conv.id, AgentInstance::Mock(agent));

    svc.set_config_option(
        "user_1",
        &conv.id,
        "model",
        SetConfigOptionRequest {
            value: "ack-only-model".to_owned(),
        },
    )
    .await
    .unwrap();

    let pref = preference_repo
        .get_for_user("user_1", "asstdef_acp_ack")
        .await
        .unwrap()
        .unwrap();
    assert_eq!(pref.last_model_id.as_deref(), Some("legacy-ack-model"));
    assert_eq!(pref.last_permission_value.as_deref(), Some("legacy-ack-mode"));
    let snapshot = repo.get_assistant_snapshot("user_1", &conv.id).await.unwrap().unwrap();
    assert_eq!(snapshot.resolved_model_id.as_deref(), Some("legacy-ack-model"));
}

#[tokio::test]
async fn update_qianjirs_model_updates_assistant_preference_only_when_snapshot_model_mode_is_auto() {
    let task_mgr = Arc::new(MockTaskManager::new());
    let (svc, _broadcaster, repo, definition_repo, overlay_repo, preference_repo) =
        make_service_with_mock_task_manager_and_assistant_support(task_mgr.clone()).await;

    upsert_test_assistant_definition(
        &definition_repo,
        "asstdef_qianjirs_auto",
        "assistant-qianjirs-auto",
        "qianjirs",
        "auto",
        "auto",
    )
    .await;
    overlay_repo
        .upsert(&UpsertAssistantOverlayParams {
            assistant_definition_id: "asstdef_qianjirs_auto",
            enabled: true,
            sort_order: 0,
            agent_id_override: None,
            last_used_at: None,
        })
        .await
        .unwrap();
    preference_repo
        .upsert_for_user(
            "user_1",
            &UpsertAssistantPreferenceParams {
                assistant_definition_id: "asstdef_qianjirs_auto",
                last_model_id: Some("legacy-qianjirs-model"),
                last_permission_value: None,
                last_thought_level_value: None,
                last_skill_ids: "[]",
                last_disabled_builtin_skill_ids: "[]",
                last_mcp_ids: "[]",
            },
        )
        .await
        .unwrap();

    let auto_conv =
        create_assistant_backed_conversation(&svc, "user_1", Some("qianjirs"), "qianjirs", "assistant-qianjirs-auto")
            .await;
    let updated = svc
        .update(
            "user_1",
            &auto_conv.id,
            UpdateConversationRequest {
                model: Some(ProviderWithModel {
                    provider_id: "provider-2".to_owned(),
                    model: "model-z".to_owned(),
                    use_model: Some("model-z".to_owned()),
                }),
                name: None,
                name_source: None,
                extra: None,
                pinned: None,
            },
            &(task_mgr.clone() as Arc<dyn IWorkerTaskManager>),
        )
        .await
        .unwrap();

    assert_eq!(
        updated.model.as_ref().and_then(|model| model.use_model.as_deref()),
        Some("model-z")
    );
    let auto_pref = preference_repo
        .get_for_user("user_1", "asstdef_qianjirs_auto")
        .await
        .unwrap()
        .unwrap();
    assert_eq!(auto_pref.last_model_id.as_deref(), Some("model-z"));
    let auto_snapshot = repo
        .get_assistant_snapshot("user_1", &auto_conv.id)
        .await
        .unwrap()
        .unwrap();
    assert_eq!(auto_snapshot.resolved_model_id.as_deref(), Some("model-z"));

    upsert_test_assistant_definition(
        &definition_repo,
        "asstdef_qianjirs_fixed",
        "assistant-qianjirs-fixed",
        "qianjirs",
        "fixed",
        "auto",
    )
    .await;
    overlay_repo
        .upsert(&UpsertAssistantOverlayParams {
            assistant_definition_id: "asstdef_qianjirs_fixed",
            enabled: true,
            sort_order: 0,
            agent_id_override: None,
            last_used_at: None,
        })
        .await
        .unwrap();
    preference_repo
        .upsert_for_user(
            "user_1",
            &UpsertAssistantPreferenceParams {
                assistant_definition_id: "asstdef_qianjirs_fixed",
                last_model_id: Some("legacy-qianjirs-fixed-model"),
                last_permission_value: None,
                last_thought_level_value: None,
                last_skill_ids: "[]",
                last_disabled_builtin_skill_ids: "[]",
                last_mcp_ids: "[]",
            },
        )
        .await
        .unwrap();

    let fixed_conv =
        create_assistant_backed_conversation(&svc, "user_1", Some("qianjirs"), "qianjirs", "assistant-qianjirs-fixed")
            .await;
    let _ = svc
        .update(
            "user_1",
            &fixed_conv.id,
            UpdateConversationRequest {
                model: Some(ProviderWithModel {
                    provider_id: "provider-3".to_owned(),
                    model: "model-y".to_owned(),
                    use_model: Some("model-y".to_owned()),
                }),
                name: None,
                name_source: None,
                extra: None,
                pinned: None,
            },
            &(task_mgr as Arc<dyn IWorkerTaskManager>),
        )
        .await
        .unwrap();

    let fixed_pref = preference_repo
        .get_for_user("user_1", "asstdef_qianjirs_fixed")
        .await
        .unwrap()
        .unwrap();
    assert_eq!(fixed_pref.last_model_id.as_deref(), Some("legacy-qianjirs-fixed-model"));
    let fixed_snapshot = repo
        .get_assistant_snapshot("user_1", &fixed_conv.id)
        .await
        .unwrap()
        .unwrap();
    assert_eq!(fixed_snapshot.resolved_model_id.as_deref(), Some("model-y"));

    // Ensure the update path used the repository row, not a no-op.
    let updated_row = repo.get("user_1", &fixed_conv.id).await.unwrap().unwrap();
    assert!(
        updated_row
            .model
            .as_deref()
            .is_some_and(|model| model.contains("model-y"))
    );
}

#[tokio::test]
async fn send_message_missing_workspace_persists_message_and_failure_tip() {
    let (svc, broadcaster, repo, _task_mgr) = make_service();
    let task_mgr: Arc<dyn IWorkerTaskManager> = Arc::new(MockTaskManager::new());

    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    broadcaster.take_events();
    let legacy_workspace = format!("/tmp/does-not-exist-{}", qianji_common::generate_short_id());
    repo.update(
        "user_1",
        &conv.id,
        &ConversationRowUpdate {
            extra: Some(json!({ "workspace": legacy_workspace }).to_string()),
            ..Default::default()
        },
    )
    .await
    .unwrap();

    let response = svc
        .send_message("user_1", &conv.id, make_send_req(), &task_mgr)
        .await
        .unwrap();
    assert!(
        !response.msg_id.is_empty(),
        "msg_id must still be returned when runtime workspace validation fails"
    );

    let messages = tokio::time::timeout(Duration::from_secs(1), async {
        loop {
            let messages = repo
                .list_messages_page(
                    "user_1",
                    &conv.id,
                    &MessagePageParams {
                        limit: 20,
                        direction: MessagePageDirection::InitialLatest,
                    },
                )
                .await
                .unwrap()
                .items;
            if messages.iter().any(|message| message.r#type == "tips")
                && messages.iter().any(|message| message.r#type == "text")
            {
                return messages;
            }
            tokio::time::sleep(Duration::from_millis(10)).await;
        }
    })
    .await
    .expect("missing workspace failure should persist a user message and error tip");

    let user_message = messages
        .iter()
        .find(|message| message.r#type == "text")
        .expect("missing workspace failure should persist the user message");
    assert_eq!(user_message.msg_id.as_deref(), Some(response.msg_id.as_str()));

    let error_tip = messages
        .iter()
        .find(|message| message.r#type == "tips")
        .expect("missing workspace failure should persist an error tips message");
    let content: serde_json::Value = serde_json::from_str(&error_tip.content).unwrap();
    assert_eq!(content["code"], "WORKSPACE_PATH_RUNTIME_UNAVAILABLE");
    assert_eq!(content["details"]["workspace_path"], legacy_workspace);
    assert_eq!(content["error"]["code"], "WORKSPACE_PATH_RUNTIME_UNAVAILABLE");
    assert_eq!(content["error"]["workspacePath"], legacy_workspace);

    let events = broadcaster.take_events();
    let error_tip_event = events
        .iter()
        .find(|event| event.name == "message.stream" && event.data["type"] == "tips")
        .expect("missing workspace failure should broadcast the error tips message");
    assert_eq!(error_tip_event.data["status"], "error");
    assert_eq!(
        error_tip_event.data["data"]["code"],
        "WORKSPACE_PATH_RUNTIME_UNAVAILABLE"
    );
    assert_eq!(error_tip_event.data["turn_id"], response.turn_id);

    let turn_event = events
        .iter()
        .find(|event| event.name == "turn.completed")
        .expect("missing workspace failure should complete the turn");
    assert_eq!(turn_event.data["turn_id"], response.turn_id);
    assert_eq!(turn_event.data["runtime"]["is_processing"], false);
    assert_eq!(turn_event.data["runtime"]["can_send_message"], true);
}

#[tokio::test]
async fn send_message_broadcasts_user_created_event() {
    let (svc, broadcaster, _repo, _task_mgr) = make_service();
    let task_mgr: Arc<dyn IWorkerTaskManager> = Arc::new(MockTaskManager::new());

    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    // Clear events from create
    broadcaster.take_events();

    let response = svc
        .send_message("user_1", &conv.id, make_send_req(), &task_mgr)
        .await
        .unwrap();

    let events = broadcaster.take_events();
    let user_created = events
        .iter()
        .find(|e| e.name == "message.userCreated")
        .expect("should broadcast message.userCreated event");

    assert_eq!(user_created.data["conversation_id"], conv.id);
    assert_eq!(user_created.data["msg_id"], response.msg_id);
    assert_eq!(user_created.data["content"], "Hello");
    assert_eq!(user_created.data["position"], "right");
}

#[tokio::test]
async fn send_message_returns_before_cold_agent_build_completes() {
    let (svc, _broadcaster, repo, _task_mgr) = make_service();
    let slow_task_mgr = Arc::new(SlowBuildTaskManager::new(Duration::from_millis(500)));
    let task_mgr: Arc<dyn IWorkerTaskManager> = slow_task_mgr.clone();

    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    let response = tokio::time::timeout(
        Duration::from_millis(50),
        svc.send_message("user_1", &conv.id, make_send_req(), &task_mgr),
    )
    .await
    .expect("send_message should return before cold agent build finishes")
    .unwrap();

    assert!(!response.msg_id.is_empty(), "msg_id must be non-empty");
    assert!(response.turn_id.starts_with("turn_"));
    assert!(
        !slow_task_mgr.was_built(),
        "cold agent build should continue in the background after send_message returns"
    );

    let updated = repo.get("user_1", &conv.id).await.unwrap().unwrap();
    assert_ne!(updated.status.as_deref(), Some("running"));
    assert!(
        svc.runtime_state().is_claimed(&conv.id),
        "runtime claim must cover the cold agent build window"
    );
}

#[tokio::test]
async fn send_message_persists_hidden_user_message_when_requested() {
    let (svc, _broadcaster, repo, _task_mgr) = make_service();
    let task_mgr: Arc<dyn IWorkerTaskManager> = Arc::new(MockTaskManager::new());

    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    let req: SendMessageRequest = serde_json::from_value(json!({
        "content": "Hidden cron prompt",
        "hidden": true
    }))
    .unwrap();

    svc.send_message("user_1", &conv.id, req, &task_mgr).await.unwrap();

    let messages = repo
        .list_messages_page(
            "user_1",
            &conv.id,
            &MessagePageParams {
                limit: 20,
                direction: MessagePageDirection::InitialLatest,
            },
        )
        .await
        .unwrap()
        .items;
    // The user message is the only hidden text row written by the service.
    let user_message = messages
        .iter()
        .find(|message| message.r#type == "text" && message.position.as_deref() == Some("right"))
        .expect("user message should be persisted");
    assert!(user_message.hidden);
    // msg_id is server-generated and must be non-empty for frontend routing.
    assert!(user_message.msg_id.as_deref().is_some_and(|s| !s.is_empty()));
}

#[tokio::test]
async fn send_message_persists_error_tip_when_agent_build_fails() {
    let (svc, broadcaster, repo, _task_mgr) = make_service();
    let task_mgr: Arc<dyn IWorkerTaskManager> =
        Arc::new(FailingBuildTaskManager::new("ACP init failed: config file is invalid"));

    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    broadcaster.take_events();

    let response = svc
        .send_message("user_1", &conv.id, make_send_req(), &task_mgr)
        .await
        .unwrap();

    assert!(!response.msg_id.is_empty(), "msg_id must be non-empty");
    assert!(response.turn_id.starts_with("turn_"));

    let messages = tokio::time::timeout(Duration::from_secs(1), async {
        loop {
            let messages = repo
                .list_messages_page(
                    "user_1",
                    &conv.id,
                    &MessagePageParams {
                        limit: 20,
                        direction: MessagePageDirection::InitialLatest,
                    },
                )
                .await
                .unwrap()
                .items;
            if messages.iter().any(|message| message.r#type == "tips") {
                return messages;
            }
            tokio::time::sleep(Duration::from_millis(10)).await;
        }
    })
    .await
    .expect("agent build failure should persist an error tip");
    assert_eq!(messages.len(), 2, "user message and error tip should be persisted");

    let error_tip = messages
        .iter()
        .find(|message| message.r#type == "tips")
        .expect("agent build failure should persist an error tips message");
    assert_eq!(error_tip.status.as_deref(), Some("error"));
    assert_eq!(error_tip.position.as_deref(), Some("center"));

    let content: serde_json::Value = serde_json::from_str(&error_tip.content).unwrap();
    assert_eq!(content["type"], "error");
    assert_eq!(content["source"], "send_failed");
    assert_eq!(content["code"], "BAD_GATEWAY");
    assert_eq!(content["error"]["code"], "UNKNOWN_UPSTREAM_ERROR");
    assert_eq!(content["error"]["ownership"], "unknown_upstream");
    assert_eq!(content["error"]["retryable"], true);
    assert_eq!(content["error"]["feedback_recommended"], false);
    assert_eq!(content["error"]["detail"], "ACP init failed: config file is invalid");
    assert_eq!(
        content["content"],
        "The upstream Agent failed while handling the request"
    );

    let updated = repo.get("user_1", &conv.id).await.unwrap().unwrap();
    assert_eq!(updated.status.as_deref(), Some("finished"));
    assert!(
        !svc.runtime_state().is_claimed(&conv.id),
        "runtime claim must be released after failed turn"
    );

    let events = broadcaster.take_events();
    let error_tip_event = events
        .iter()
        .find(|event| event.name == "message.stream" && event.data["type"] == "tips")
        .expect("agent build failure should broadcast the error tips message");
    assert_eq!(error_tip_event.data["status"], "error");
    assert_eq!(error_tip_event.data["data"]["code"], "BAD_GATEWAY");
    assert_eq!(error_tip_event.data["turn_id"], response.turn_id);
}

#[tokio::test]
async fn run_agent_turn_returns_error_message_when_agent_build_fails() {
    let task_mgr: Arc<dyn IWorkerTaskManager> =
        Arc::new(FailingBuildTaskManager::new("ACP init failed: config file is invalid"));
    let repo = Arc::new(MockRepo::new());
    let broadcaster = Arc::new(MockBroadcaster::new());
    let service = ConversationService::new(
        std::env::temp_dir(),
        broadcaster,
        Arc::new(FixedSkillResolver { names: vec![] }),
        task_mgr,
        repo,
        Arc::new(StubAgentMetadataRepo),
        Arc::new(StubAcpSessionRepo::default()),
    );

    let conv = service.create("user_1", make_create_req()).await.unwrap();
    let outcome = service
        .run_agent_turn(ConversationAgentTurnRequest {
            user_id: "user_1".into(),
            conversation_id: conv.id,
            content: "run scheduled task".into(),
            files: Vec::new(),
            inject_skills: Vec::new(),
            required_runtime_mode: None,
            persist_user_message: true,
            user_message_hidden: true,
            on_started: None,
        })
        .await
        .unwrap();

    assert_eq!(outcome.status, ConversationAgentTurnStatus::Failed);
    assert_eq!(
        outcome.error_message.as_deref(),
        Some("ACP init failed: config file is invalid")
    );
}

#[tokio::test]
async fn latest_conversation_error_message_prefers_error_detail() {
    let (svc, _broadcaster, repo, _task_mgr) = make_service();
    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    repo.insert_message(
        "user_1",
        &MessageRow {
            id: "msg_error".into(),
            conversation_id: conv.id.clone(),
            msg_id: None,
            r#type: "tips".into(),
            content: serde_json::json!({
                "content": "Current agent failed",
                "type": "error",
                "details": {
                    "detail": "Cannot resume Claude session with Codex assistant"
                },
                "error": {
                    "message": "Current agent failed",
                    "detail": "Codex cannot resume a conversation created by Claude"
                }
            })
            .to_string(),
            position: Some("center".into()),
            status: Some("error".into()),
            hidden: false,
            created_at: 10,
            backend_turn_id: None,
        },
    )
    .await
    .unwrap();

    let message = svc.latest_conversation_error_message("user_1", &conv.id).await.unwrap();

    assert_eq!(
        message.as_deref(),
        Some("Codex cannot resume a conversation created by Claude")
    );
}

#[tokio::test]
async fn send_message_persists_openclaw_gateway_unreachable_tip_when_turn_build_fails() {
    let (svc, broadcaster, repo, _default_task_mgr) = make_service();
    let task_mgr: Arc<dyn IWorkerTaskManager> = Arc::new(AgentErrorFailingBuildTaskManager::new(AgentError::from(
        AcpError::StartupCrash {
            exit_code: Some(1),
            signal: None,
            stderr: "ACP bridge failed: connect ECONNREFUSED 127.0.0.1:18789".into(),
        },
    )));

    let conv = svc
        .create("user_1", make_create_req_with_backend("openclaw"))
        .await
        .unwrap();
    broadcaster.take_events();

    let response = svc
        .send_message(
            "user_1",
            &conv.id,
            SendMessageRequest {
                content: "hello".into(),
                hidden: false,
                files: vec![],
                sessions: vec![],
                inject_skills: vec![],
            },
            &task_mgr,
        )
        .await
        .unwrap();

    wait_for_turn_released(&svc, &conv.id).await;

    let messages = repo
        .list_messages_page(
            "user_1",
            &conv.id,
            &MessagePageParams {
                limit: 20,
                direction: MessagePageDirection::InitialLatest,
            },
        )
        .await
        .unwrap()
        .items;
    let tip = messages
        .iter()
        .find(|row| row.r#type == "tips" && row.status.as_deref() == Some("error"))
        .expect("send failure tip should be persisted");
    let content: serde_json::Value = serde_json::from_str(&tip.content).unwrap();

    assert_eq!(content["source"], "send_failed");
    assert_eq!(content["error"]["code"], "USER_AGENT_OPENCLAW_GATEWAY_UNREACHABLE");
    assert_eq!(content["error"]["ownership"], "user_agent");
    assert!(
        content["error"]["detail"]
            .as_str()
            .unwrap()
            .contains("openclaw gateway start")
    );

    let events = broadcaster.take_events();
    let error_tip_event = events
        .iter()
        .find(|event| event.name == "message.stream" && event.data["type"] == "tips")
        .expect("OpenClaw Gateway build failure should broadcast the error tips message");
    assert_eq!(error_tip_event.data["status"], "error");
    assert_eq!(
        error_tip_event.data["data"]["code"],
        "USER_AGENT_OPENCLAW_GATEWAY_UNREACHABLE"
    );
    assert_eq!(
        error_tip_event.data["data"]["error"]["code"],
        "USER_AGENT_OPENCLAW_GATEWAY_UNREACHABLE"
    );
    assert_eq!(error_tip_event.data["turn_id"], response.turn_id);
}

#[tokio::test]
async fn send_message_empty_content_returns_bad_request() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let task_mgr: Arc<dyn IWorkerTaskManager> = Arc::new(MockTaskManager::new());

    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    let req: SendMessageRequest = serde_json::from_value(json!({
        "content": ""
    }))
    .unwrap();

    let err = svc.send_message("user_1", &conv.id, req, &task_mgr).await.unwrap_err();
    assert!(matches!(err, ConversationError::BadRequest { .. }));
}

#[tokio::test]
async fn send_message_whitespace_content_returns_bad_request() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let task_mgr: Arc<dyn IWorkerTaskManager> = Arc::new(MockTaskManager::new());

    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    let req: SendMessageRequest = serde_json::from_value(json!({
        "content": "   "
    }))
    .unwrap();

    let err = svc.send_message("user_1", &conv.id, req, &task_mgr).await.unwrap_err();
    assert!(matches!(err, ConversationError::BadRequest { .. }));
}

#[tokio::test]
async fn send_message_conversation_not_found() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let task_mgr: Arc<dyn IWorkerTaskManager> = Arc::new(MockTaskManager::new());

    let err = svc
        .send_message("user_1", "no-such-id", make_send_req(), &task_mgr)
        .await
        .unwrap_err();
    assert!(matches!(err, ConversationError::NotFound { .. }));
}

#[tokio::test]
async fn send_message_wrong_user_returns_not_found() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let task_mgr: Arc<dyn IWorkerTaskManager> = Arc::new(MockTaskManager::new());

    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    let err = svc
        .send_message("user_2", &conv.id, make_send_req(), &task_mgr)
        .await
        .unwrap_err();
    assert!(matches!(err, ConversationError::NotFound { .. }));
}

#[tokio::test]
async fn send_message_allows_stale_db_running_without_runtime_claim() {
    let (svc, _broadcaster, repo, _task_mgr) = make_service();
    let task_mgr: Arc<dyn IWorkerTaskManager> = Arc::new(MockTaskManager::new());

    let conv = svc.create("user_1", make_create_req()).await.unwrap();

    // Manually set status to running
    let update = ConversationRowUpdate {
        status: Some("running".into()),
        ..Default::default()
    };
    repo.update("user_1", &conv.id, &update).await.unwrap();

    let result = svc.send_message("user_1", &conv.id, make_send_req(), &task_mgr).await;
    assert!(result.is_ok(), "stale DB running must not block sending");
}

#[tokio::test]
async fn send_message_rejects_active_runtime_claim() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let task_mgr: Arc<dyn IWorkerTaskManager> = Arc::new(MockTaskManager::new());

    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    let _claim = svc
        .runtime_state()
        .try_claim_turn(&conv.id, "turn-test")
        .expect("test claim should be created");

    let err = svc
        .send_message("user_1", &conv.id, make_send_req(), &task_mgr)
        .await
        .unwrap_err();
    assert!(matches!(err, ConversationError::Busy { .. }));
}

#[tokio::test]
async fn send_message_rejects_when_runtime_is_shutting_down() {
    let (svc, _broadcaster, repo, _task_mgr) = make_service();
    let task_mgr: Arc<dyn IWorkerTaskManager> = Arc::new(MockTaskManager::new());

    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    svc.runtime_state().mark_shutting_down();

    let err = svc
        .send_message("user_1", &conv.id, make_send_req(), &task_mgr)
        .await
        .unwrap_err();
    assert!(matches!(err, ConversationError::Busy { .. }));

    let messages = repo
        .list_messages_page(
            "user_1",
            &conv.id,
            &MessagePageParams {
                limit: 20,
                direction: MessagePageDirection::InitialLatest,
            },
        )
        .await
        .unwrap()
        .items;
    assert!(
        messages.is_empty(),
        "shutdown rejection must not persist a user message"
    );
}

#[tokio::test]
async fn send_message_build_failure_while_deleting_skips_failure_tip_and_completion() {
    let (svc, broadcaster, repo, _task_mgr) = make_service();
    let task_mgr: Arc<dyn IWorkerTaskManager> = Arc::new(DelayedFailingBuildTaskManager::new(
        Duration::from_millis(100),
        "delayed build failure",
    ));

    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    broadcaster.take_events();

    let response = svc
        .send_message("user_1", &conv.id, make_send_req(), &task_mgr)
        .await
        .unwrap();
    assert!(!response.msg_id.is_empty());

    svc.runtime_state().mark_deleting(&conv.id);
    wait_for_turn_released(&svc, &conv.id).await;

    let messages = repo
        .list_messages_page(
            "user_1",
            &conv.id,
            &MessagePageParams {
                limit: 20,
                direction: MessagePageDirection::InitialLatest,
            },
        )
        .await
        .unwrap()
        .items;
    assert!(
        messages.iter().all(|message| message.r#type != "tips"),
        "deleting conversation must skip build-failure tips"
    );

    let events = broadcaster.take_events();
    assert!(
        events.iter().all(|event| event.name != "turn.completed"),
        "deleting conversation must not publish turn.completed"
    );
}

#[tokio::test]
async fn send_message_persists_factory_resolved_workspace() {
    // Conversation created with no workspace → create() auto-assigns one.
    // Factory resolves a *different* temp dir (simulating legacy-conv fallback).
    // After send_message, conversation.extra.workspace must match what the
    // agent reports.
    let (svc, _broadcaster, repo, _default_task_mgr) = make_service();
    let auto_workspace = "/tmp/factory-resolved";
    let task_mgr: Arc<dyn IWorkerTaskManager> = Arc::new(MockTaskManagerWithWorkspace::new(auto_workspace));

    // Create a conversation with an empty workspace to simulate legacy case.
    let req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "acp",
        "extra": {}
    }))
    .unwrap();
    let conv = svc.create("user_1", req).await.unwrap();

    // Inject an empty workspace directly into the repo to mimic legacy state.
    let empty_ws_update = ConversationRowUpdate {
        extra: Some(r#"{"workspace":""}"#.to_owned()),
        ..Default::default()
    };
    repo.update("user_1", &conv.id, &empty_ws_update).await.unwrap();

    svc.send_message("user_1", &conv.id, make_send_req(), &task_mgr)
        .await
        .unwrap();

    // Verify the workspace was written back.
    let updated = tokio::time::timeout(Duration::from_secs(1), async {
        loop {
            let updated = svc.get("user_1", &conv.id).await.unwrap();
            if updated.extra["workspace"] == auto_workspace {
                return updated;
            }
            tokio::time::sleep(Duration::from_millis(10)).await;
        }
    })
    .await
    .expect("factory-resolved workspace should be persisted in the background");
    assert_eq!(updated.extra["workspace"], auto_workspace);
}

#[tokio::test]
async fn startup_recovery_closes_stale_runtime_messages_without_failure_tip() {
    let (svc, _broadcaster, repo, _task_mgr) = make_service();
    let conv = svc.create("user_1", make_create_req()).await.unwrap();

    repo.insert_message(
        "user_1",
        &MessageRow {
            id: "visible-stale".into(),
            conversation_id: conv.id.clone(),
            msg_id: Some("visible-stale".into()),
            r#type: "text".into(),
            content: json!({ "content": "partial output" }).to_string(),
            position: Some("left".into()),
            status: Some("work".into()),
            hidden: false,
            created_at: 1,
            backend_turn_id: None,
        },
    )
    .await
    .unwrap();
    repo.insert_message(
        "user_1",
        &MessageRow {
            id: "empty-stale".into(),
            conversation_id: conv.id.clone(),
            msg_id: Some("empty-stale".into()),
            r#type: "thinking".into(),
            content: json!({ "content": "" }).to_string(),
            position: Some("left".into()),
            status: Some("pending".into()),
            hidden: false,
            created_at: 2,
            backend_turn_id: None,
        },
    )
    .await
    .unwrap();

    svc.recover_stale_runtime_state_on_startup().await;

    let messages = repo
        .list_messages_page(
            "user_1",
            &conv.id,
            &MessagePageParams {
                limit: 20,
                direction: MessagePageDirection::InitialLatest,
            },
        )
        .await
        .unwrap()
        .items;
    let visible = messages.iter().find(|message| message.id == "visible-stale").unwrap();
    assert_eq!(visible.status.as_deref(), Some("finish"));
    assert!(!visible.hidden);

    let empty = messages.iter().find(|message| message.id == "empty-stale").unwrap();
    assert_eq!(empty.status.as_deref(), Some("finish"));
    assert!(empty.hidden);

    assert!(
        messages.iter().all(|message| message.r#type != "tips"),
        "startup recovery must not write failure tips"
    );
}

#[tokio::test]
async fn send_message_keeps_acp_task_after_normal_finish() {
    let (svc, _broadcaster, _repo, _default_task_mgr) = make_service();
    let task_mgr = Arc::new(MockTaskManager::new());
    let conv = svc.create("user_1", make_create_req()).await.unwrap();

    let scripted_agent = Arc::new(ScriptedAgent::new(
        &conv.id,
        vec![vec![AgentStreamEvent::Finish(FinishEventData::default())]],
    ));
    task_mgr.insert_agent(&conv.id, AgentInstance::Mock(scripted_agent));

    let task_mgr_dyn: Arc<dyn IWorkerTaskManager> = task_mgr.clone();
    svc.send_message("user_1", &conv.id, make_send_req(), &task_mgr_dyn)
        .await
        .unwrap();
    wait_for_turn_released(&svc, &conv.id).await;

    assert_eq!(task_mgr.kill_count(), 0);
    assert_eq!(task_mgr.active_count(), 1);
}

#[tokio::test]
async fn send_message_does_not_evict_non_acp_task_after_terminal_error() {
    let (svc, _broadcaster, _repo, _default_task_mgr) = make_service();
    let task_mgr = Arc::new(MockTaskManager::new());
    let conv = svc.create("user_1", make_create_req()).await.unwrap();

    let scripted_agent = Arc::new(
        ScriptedAgent::new(
            &conv.id,
            vec![vec![AgentStreamEvent::Error(ErrorEventData::legacy(
                "qianjirs terminal error",
                Some(AgentErrorCode::UnknownUpstreamError),
            ))]],
        )
        .with_agent_type(AgentType::Qianjirs),
    );
    task_mgr.insert_agent(&conv.id, AgentInstance::Mock(scripted_agent));

    let task_mgr_dyn: Arc<dyn IWorkerTaskManager> = task_mgr.clone();
    svc.send_message("user_1", &conv.id, make_send_req(), &task_mgr_dyn)
        .await
        .unwrap();
    wait_for_turn_released(&svc, &conv.id).await;

    assert_eq!(task_mgr.kill_count(), 0);
    assert_eq!(task_mgr.active_count(), 1);
}

#[tokio::test]
async fn send_message_does_not_inject_send_error_when_runtime_terminal_exists() {
    let (svc, _broadcaster, repo, _default_task_mgr) = make_service();
    let task_mgr = Arc::new(MockTaskManager::new());
    let conv = svc.create("user_1", make_create_req()).await.unwrap();

    let scripted_agent = Arc::new(
        ScriptedAgent::new(
            &conv.id,
            vec![vec![AgentStreamEvent::Error(ErrorEventData::legacy(
                "runtime already emitted",
                Some(AgentErrorCode::UnknownUpstreamError),
            ))]],
        )
        .with_send_error(AgentSendError::from_agent_error(AgentError::bad_gateway(
            "fallback should not render",
        ))),
    );
    task_mgr.insert_agent(&conv.id, AgentInstance::Mock(scripted_agent));

    let task_mgr_dyn: Arc<dyn IWorkerTaskManager> = task_mgr.clone();
    svc.send_message("user_1", &conv.id, make_send_req(), &task_mgr_dyn)
        .await
        .unwrap();
    wait_for_turn_released(&svc, &conv.id).await;

    let messages = repo
        .list_messages_page(
            "user_1",
            &conv.id,
            &MessagePageParams {
                limit: 20,
                direction: MessagePageDirection::InitialLatest,
            },
        )
        .await
        .unwrap()
        .items;
    let tips: Vec<_> = messages.iter().filter(|msg| msg.r#type == "tips").collect();
    assert_eq!(tips.len(), 1);
    let content: serde_json::Value = serde_json::from_str(&tips[0].content).unwrap();
    assert_eq!(content["content"], "runtime already emitted");
}

#[tokio::test]
async fn send_message_injects_send_error_when_runtime_terminal_missing() {
    let (svc, _broadcaster, repo, _default_task_mgr) = make_service();
    let task_mgr = Arc::new(MockTaskManager::new());
    let conv = svc.create("user_1", make_create_req()).await.unwrap();

    let scripted_agent = Arc::new(
        ScriptedAgent::new(&conv.id, vec![vec![]])
            .with_status(None)
            .with_send_error(AgentSendError::from_agent_error(AgentError::bad_gateway(
                "provider returned 401 invalid api key",
            ))),
    );
    task_mgr.insert_agent(&conv.id, AgentInstance::Mock(scripted_agent));

    let task_mgr_dyn: Arc<dyn IWorkerTaskManager> = task_mgr.clone();
    svc.send_message("user_1", &conv.id, make_send_req(), &task_mgr_dyn)
        .await
        .unwrap();
    wait_for_turn_released(&svc, &conv.id).await;

    let messages = repo
        .list_messages_page(
            "user_1",
            &conv.id,
            &MessagePageParams {
                limit: 20,
                direction: MessagePageDirection::InitialLatest,
            },
        )
        .await
        .unwrap()
        .items;
    let tips: Vec<_> = messages.iter().filter(|msg| msg.r#type == "tips").collect();
    assert_eq!(tips.len(), 1);
    let content: serde_json::Value = serde_json::from_str(&tips[0].content).unwrap();
    assert_eq!(content["type"], "error");
    assert_eq!(content["error"]["code"], "USER_LLM_PROVIDER_AUTH_FAILED");
}

#[tokio::test]
async fn send_message_records_agent_availability_feedback_on_send_failure() {
    let (svc, _broadcaster, _repo, _default_task_mgr) = make_service();
    let task_mgr = Arc::new(MockTaskManager::new());
    let feedback = Arc::new(RecordingAvailabilityFeedback::default());
    svc.with_agent_availability_feedback(feedback.clone());

    let mut create_req = make_create_req();
    create_req.name = Some("Feedback Conversation".into());
    create_req.source = Some(ConversationSource::Qianji);
    create_req.extra = json!({
        "backend": "claude",
        "agent_id": "agent-feedback-1",
        "agent_source": "custom",
        "workspace": ensure_test_workspace_path()
    });

    let conv = svc.create("user_1", create_req).await.unwrap();

    let scripted_agent = Arc::new(
        ScriptedAgent::new(&conv.id, vec![vec![]])
            .with_status(None)
            .with_send_error(AgentSendError::from_agent_error(AgentError::bad_gateway(
                "provider returned 401 invalid api key",
            ))),
    );
    task_mgr.insert_agent(&conv.id, AgentInstance::Mock(scripted_agent));

    let task_mgr_dyn: Arc<dyn IWorkerTaskManager> = task_mgr.clone();
    svc.send_message("user_1", &conv.id, make_send_req(), &task_mgr_dyn)
        .await
        .unwrap();
    wait_for_turn_released(&svc, &conv.id).await;

    let failures = feedback.failures.lock().unwrap().clone();
    assert_eq!(
        failures,
        vec![
            RecordedAvailabilityFailure {
                user_id: "user_1".into(),
                agent_id: "agent-feedback-1".into(),
                code: "session_send_failed".into(),
                message: "provider returned 401 invalid api key".into(),
            },
            RecordedAvailabilityFailure {
                user_id: "user_1".into(),
                agent_id: "agent-feedback-1".into(),
                code: "auth_required".into(),
                message: "provider returned 401 invalid api key".into(),
            },
        ]
    );
}

#[tokio::test]
async fn send_message_records_agent_availability_feedback_on_send_success() {
    let (svc, _broadcaster, _repo, _default_task_mgr) = make_service();
    let task_mgr = Arc::new(MockTaskManager::new());
    let feedback = Arc::new(RecordingAvailabilityFeedback::default());
    svc.with_agent_availability_feedback(feedback.clone());

    let mut create_req = make_create_req();
    create_req.name = Some("Feedback Success Conversation".into());
    create_req.source = Some(ConversationSource::Qianji);
    create_req.extra = json!({
        "backend": "claude",
        "agent_id": "agent-feedback-success",
        "agent_source": "custom",
        "workspace": ensure_test_workspace_path()
    });

    let conv = svc.create("user_1", create_req).await.unwrap();

    let scripted_agent = Arc::new(ScriptedAgent::new(
        &conv.id,
        vec![vec![AgentStreamEvent::Finish(FinishEventData::default())]],
    ));
    task_mgr.insert_agent(&conv.id, AgentInstance::Mock(scripted_agent));

    let task_mgr_dyn: Arc<dyn IWorkerTaskManager> = task_mgr.clone();
    svc.send_message("user_1", &conv.id, make_send_req(), &task_mgr_dyn)
        .await
        .unwrap();
    wait_for_turn_released(&svc, &conv.id).await;

    let successes = feedback.successes.lock().unwrap().clone();
    assert_eq!(
        successes,
        vec![("user_1".to_owned(), "agent-feedback-success".to_owned())]
    );
    assert!(feedback.failures.lock().unwrap().is_empty());
}

#[tokio::test]
async fn send_message_recovers_when_finished_task_has_no_runtime_terminal() {
    let (svc, _broadcaster, repo, _default_task_mgr) = make_service();
    let task_mgr = Arc::new(MockTaskManager::new());
    let conv = svc.create("user_1", make_create_req()).await.unwrap();

    let scripted_agent = Arc::new(
        ScriptedAgent::new(&conv.id, vec![vec![]])
            .with_status(Some(ConversationStatus::Finished))
            .with_send_error(AgentSendError::from_agent_error(AgentError::bad_gateway(
                "acp protocol not connected",
            ))),
    );
    task_mgr.insert_agent(&conv.id, AgentInstance::Mock(scripted_agent));

    let task_mgr_dyn: Arc<dyn IWorkerTaskManager> = task_mgr.clone();
    svc.send_message("user_1", &conv.id, make_send_req(), &task_mgr_dyn)
        .await
        .unwrap();
    wait_for_turn_released(&svc, &conv.id).await;

    assert_eq!(task_mgr.kill_count(), 1);
    assert_eq!(task_mgr.active_count(), 1);

    let messages = repo_messages_asc(&repo, &conv.id, 20).await;
    let tips: Vec<_> = messages.iter().filter(|msg| msg.r#type == "tips").collect();
    assert!(tips.is_empty());
}

#[tokio::test]
async fn send_message_auto_replays_clean_retryable_acp_error_once() {
    let (svc, _broadcaster, repo, _default_task_mgr) = make_service();
    let conv = svc.create("user_1", make_create_req()).await.unwrap();

    let first = Arc::new(ScriptedAgent::new(
        &conv.id,
        vec![vec![AgentStreamEvent::Error(ErrorEventData {
            message: "temporary provider failure".into(),
            code: Some(AgentErrorCode::UnknownUpstreamError),
            ownership: None,
            detail: None,
            workspace_path: None,
            retryable: Some(true),
            feedback_recommended: None,
            resolution: None,
        })]],
    ));
    let second = Arc::new(ScriptedAgent::new(
        &conv.id,
        vec![vec![
            AgentStreamEvent::Text(TextEventData { content: "done".into() }),
            AgentStreamEvent::Finish(FinishEventData::default()),
        ]],
    ));
    let task_mgr = Arc::new(RebuildingScriptedTaskManager::new(vec![
        AgentInstance::Mock(first.clone()),
        AgentInstance::Mock(second.clone()),
    ]));

    let task_mgr_dyn: Arc<dyn IWorkerTaskManager> = task_mgr.clone();
    svc.send_message("user_1", &conv.id, make_send_req(), &task_mgr_dyn)
        .await
        .unwrap();
    wait_for_turn_released(&svc, &conv.id).await;

    assert_eq!(task_mgr.build_count(), 2);
    assert_eq!(task_mgr.kill_count(), 1);
    assert_eq!(first.sent_contents(), vec!["Hello"]);
    assert_eq!(second.sent_contents(), vec!["Hello"]);

    let messages = repo_messages_asc(&repo, &conv.id, 20).await;
    let users: Vec<_> = messages
        .iter()
        .filter(|msg| msg.r#type == "text" && msg.position.as_deref() == Some("right"))
        .collect();
    let assistants: Vec<_> = messages
        .iter()
        .filter(|msg| msg.r#type == "text" && msg.position.as_deref() == Some("left"))
        .collect();
    let tips: Vec<_> = messages.iter().filter(|msg| msg.r#type == "tips").collect();
    assert_eq!(users.len(), 1, "auto replay must not insert the user message again");
    assert_eq!(assistants.len(), 1);
    assert_eq!(
        tips.len(),
        0,
        "first clean retryable error stays hidden when replay succeeds"
    );
}

#[tokio::test]
async fn auto_replay_rebuild_keeps_existing_acp_session_id_in_build_options() {
    let acp_session_repo = Arc::new(StubAcpSessionRepo::with_session_id("sess-existing"));
    let (svc, _broadcaster, _repo, _default_task_mgr) = make_service_with_resolver_and_acp_session_repo(
        Arc::new(FixedSkillResolver { names: vec![] }),
        acp_session_repo,
    );
    let conv = svc.create("user_1", make_create_req()).await.unwrap();

    let first = Arc::new(ScriptedAgent::new(
        &conv.id,
        vec![vec![AgentStreamEvent::Error(ErrorEventData {
            message: "temporary provider failure".into(),
            code: Some(AgentErrorCode::UnknownUpstreamError),
            ownership: None,
            detail: None,
            workspace_path: None,
            retryable: Some(true),
            feedback_recommended: None,
            resolution: None,
        })]],
    ));
    let second = Arc::new(ScriptedAgent::new(
        &conv.id,
        vec![vec![AgentStreamEvent::Finish(FinishEventData::default())]],
    ));
    let task_mgr = Arc::new(RebuildingScriptedTaskManager::new(vec![
        AgentInstance::Mock(first),
        AgentInstance::Mock(second),
    ]));

    let task_mgr_dyn: Arc<dyn IWorkerTaskManager> = task_mgr.clone();
    svc.send_message("user_1", &conv.id, make_send_req(), &task_mgr_dyn)
        .await
        .unwrap();
    wait_for_turn_released(&svc, &conv.id).await;

    let options = task_mgr.captured_options();
    assert_eq!(options.len(), 2);
    for options in options {
        match options.context.kind {
            AgentSessionKind::Acp(ctx) => {
                assert_eq!(ctx.session_id.as_deref(), Some("sess-existing"));
            }
            AgentSessionKind::Qianjirs(_) | AgentSessionKind::Antigravity(_) => {
                panic!("test conversation should build ACP options")
            }
        }
    }
}

#[tokio::test]
async fn send_message_does_not_auto_replay_after_visible_output() {
    let (svc, _broadcaster, repo, _default_task_mgr) = make_service();
    let conv = svc.create("user_1", make_create_req()).await.unwrap();

    let first = Arc::new(ScriptedAgent::new(
        &conv.id,
        vec![vec![
            AgentStreamEvent::Text(TextEventData {
                content: "partial".into(),
            }),
            AgentStreamEvent::Error(ErrorEventData {
                message: "temporary provider failure".into(),
                code: Some(AgentErrorCode::UnknownUpstreamError),
                ownership: None,
                detail: None,
                workspace_path: None,
                retryable: Some(true),
                feedback_recommended: None,
                resolution: None,
            }),
        ]],
    ));
    let second = Arc::new(ScriptedAgent::new(
        &conv.id,
        vec![vec![AgentStreamEvent::Finish(FinishEventData::default())]],
    ));
    let task_mgr = Arc::new(RebuildingScriptedTaskManager::new(vec![
        AgentInstance::Mock(first),
        AgentInstance::Mock(second),
    ]));

    let task_mgr_dyn: Arc<dyn IWorkerTaskManager> = task_mgr.clone();
    svc.send_message("user_1", &conv.id, make_send_req(), &task_mgr_dyn)
        .await
        .unwrap();
    wait_for_turn_released(&svc, &conv.id).await;

    assert_eq!(task_mgr.build_count(), 1);
    assert_eq!(task_mgr.kill_count(), 1);
    let messages = repo_messages_asc(&repo, &conv.id, 20).await;
    let assistants: Vec<_> = messages
        .iter()
        .filter(|msg| msg.r#type == "text" && msg.position.as_deref() == Some("left"))
        .collect();
    assert_eq!(assistants.len(), 1);
    assert!(assistants[0].content.contains("partial"));
}

#[tokio::test]
async fn send_message_does_not_auto_replay_after_tool_side_effect() {
    let (svc, _broadcaster, _repo, _default_task_mgr) = make_service();
    let conv = svc.create("user_1", make_create_req()).await.unwrap();

    let first = Arc::new(ScriptedAgent::new(
        &conv.id,
        vec![vec![
            AgentStreamEvent::ToolCall(ToolCallEventData {
                call_id: "call-1".into(),
                name: "write_file".into(),
                args: serde_json::json!({ "path": "a.txt" }),
                status: ToolCallStatus::Running,
                input: None,
                output: None,
                description: None,
                parent_call_id: None,
            }),
            AgentStreamEvent::Error(ErrorEventData {
                message: "temporary provider failure".into(),
                code: Some(AgentErrorCode::UnknownUpstreamError),
                ownership: None,
                detail: None,
                workspace_path: None,
                retryable: Some(true),
                feedback_recommended: None,
                resolution: None,
            }),
        ]],
    ));
    let second = Arc::new(ScriptedAgent::new(
        &conv.id,
        vec![vec![AgentStreamEvent::Finish(FinishEventData::default())]],
    ));
    let task_mgr = Arc::new(RebuildingScriptedTaskManager::new(vec![
        AgentInstance::Mock(first),
        AgentInstance::Mock(second),
    ]));

    let task_mgr_dyn: Arc<dyn IWorkerTaskManager> = task_mgr.clone();
    svc.send_message("user_1", &conv.id, make_send_req(), &task_mgr_dyn)
        .await
        .unwrap();
    wait_for_turn_released(&svc, &conv.id).await;

    assert_eq!(task_mgr.build_count(), 1);
    assert_eq!(task_mgr.kill_count(), 1);
}

#[tokio::test]
async fn send_message_does_not_auto_replay_model_not_found() {
    let (svc, _broadcaster, repo, _default_task_mgr) = make_service();
    let conv = svc.create("user_1", make_create_req()).await.unwrap();

    let first = Arc::new(ScriptedAgent::new(
        &conv.id,
        vec![vec![AgentStreamEvent::Error(ErrorEventData {
            message: "model not found".into(),
            code: Some(AgentErrorCode::UserLlmProviderModelNotFound),
            ownership: None,
            detail: None,
            workspace_path: None,
            retryable: Some(true),
            feedback_recommended: None,
            resolution: None,
        })]],
    ));
    let second = Arc::new(ScriptedAgent::new(
        &conv.id,
        vec![vec![AgentStreamEvent::Finish(FinishEventData::default())]],
    ));
    let task_mgr = Arc::new(RebuildingScriptedTaskManager::new(vec![
        AgentInstance::Mock(first),
        AgentInstance::Mock(second),
    ]));

    let task_mgr_dyn: Arc<dyn IWorkerTaskManager> = task_mgr.clone();
    svc.send_message("user_1", &conv.id, make_send_req(), &task_mgr_dyn)
        .await
        .unwrap();
    wait_for_turn_released(&svc, &conv.id).await;

    assert_eq!(task_mgr.build_count(), 1);
    assert_eq!(task_mgr.kill_count(), 1);
    let messages = repo_messages_asc(&repo, &conv.id, 20).await;
    let tips: Vec<_> = messages.iter().filter(|msg| msg.r#type == "tips").collect();
    assert_eq!(
        tips.len(),
        1,
        "model_not_found should remain visible and must not be swallowed by replay deferral"
    );
}

#[tokio::test]
async fn send_message_auto_replay_stops_after_second_retryable_failure() {
    let (svc, _broadcaster, repo, _default_task_mgr) = make_service();
    let conv = svc.create("user_1", make_create_req()).await.unwrap();

    let first = Arc::new(ScriptedAgent::new(
        &conv.id,
        vec![vec![AgentStreamEvent::Error(ErrorEventData {
            message: "temporary provider failure one".into(),
            code: Some(AgentErrorCode::UnknownUpstreamError),
            ownership: None,
            detail: None,
            workspace_path: None,
            retryable: Some(true),
            feedback_recommended: None,
            resolution: None,
        })]],
    ));
    let second = Arc::new(ScriptedAgent::new(
        &conv.id,
        vec![vec![AgentStreamEvent::Error(ErrorEventData {
            message: "temporary provider failure two".into(),
            code: Some(AgentErrorCode::UnknownUpstreamError),
            ownership: None,
            detail: None,
            workspace_path: None,
            retryable: Some(true),
            feedback_recommended: None,
            resolution: None,
        })]],
    ));
    let third = Arc::new(ScriptedAgent::new(
        &conv.id,
        vec![vec![AgentStreamEvent::Finish(FinishEventData::default())]],
    ));
    let task_mgr = Arc::new(RebuildingScriptedTaskManager::new(vec![
        AgentInstance::Mock(first),
        AgentInstance::Mock(second),
        AgentInstance::Mock(third),
    ]));

    let task_mgr_dyn: Arc<dyn IWorkerTaskManager> = task_mgr.clone();
    svc.send_message("user_1", &conv.id, make_send_req(), &task_mgr_dyn)
        .await
        .unwrap();
    wait_for_turn_released(&svc, &conv.id).await;

    assert_eq!(task_mgr.build_count(), 2);
    assert_eq!(task_mgr.kill_count(), 2);
    let messages = repo_messages_asc(&repo, &conv.id, 20).await;
    let tips: Vec<_> = messages.iter().filter(|msg| msg.r#type == "tips").collect();
    assert_eq!(tips.len(), 1, "second failure is final and visible");
    let content: serde_json::Value = serde_json::from_str(&tips[0].content).unwrap();
    assert_eq!(content["content"], "temporary provider failure two");
}

// ── stop_stream tests ───────────────────────────────────────────

#[tokio::test]
async fn stop_stream_with_active_agent() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let task_mgr = Arc::new(MockTaskManager::new());

    let conv = svc.create("user_1", make_create_req()).await.unwrap();

    // Build agent via send_message
    let send = svc
        .send_message(
            "user_1",
            &conv.id,
            make_send_req(),
            &(task_mgr.clone() as Arc<dyn IWorkerTaskManager>),
        )
        .await
        .unwrap();

    // Stop should succeed since agent exists
    let result = svc
        .cancel(
            "user_1",
            &conv.id,
            &send.turn_id,
            &(task_mgr as Arc<dyn IWorkerTaskManager>),
        )
        .await;
    assert!(result.is_ok());
}

#[tokio::test]
async fn cancel_with_mismatched_turn_id_does_not_cancel_and_returns_current_runtime() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let slow_task_mgr = Arc::new(SlowBuildTaskManager::new(Duration::from_millis(500)));
    let task_mgr: Arc<dyn IWorkerTaskManager> = slow_task_mgr.clone();

    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    let send = svc
        .send_message("user_1", &conv.id, make_send_req(), &task_mgr)
        .await
        .unwrap();

    let response = svc.cancel("user_1", &conv.id, "turn_stale", &task_mgr).await.unwrap();

    assert_eq!(response.runtime.turn_id.as_deref(), Some(send.turn_id.as_str()));
    assert!(response.runtime.is_processing);
    assert!(svc.runtime_state().is_claimed(&conv.id));
}

#[tokio::test]
async fn cancel_keeps_turn_claim_until_agent_terminal_event() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let task_mgr = Arc::new(MockTaskManager::new());
    let task_mgr_dyn: Arc<dyn IWorkerTaskManager> = task_mgr.clone();

    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    let agent = Arc::new(BlockingCancelAgent::new(&conv.id));
    task_mgr.insert_agent(&conv.id, AgentInstance::Mock(agent.clone()));

    let send = svc
        .send_message("user_1", &conv.id, make_send_req(), &task_mgr_dyn)
        .await
        .unwrap();
    agent.wait_until_send_started().await;

    let cancel = svc
        .cancel("user_1", &conv.id, &send.turn_id, &task_mgr_dyn)
        .await
        .unwrap();

    assert_eq!(cancel.runtime.turn_id.as_deref(), Some(send.turn_id.as_str()));
    assert!(cancel.runtime.is_processing);
    assert!(!cancel.runtime.can_send_message);
    assert!(svc.runtime_state().is_claimed(&conv.id));

    let second = svc
        .send_message("user_1", &conv.id, make_send_req(), &task_mgr_dyn)
        .await
        .unwrap_err();
    assert!(matches!(second, ConversationError::Busy { .. }));

    agent.release_finish();
    wait_for_turn_released(&svc, &conv.id).await;
}

#[tokio::test]
async fn cancel_error_clears_cancelling_state() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let task_mgr = Arc::new(MockTaskManager::new());
    let task_mgr_dyn: Arc<dyn IWorkerTaskManager> = task_mgr.clone();

    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    let agent = Arc::new(BlockingCancelAgent::new_with_cancel_error(&conv.id));
    task_mgr.insert_agent(&conv.id, AgentInstance::Mock(agent.clone()));

    let send = svc
        .send_message("user_1", &conv.id, make_send_req(), &task_mgr_dyn)
        .await
        .unwrap();
    agent.wait_until_send_started().await;

    let err = svc
        .cancel("user_1", &conv.id, &send.turn_id, &task_mgr_dyn)
        .await
        .unwrap_err();

    assert!(matches!(err, ConversationError::BadGateway { .. }));
    assert!(!svc.runtime_state().is_cancelling(&conv.id));

    agent.release_finish();
    wait_for_turn_released(&svc, &conv.id).await;
}

#[tokio::test(start_paused = true)]
async fn cancel_timeout_kills_acp_task_when_turn_still_claimed() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let task_mgr = Arc::new(MockTaskManager::new());
    let task_mgr_dyn: Arc<dyn IWorkerTaskManager> = task_mgr.clone();

    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    let agent = Arc::new(BlockingCancelAgent::new(&conv.id));
    task_mgr.insert_agent(&conv.id, AgentInstance::Mock(agent));

    let send = svc
        .send_message("user_1", &conv.id, make_send_req(), &task_mgr_dyn)
        .await
        .unwrap();

    svc.cancel("user_1", &conv.id, &send.turn_id, &task_mgr_dyn)
        .await
        .unwrap();

    tokio::task::yield_now().await;
    tokio::time::advance(Duration::from_secs(15) + Duration::from_millis(1)).await;
    tokio::task::yield_now().await;

    assert_eq!(
        task_mgr.kill_records(),
        vec![(conv.id.clone(), Some(AgentKillReason::UserCancelTimeout))]
    );
}

#[tokio::test(start_paused = true)]
async fn cancel_timeout_does_not_kill_non_acp_task() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let task_mgr = Arc::new(MockTaskManager::new());
    let task_mgr_dyn: Arc<dyn IWorkerTaskManager> = task_mgr.clone();

    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    let agent = Arc::new(BlockingCancelAgent::new_with_type(&conv.id, AgentType::Qianjirs));
    task_mgr.insert_agent(&conv.id, AgentInstance::Mock(agent));

    let send = svc
        .send_message("user_1", &conv.id, make_send_req(), &task_mgr_dyn)
        .await
        .unwrap();

    svc.cancel("user_1", &conv.id, &send.turn_id, &task_mgr_dyn)
        .await
        .unwrap();

    tokio::task::yield_now().await;
    tokio::time::advance(Duration::from_secs(15) + Duration::from_millis(1)).await;
    tokio::task::yield_now().await;

    assert!(task_mgr.kill_records().is_empty());
}

#[tokio::test]
async fn stop_stream_conversation_not_found() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let task_mgr: Arc<dyn IWorkerTaskManager> = Arc::new(MockTaskManager::new());

    let err = svc
        .cancel("user_1", "no-such-id", "turn-test", &task_mgr)
        .await
        .unwrap_err();
    assert!(matches!(err, ConversationError::NotFound { .. }));
}

#[tokio::test]
async fn stop_stream_no_active_agent_is_idempotent() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let task_mgr: Arc<dyn IWorkerTaskManager> = Arc::new(MockTaskManager::new());

    let conv = svc.create("user_1", make_create_req()).await.unwrap();

    let result = svc.cancel("user_1", &conv.id, "turn-test", &task_mgr).await;
    assert!(result.is_ok());
}

#[tokio::test]
async fn stop_stream_wrong_user_returns_not_found() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let task_mgr: Arc<dyn IWorkerTaskManager> = Arc::new(MockTaskManager::new());

    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    let err = svc
        .cancel("user_2", &conv.id, "turn-test", &task_mgr)
        .await
        .unwrap_err();
    assert!(matches!(err, ConversationError::NotFound { .. }));
}

// ── warmup tests ────────────────────────────────────────────────

#[tokio::test]
async fn warmup_creates_agent_task() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let task_mgr = Arc::new(MockTaskManager::new());

    let conv = svc.create("user_1", make_create_req()).await.unwrap();

    let result = svc
        .warmup("user_1", &conv.id, &(task_mgr.clone() as Arc<dyn IWorkerTaskManager>))
        .await;
    assert!(result.is_ok());

    // Agent should now exist
    assert!(task_mgr.get_task(&conv.id).is_some());
}

#[tokio::test]
async fn warmup_injects_conversation_runtime_context() {
    let (svc, _broadcaster, _repo, _default_task_mgr) = make_service();
    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    let task_mgr = Arc::new(RebuildingScriptedTaskManager::new(vec![AgentInstance::Mock(Arc::new(
        MockAgent::new(&conv.id),
    ))]));
    let task_mgr_dyn: Arc<dyn IWorkerTaskManager> = task_mgr.clone();

    svc.warmup("user_1", &conv.id, &task_mgr_dyn).await.unwrap();

    let options = task_mgr.captured_options();
    assert_eq!(options.len(), 1);
    assert_conversation_runtime_context(&options[0], "user_1", &conv.id);
}

#[tokio::test]
async fn warmup_keeps_existing_acp_session_anchor_in_build_options() {
    let acp_session_repo = Arc::new(StubAcpSessionRepo::with_session_id("sess-existing"));
    let (svc, _broadcaster, _repo, _default_task_mgr) = make_service_with_resolver_and_acp_session_repo(
        Arc::new(FixedSkillResolver { names: vec![] }),
        acp_session_repo,
    );
    let mut request = make_create_req();
    request.extra = serde_json::json!({
        "teamId": "team-1",
        "slot_id": "slot-1",
        "role": "teammate",
    });
    let conv = svc.create("user_1", request).await.unwrap();
    let task_mgr = Arc::new(RebuildingScriptedTaskManager::new(vec![AgentInstance::Mock(Arc::new(
        MockAgent::new(&conv.id),
    ))]));
    let task_mgr_dyn: Arc<dyn IWorkerTaskManager> = task_mgr.clone();

    svc.warmup("user_1", &conv.id, &task_mgr_dyn).await.unwrap();

    let options = task_mgr.captured_options();
    assert_eq!(options.len(), 1);
    match &options[0].context.kind {
        AgentSessionKind::Acp(context) => {
            assert_eq!(context.session_id.as_deref(), Some("sess-existing"));
        }
        AgentSessionKind::Qianjirs(_) | AgentSessionKind::Antigravity(_) => {
            panic!("test conversation should build ACP options")
        }
    }
}

#[tokio::test]
async fn warmup_injects_runtime_token_for_mcp_team_conversation() {
    let (svc, _broadcaster, _repo, _default_task_mgr) = make_service();
    let svc = svc.with_runtime_token_service(Arc::new(RuntimeTokenService::new()));
    let mut req = make_create_req();
    req.extra = serde_json::json!({
        "teamId": "team-1",
        "slot_id": "slot-1",
        "role": "lead",
        "team_mcp_stdio_config": {
            "team_id": "team-1",
            "port": 4242,
            "token": "mcp-token",
            "slot_id": "slot-1",
            "binary_path": "/tmp/qianjicore"
        }
    });
    let conv = svc.create("user_1", req).await.unwrap();
    let task_mgr = Arc::new(RebuildingScriptedTaskManager::new(vec![AgentInstance::Mock(Arc::new(
        MockAgent::new(&conv.id),
    ))]));
    let task_mgr_dyn: Arc<dyn IWorkerTaskManager> = task_mgr.clone();

    svc.warmup("user_1", &conv.id, &task_mgr_dyn).await.unwrap();

    let options = task_mgr.captured_options();
    assert_eq!(options.len(), 1);
    assert!(
        options[0]
            .context
            .runtime_env
            .iter()
            .any(|(key, value)| key == QIANJI_RUNTIME_TOKEN_ENV && !value.is_empty()),
        "MCP Team conversations should receive QIANJI_RUNTIME_TOKEN for CLI fallback"
    );
}

#[tokio::test]
async fn warmup_rejects_legacy_runtime_conversations_as_archived() {
    let (svc, _broadcaster, repo, _task_mgr) = make_service();
    let task_mgr: Arc<dyn IWorkerTaskManager> = Arc::new(MockTaskManager::new());

    for agent_type in [
        AgentType::Gemini,
        AgentType::Codex,
        AgentType::OpenclawGateway,
        AgentType::Nanobot,
        AgentType::Remote,
    ] {
        let conv = insert_conversation_with_type(&repo, "user_1", agent_type).await;

        let err = svc.warmup("user_1", &conv.id, &task_mgr).await.unwrap_err();

        assert_eq!(err.error_code(), "CONVERSATION_ARCHIVED");
        assert!(
            err.to_string()
                .contains("This historical conversation can no longer be continued. Please start a new conversation."),
            "unexpected archived message for {}: {err}",
            agent_type.serde_name()
        );
    }
}

#[tokio::test]
async fn warmup_conversation_not_found() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let task_mgr: Arc<dyn IWorkerTaskManager> = Arc::new(MockTaskManager::new());

    let err = svc.warmup("user_1", "no-such-id", &task_mgr).await.unwrap_err();
    assert!(matches!(err, ConversationError::NotFound { .. }));
}

#[tokio::test]
async fn warmup_wrong_user_returns_not_found() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let task_mgr: Arc<dyn IWorkerTaskManager> = Arc::new(MockTaskManager::new());

    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    let err = svc.warmup("user_2", &conv.id, &task_mgr).await.unwrap_err();
    assert!(matches!(err, ConversationError::NotFound { .. }));
}

#[tokio::test]
async fn warmup_rejects_legacy_workspace_with_runtime_error_code() {
    let (svc, _broadcaster, repo, _task_mgr) = make_service();
    let task_mgr: Arc<dyn IWorkerTaskManager> = Arc::new(MockTaskManager::new());

    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    let legacy_workspace = format!("/tmp/does-not-exist-{}", qianji_common::generate_short_id());
    repo.update(
        "user_1",
        &conv.id,
        &ConversationRowUpdate {
            extra: Some(json!({ "workspace": legacy_workspace }).to_string()),
            ..Default::default()
        },
    )
    .await
    .unwrap();

    let err = svc.warmup("user_1", &conv.id, &task_mgr).await.unwrap_err();
    assert!(matches!(
        err,
        ConversationError::WorkspacePathRuntimeUnavailable { path: message }
            if message == legacy_workspace
    ));
}

#[tokio::test]
async fn warmup_returns_openclaw_gateway_unreachable_when_startup_stderr_matches() {
    let (svc, _broadcaster, _repo, _default_task_mgr) = make_service();
    let task_mgr: Arc<dyn IWorkerTaskManager> = Arc::new(AgentErrorFailingBuildTaskManager::new(AgentError::from(
        AcpError::StartupCrash {
            exit_code: Some(1),
            signal: None,
            stderr: "ACP bridge failed: connect ECONNREFUSED 127.0.0.1:18789".into(),
        },
    )));

    let conv = svc
        .create("user_1", make_create_req_with_backend("openclaw"))
        .await
        .unwrap();

    let err = svc.warmup("user_1", &conv.id, &task_mgr).await.unwrap_err();

    match err {
        ConversationError::OpenClawGatewayUnreachable { detail } => {
            assert!(detail.contains("127.0.0.1:18789"));
            assert!(detail.contains("openclaw gateway status"));
            assert!(detail.contains("openclaw gateway start"));
        }
        other => panic!("expected OpenClawGatewayUnreachable, got {other:?}"),
    }
}

#[tokio::test]
async fn warmup_keeps_generic_error_for_non_openclaw_gateway_signature() {
    let (svc, _broadcaster, _repo, _default_task_mgr) = make_service();
    let task_mgr: Arc<dyn IWorkerTaskManager> = Arc::new(AgentErrorFailingBuildTaskManager::new(AgentError::from(
        AcpError::StartupCrash {
            exit_code: Some(1),
            signal: None,
            stderr: "ACP bridge failed: connect ECONNREFUSED 127.0.0.1:18789".into(),
        },
    )));

    let conv = svc
        .create("user_1", make_create_req_with_backend("codex"))
        .await
        .unwrap();

    let err = svc.warmup("user_1", &conv.id, &task_mgr).await.unwrap_err();

    assert!(
        !matches!(err, ConversationError::OpenClawGatewayUnreachable { .. }),
        "non-OpenClaw backend must not receive the OpenClaw Gateway error"
    );
}

// ── Confirmation system tests ────────────────────────────────────

fn make_test_confirmations() -> Vec<Confirmation> {
    vec![
        Confirmation {
            id: "c1".into(),
            call_id: "call-1".into(),
            title: Some("Allow file edit".into()),
            action: Some("edit_file".into()),
            description: "Edit main.rs".into(),
            command_type: Some("bash".into()),
            questions: None,
            options: vec![],
        },
        Confirmation {
            id: "c2".into(),
            call_id: "call-2".into(),
            title: Some("Read file".into()),
            action: Some("read_file".into()),
            description: "Read config.toml".into(),
            command_type: None,
            questions: None,
            options: vec![],
        },
    ]
}

#[tokio::test]
async fn list_confirmations_empty_when_no_agent() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let task_mgr: Arc<dyn IWorkerTaskManager> = Arc::new(MockTaskManager::new());

    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    let result = svc.list_confirmations("user_1", &conv.id, &task_mgr).await.unwrap();
    assert!(result.is_empty());
}

#[tokio::test]
async fn list_confirmations_returns_items() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let task_mgr = Arc::new(MockTaskManager::new());

    let conv = svc.create("user_1", make_create_req()).await.unwrap();

    let agent = AgentInstance::Mock(Arc::new(MockAgent::with_confirmations(
        &conv.id,
        make_test_confirmations(),
    )));
    task_mgr.insert_agent(&conv.id, agent);

    let result = svc
        .list_confirmations("user_1", &conv.id, &(task_mgr as Arc<dyn IWorkerTaskManager>))
        .await
        .unwrap();
    assert_eq!(result.len(), 2);
    assert_eq!(result[0].call_id, "call-1");
    assert_eq!(result[1].call_id, "call-2");
}

#[tokio::test]
async fn list_confirmations_not_found() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let task_mgr: Arc<dyn IWorkerTaskManager> = Arc::new(MockTaskManager::new());

    let err = svc
        .list_confirmations("user_1", "no-such-id", &task_mgr)
        .await
        .unwrap_err();
    assert!(matches!(err, ConversationError::NotFound { .. }));
}

#[tokio::test]
async fn list_confirmations_wrong_user() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let task_mgr: Arc<dyn IWorkerTaskManager> = Arc::new(MockTaskManager::new());

    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    let err = svc.list_confirmations("user_2", &conv.id, &task_mgr).await.unwrap_err();
    assert!(matches!(err, ConversationError::NotFound { .. }));
}

#[tokio::test]
async fn confirm_removes_confirmation_and_broadcasts() {
    let (svc, broadcaster, _repo, _task_mgr) = make_service();
    let task_mgr = Arc::new(MockTaskManager::new());

    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    broadcaster.take_events(); // clear create event

    let agent = AgentInstance::Mock(Arc::new(MockAgent::with_confirmations(
        &conv.id,
        make_test_confirmations(),
    )));
    task_mgr.insert_agent(&conv.id, agent);

    let req = qianji_api_types::ConfirmRequest {
        msg_id: "msg-1".into(),
        data: json!({ "value": "allow" }),
        always_allow: false,
    };
    svc.confirm(
        "user_1",
        &conv.id,
        "call-1",
        req,
        &(task_mgr.clone() as Arc<dyn IWorkerTaskManager>),
    )
    .await
    .unwrap();

    // Confirmation should be removed from the agent
    let remaining = task_mgr.get_task(&conv.id).unwrap().get_confirmations();
    assert_eq!(remaining.len(), 1);
    assert_eq!(remaining[0].call_id, "call-2");

    // Should broadcast confirmation.remove event
    let events = broadcaster.take_events();
    assert_eq!(events.len(), 1);
    assert_eq!(events[0].name, "confirmation.remove");
    assert_eq!(events[0].data["conversation_id"], conv.id);
    assert_eq!(events[0].data["id"], "c1");
}

#[tokio::test]
async fn confirm_with_always_allow_stores_approval() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let task_mgr = Arc::new(MockTaskManager::new());

    let conv = svc.create("user_1", make_create_req()).await.unwrap();

    let agent = AgentInstance::Mock(Arc::new(MockAgent::with_confirmations(
        &conv.id,
        make_test_confirmations(),
    )));
    task_mgr.insert_agent(&conv.id, agent);

    let req = qianji_api_types::ConfirmRequest {
        msg_id: "msg-1".into(),
        data: json!({ "value": "allow" }),
        always_allow: true,
    };
    let task_mgr_arc: Arc<dyn IWorkerTaskManager> = task_mgr.clone();
    svc.confirm("user_1", &conv.id, "call-1", req, &task_mgr_arc)
        .await
        .unwrap();

    // check_approval should now return true for edit_file:bash
    let agent = task_mgr.get_task(&conv.id).unwrap();
    assert!(agent.check_approval("edit_file", Some("bash")));
    assert!(!agent.check_approval("delete_file", None));
}

#[tokio::test]
async fn confirm_nonexistent_call_id_returns_not_found() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let task_mgr = Arc::new(MockTaskManager::new());

    let conv = svc.create("user_1", make_create_req()).await.unwrap();

    let agent = AgentInstance::Mock(Arc::new(MockAgent::with_confirmations(
        &conv.id,
        make_test_confirmations(),
    )));
    task_mgr.insert_agent(&conv.id, agent);

    let req = qianji_api_types::ConfirmRequest {
        msg_id: "msg-1".into(),
        data: json!({ "value": "allow" }),
        always_allow: false,
    };
    let err = svc
        .confirm(
            "user_1",
            &conv.id,
            "nonexistent-call",
            req,
            &(task_mgr as Arc<dyn IWorkerTaskManager>),
        )
        .await
        .unwrap_err();
    assert!(matches!(err, ConversationError::NotFoundReason { .. }));
}

#[tokio::test]
async fn confirm_without_confirmation_state_still_calls_agent() {
    let (svc, broadcaster, _repo, _task_mgr) = make_service();
    let task_mgr = Arc::new(MockTaskManager::new());

    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    broadcaster.take_events();

    let agent = AgentInstance::Mock(Arc::new(MockAgent::with_direct_confirm(&conv.id)));
    task_mgr.insert_agent(&conv.id, agent);

    let req = qianji_api_types::ConfirmRequest {
        msg_id: "msg-1".into(),
        data: json!("allow_once"),
        always_allow: false,
    };
    svc.confirm(
        "user_1",
        &conv.id,
        "call-1",
        req,
        &(task_mgr.clone() as Arc<dyn IWorkerTaskManager>),
    )
    .await
    .unwrap();

    assert!(broadcaster.take_events().is_empty());
}

#[tokio::test]
async fn confirm_no_agent_returns_not_found() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let task_mgr: Arc<dyn IWorkerTaskManager> = Arc::new(MockTaskManager::new());

    let conv = svc.create("user_1", make_create_req()).await.unwrap();

    let req = qianji_api_types::ConfirmRequest {
        msg_id: "msg-1".into(),
        data: json!({ "value": "allow" }),
        always_allow: false,
    };
    let err = svc
        .confirm("user_1", &conv.id, "call-1", req, &task_mgr)
        .await
        .unwrap_err();
    assert!(matches!(err, ConversationError::ActiveAgentNotFound { .. }));
}

#[tokio::test]
async fn check_approval_returns_false_when_not_set() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let task_mgr = Arc::new(MockTaskManager::new());

    let conv = svc.create("user_1", make_create_req()).await.unwrap();

    let agent = AgentInstance::Mock(Arc::new(MockAgent::new(&conv.id)));
    task_mgr.insert_agent(&conv.id, agent);

    let result = svc
        .check_approval(
            "user_1",
            &conv.id,
            "edit_file",
            None,
            &(task_mgr as Arc<dyn IWorkerTaskManager>),
        )
        .await
        .unwrap();
    assert!(!result.approved);
}

#[tokio::test]
async fn check_approval_returns_true_after_always_allow() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let task_mgr = Arc::new(MockTaskManager::new());

    let conv = svc.create("user_1", make_create_req()).await.unwrap();

    let agent = AgentInstance::Mock(Arc::new(MockAgent::with_confirmations(
        &conv.id,
        make_test_confirmations(),
    )));
    task_mgr.insert_agent(&conv.id, agent);

    // Confirm with always_allow
    let req = qianji_api_types::ConfirmRequest {
        msg_id: "msg-1".into(),
        data: json!({ "value": "allow" }),
        always_allow: true,
    };
    let task_mgr_arc: Arc<dyn IWorkerTaskManager> = task_mgr.clone();
    svc.confirm("user_1", &conv.id, "call-1", req, &task_mgr_arc)
        .await
        .unwrap();

    // Now check_approval should return true
    let result = svc
        .check_approval("user_1", &conv.id, "edit_file", Some("bash"), &task_mgr_arc)
        .await
        .unwrap();
    assert!(result.approved);
}

#[tokio::test]
async fn check_approval_returns_false_when_no_agent() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let task_mgr: Arc<dyn IWorkerTaskManager> = Arc::new(MockTaskManager::new());

    let conv = svc.create("user_1", make_create_req()).await.unwrap();

    let result = svc
        .check_approval("user_1", &conv.id, "edit_file", None, &task_mgr)
        .await
        .unwrap();
    assert!(!result.approved);
}

#[tokio::test]
async fn check_approval_not_found() {
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let task_mgr: Arc<dyn IWorkerTaskManager> = Arc::new(MockTaskManager::new());

    let err = svc
        .check_approval("user_1", "no-such-id", "edit_file", None, &task_mgr)
        .await
        .unwrap_err();
    assert!(matches!(err, ConversationError::NotFound { .. }));
}

// ── Skill snapshot tests ───────────────────────────────────────────

#[tokio::test]
async fn create_writes_extra_skills_from_auto_inject_and_preset() {
    let resolver = Arc::new(FixedSkillResolver {
        names: vec!["cron".into(), "todo-tracker".into()],
    });
    let (svc, _broadcaster, _repo, _task_mgr) = make_service_with_resolver(resolver);
    let workspace = ensure_test_workspace_path();

    let req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "acp",
        "name": "t",
        "extra": {
            "workspace": workspace,
            "backend": "claude",
            "preset_enabled_skills": ["pdf", "cron"],
            "exclude_auto_inject_skills": ["todo-tracker"],
        },
    }))
    .unwrap();
    let resp = svc.create("user-1", req).await.unwrap();

    assert_eq!(resp.extra["skills"], json!(["cron", "pdf"]));
    assert!(resp.extra.get("preset_enabled_skills").is_none());
    assert!(resp.extra.get("exclude_auto_inject_skills").is_none());
}

#[tokio::test]
async fn create_resolves_assistant_snapshot_and_updates_preferences() {
    let resolver = Arc::new(FixedSkillResolver {
        names: vec!["cron".into(), "todo-tracker".into()],
    });
    let dispatcher = Arc::new(StaticAssistantDispatcher {
        rules: std::collections::HashMap::from([("preset-1".to_string(), "assistant rule body".to_string())]),
    });
    let (svc, _broadcaster, repo, definition_repo, state_repo, preference_repo) =
        make_service_with_assistant_support(resolver, dispatcher).await;
    let workspace = ensure_test_workspace_path();

    definition_repo
        .upsert(&UpsertAssistantDefinitionParams {
            id: "asstdef_preset_1",
            assistant_id: "preset-1",
            source: "builtin",
            owner_type: "system",
            source_ref: Some("preset-1"),
            name: "Preset",
            name_i18n: "{}",
            description: Some("desc"),
            description_i18n: "{}",
            avatar_type: "emoji",
            avatar_value: Some("🤖"),
            agent_id: "claude",
            rule_resource_type: "builtin_asset",
            rule_resource_ref: Some("preset-1"),
            recommended_prompts: "[]",
            recommended_prompts_i18n: "{}",
            default_model_mode: "auto",
            default_model_value: None,
            default_permission_mode: "auto",
            default_permission_value: None,
            default_thought_level_mode: "auto",
            default_thought_level_value: None,
            default_skills_mode: "auto",
            default_skill_ids: "[]",
            custom_skill_names: "[]",
            default_disabled_builtin_skill_ids: "[]",
            default_mcps_mode: "auto",
            default_mcp_ids: "[]",
        })
        .await
        .unwrap();
    state_repo
        .upsert_for_user(
            "user-1",
            &UpsertAssistantOverlayParams {
                assistant_definition_id: "asstdef_preset_1",
                enabled: true,
                sort_order: 0,
                agent_id_override: Some("codex"),
                last_used_at: None,
            },
        )
        .await
        .unwrap();
    preference_repo
        .upsert_for_user(
            "user-1",
            &UpsertAssistantPreferenceParams {
                assistant_definition_id: "asstdef_preset_1",
                last_model_id: Some("old-model"),
                last_permission_value: Some("workspace-write"),
                last_thought_level_value: Some("high"),
                last_skill_ids: r#"["legacy-skill"]"#,
                last_disabled_builtin_skill_ids: r#"["legacy-disabled"]"#,
                last_mcp_ids: r#"["legacy-mcp"]"#,
            },
        )
        .await
        .unwrap();

    let req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "acp",
        "name": "t",
        "assistant": {
            "id": "preset-1",
            "locale": "zh-CN",
            "conversation_overrides": {
                "model": "new-model",
                "skill_ids": ["pdf"],
                "disabled_builtin_skill_ids": ["todo-tracker"],
            }
        },
        "extra": {
            "workspace": workspace,
            "backend": "claude"
        },
    }))
    .unwrap();
    let resp = svc.create("user-1", req).await.unwrap();

    assert_eq!(
        resp.assistant,
        Some(qianji_api_types::ConversationAssistantIdentityResponse {
            id: "preset-1".into(),
            source: "builtin".into(),
            name: "Preset".into(),
            avatar: "🤖".into(),
            backend: "codex".into(),
        })
    );
    assert!(resp.extra.get("assistant_id").is_none());
    assert_eq!(resp.extra["agent_id"], json!("8e1acf31"));
    assert_eq!(resp.extra["agent_source"], json!("builtin"));
    assert!(resp.extra.get("preset_assistant_id").is_none());
    assert!(resp.extra.get("preset_context").is_none());
    assert!(resp.extra.get("preset_rules").is_none());
    assert_eq!(resp.extra["session_mode"], json!("workspace-write"));
    assert_eq!(resp.extra["current_mode_id"], json!("workspace-write"));
    assert_eq!(resp.extra["current_model_id"], json!("new-model"));
    assert_eq!(resp.extra["skills"], json!(["cron", "pdf"]));
    assert!(resp.extra.get("assistant_snapshot").is_none());

    let snapshot = repo.get_assistant_snapshot("user_1", &resp.id).await.unwrap().unwrap();
    assert_eq!(snapshot.assistant_definition_id, "asstdef_preset_1");
    assert_eq!(snapshot.assistant_id, "preset-1");
    assert_eq!(snapshot.agent_id, "8e1acf31");
    assert_eq!(snapshot.rules_content, "assistant rule body");
    assert_eq!(snapshot.default_model_mode, "auto");
    assert_eq!(snapshot.resolved_model_id.as_deref(), Some("new-model"));
    assert_eq!(snapshot.default_skills_mode, "auto");
    assert_eq!(snapshot.resolved_skill_ids, r#"["pdf"]"#);

    let updated_pref = preference_repo
        .get_for_user("user-1", "asstdef_preset_1")
        .await
        .unwrap()
        .unwrap();
    assert_eq!(updated_pref.last_model_id.as_deref(), Some("new-model"));
    assert_eq!(updated_pref.last_skill_ids, r#"["pdf"]"#);
    assert_eq!(updated_pref.last_disabled_builtin_skill_ids, r#"["todo-tracker"]"#);

    let fetched = svc.get("user-1", &resp.id).await.unwrap();
    assert_eq!(
        fetched.assistant,
        Some(qianji_api_types::ConversationAssistantIdentityResponse {
            id: "preset-1".into(),
            source: "builtin".into(),
            name: "Preset".into(),
            avatar: "🤖".into(),
            backend: "codex".into(),
        })
    );

    let listed = svc
        .list(
            "user-1",
            ListConversationsQuery {
                cursor: None,
                limit: Some(20),
                source: None,
                cron_job_id: None,
                pinned: None,
            },
        )
        .await
        .unwrap();
    assert_eq!(
        listed.items[0].assistant,
        Some(qianji_api_types::ConversationAssistantIdentityResponse {
            id: "preset-1".into(),
            source: "builtin".into(),
            name: "Preset".into(),
            avatar: "🤖".into(),
            backend: "codex".into(),
        })
    );
}

#[tokio::test]
async fn existing_conversation_reads_current_assistant_identity() {
    let resolver = Arc::new(FixedSkillResolver { names: vec![] });
    let dispatcher = Arc::new(StaticAssistantDispatcher {
        rules: std::collections::HashMap::new(),
    });
    let (svc, _broadcaster, _repo, definition_repo, state_repo, _preference_repo) =
        make_service_with_assistant_support(resolver, dispatcher).await;
    let workspace = ensure_test_workspace_path();

    definition_repo
        .upsert_for_user(
            "user-1",
            &UpsertAssistantDefinitionParams {
                id: "asstdef_live_identity",
                assistant_id: "live-identity",
                source: "user",
                owner_type: "user",
                source_ref: Some("live-identity"),
                name: "Old Name",
                name_i18n: "{}",
                description: None,
                description_i18n: "{}",
                avatar_type: "emoji",
                avatar_value: Some("🤖"),
                agent_id: "claude",
                rule_resource_type: "none",
                rule_resource_ref: None,
                recommended_prompts: "[]",
                recommended_prompts_i18n: "{}",
                default_model_mode: "auto",
                default_model_value: None,
                default_permission_mode: "auto",
                default_permission_value: None,
                default_thought_level_mode: "auto",
                default_thought_level_value: None,
                default_skills_mode: "auto",
                default_skill_ids: "[]",
                custom_skill_names: "[]",
                default_disabled_builtin_skill_ids: "[]",
                default_mcps_mode: "auto",
                default_mcp_ids: "[]",
            },
        )
        .await
        .unwrap();
    state_repo
        .upsert_for_user(
            "user-1",
            &UpsertAssistantOverlayParams {
                assistant_definition_id: "asstdef_live_identity",
                enabled: true,
                sort_order: 0,
                agent_id_override: None,
                last_used_at: None,
            },
        )
        .await
        .unwrap();

    let req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "acp",
        "name": "t",
        "assistant": { "id": "live-identity" },
        "extra": {
            "workspace": workspace,
            "backend": "claude"
        },
    }))
    .unwrap();
    let created = svc.create("user-1", req).await.unwrap();

    definition_repo
        .upsert_for_user(
            "user-1",
            &UpsertAssistantDefinitionParams {
                id: "asstdef_live_identity",
                assistant_id: "live-identity",
                source: "user",
                owner_type: "user",
                source_ref: Some("live-identity"),
                name: "New Name",
                name_i18n: "{}",
                description: None,
                description_i18n: "{}",
                avatar_type: "emoji",
                avatar_value: Some("🧪"),
                agent_id: "claude",
                rule_resource_type: "none",
                rule_resource_ref: None,
                recommended_prompts: "[]",
                recommended_prompts_i18n: "{}",
                default_model_mode: "auto",
                default_model_value: None,
                default_permission_mode: "auto",
                default_permission_value: None,
                default_thought_level_mode: "auto",
                default_thought_level_value: None,
                default_skills_mode: "auto",
                default_skill_ids: "[]",
                custom_skill_names: "[]",
                default_disabled_builtin_skill_ids: "[]",
                default_mcps_mode: "auto",
                default_mcp_ids: "[]",
            },
        )
        .await
        .unwrap();

    let fetched = svc.get("user-1", &created.id).await.unwrap();
    assert_eq!(
        fetched.assistant,
        Some(qianji_api_types::ConversationAssistantIdentityResponse {
            id: "live-identity".into(),
            source: "user".into(),
            name: "New Name".into(),
            avatar: "🧪".into(),
            backend: "claude".into(),
        })
    );

    let listed = svc
        .list(
            "user-1",
            ListConversationsQuery {
                cursor: None,
                limit: Some(20),
                source: None,
                cron_job_id: None,
                pinned: None,
            },
        )
        .await
        .unwrap();
    assert_eq!(listed.items[0].assistant, fetched.assistant);
}

#[tokio::test]
async fn create_routes_asset_avatar_in_assistant_identity_through_backend() {
    let dispatcher = Arc::new(StaticAssistantDispatcher {
        rules: std::collections::HashMap::new(),
    });
    let (svc, _broadcaster, _repo, definition_repo, state_repo, _preference_repo) =
        make_service_with_assistant_support(Arc::new(FixedSkillResolver { names: vec![] }), dispatcher).await;
    let workspace = ensure_test_workspace_path();

    definition_repo
        .upsert_for_user(
            "user-1",
            &UpsertAssistantDefinitionParams {
                id: "asstdef_data_avatar",
                assistant_id: "custom-data-avatar",
                source: "user",
                owner_type: "user",
                source_ref: Some("custom-data-avatar"),
                name: "Data Avatar",
                name_i18n: "{}",
                description: None,
                description_i18n: "{}",
                avatar_type: "user_asset",
                avatar_value: Some("data:image/svg+xml;base64,PHN2Zy8+"),
                agent_id: "claude",
                rule_resource_type: "none",
                rule_resource_ref: None,
                recommended_prompts: "[]",
                recommended_prompts_i18n: "{}",
                default_model_mode: "auto",
                default_model_value: None,
                default_permission_mode: "auto",
                default_permission_value: None,
                default_thought_level_mode: "auto",
                default_thought_level_value: None,
                default_skills_mode: "auto",
                default_skill_ids: "[]",
                custom_skill_names: "[]",
                default_disabled_builtin_skill_ids: "[]",
                default_mcps_mode: "auto",
                default_mcp_ids: "[]",
            },
        )
        .await
        .unwrap();
    state_repo
        .upsert_for_user(
            "user-1",
            &UpsertAssistantOverlayParams {
                assistant_definition_id: "asstdef_data_avatar",
                enabled: true,
                sort_order: 0,
                agent_id_override: None,
                last_used_at: None,
            },
        )
        .await
        .unwrap();

    let req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "acp",
        "name": "t",
        "assistant": { "id": "custom-data-avatar" },
        "extra": {
            "workspace": workspace,
            "backend": "claude"
        },
    }))
    .unwrap();

    let resp = svc.create("user-1", req).await.unwrap();

    assert_eq!(
        resp.assistant.as_ref().map(|assistant| assistant.avatar.as_str()),
        Some("/api/assistants/custom-data-avatar/avatar")
    );
}

#[tokio::test]
async fn assistant_backed_acp_build_options_include_snapshot_rule_as_preset_context() {
    let resolver = Arc::new(FixedSkillResolver { names: vec![] });
    let dispatcher = Arc::new(StaticAssistantDispatcher {
        rules: std::collections::HashMap::from([("preset-acp-rule".to_string(), "assistant rule body".to_string())]),
    });
    let (svc, _broadcaster, repo, definition_repo, state_repo, _preference_repo) =
        make_service_with_assistant_support(resolver, dispatcher).await;

    upsert_test_assistant_definition(
        &definition_repo,
        "asstdef_preset_acp_rule",
        "preset-acp-rule",
        "codex",
        "auto",
        "auto",
    )
    .await;
    state_repo
        .upsert(&UpsertAssistantOverlayParams {
            assistant_definition_id: "asstdef_preset_acp_rule",
            enabled: true,
            sort_order: 0,
            agent_id_override: None,
            last_used_at: None,
        })
        .await
        .unwrap();

    let conv = create_assistant_backed_conversation(&svc, "user_1", Some("acp"), "codex", "preset-acp-rule").await;
    let row = repo.get("user_1", &conv.id).await.unwrap().unwrap();
    let options = svc.build_task_options(&row).await.unwrap();

    match options.context.kind {
        AgentSessionKind::Acp(ctx) => {
            assert_eq!(ctx.config.preset_context.as_deref(), Some("assistant rule body"));
        }
        AgentSessionKind::Qianjirs(_) | AgentSessionKind::Antigravity(_) => {
            panic!("test conversation should build ACP options")
        }
    }
}

#[tokio::test]
async fn assistant_backed_qianjirs_build_options_include_snapshot_rule_as_preset_rules() {
    let resolver = Arc::new(FixedSkillResolver { names: vec![] });
    let dispatcher = Arc::new(StaticAssistantDispatcher {
        rules: std::collections::HashMap::from([(
            "preset-qianjirs-rule".to_string(),
            "assistant rule body".to_string(),
        )]),
    });
    let (svc, _broadcaster, repo, definition_repo, state_repo, _preference_repo) =
        make_service_with_assistant_support(resolver, dispatcher).await;

    upsert_test_assistant_definition(
        &definition_repo,
        "asstdef_preset_qianjirs_rule",
        "preset-qianjirs-rule",
        "qianjirs",
        "auto",
        "auto",
    )
    .await;
    state_repo
        .upsert(&UpsertAssistantOverlayParams {
            assistant_definition_id: "asstdef_preset_qianjirs_rule",
            enabled: true,
            sort_order: 0,
            agent_id_override: None,
            last_used_at: None,
        })
        .await
        .unwrap();

    let conv =
        create_assistant_backed_conversation(&svc, "user_1", Some("qianjirs"), "qianjirs", "preset-qianjirs-rule")
            .await;
    let row = repo.get("user_1", &conv.id).await.unwrap().unwrap();
    let options = svc.build_task_options(&row).await.unwrap();

    match options.context.kind {
        AgentSessionKind::Acp(_) | AgentSessionKind::Antigravity(_) => {
            panic!("test conversation should build Qianjirs options")
        }
        AgentSessionKind::Qianjirs(ctx) => {
            assert_eq!(ctx.config.preset_rules.as_deref(), Some("assistant rule body"));
        }
    }
}

#[tokio::test]
async fn create_prefers_assistant_snapshot_over_legacy_runtime_seed_fields() {
    let resolver = Arc::new(FixedSkillResolver {
        names: vec!["cron".into(), "todo-tracker".into()],
    });
    let dispatcher = Arc::new(StaticAssistantDispatcher {
        rules: std::collections::HashMap::from([("preset-1".to_string(), "assistant rule body".to_string())]),
    });
    let (svc, _broadcaster, repo, definition_repo, state_repo, preference_repo) =
        make_service_with_assistant_support(resolver, dispatcher).await;
    let workspace = ensure_test_workspace_path();

    definition_repo
        .upsert(&UpsertAssistantDefinitionParams {
            id: "asstdef_preset_legacy_seed",
            assistant_id: "preset-1",
            source: "builtin",
            owner_type: "system",
            source_ref: Some("preset-1"),
            name: "Preset",
            name_i18n: "{}",
            description: Some("desc"),
            description_i18n: "{}",
            avatar_type: "emoji",
            avatar_value: Some("🤖"),
            agent_id: "claude",
            rule_resource_type: "builtin_asset",
            rule_resource_ref: Some("preset-1"),
            recommended_prompts: "[]",
            recommended_prompts_i18n: "{}",
            default_model_mode: "auto",
            default_model_value: None,
            default_permission_mode: "auto",
            default_permission_value: None,
            default_thought_level_mode: "auto",
            default_thought_level_value: None,
            default_skills_mode: "auto",
            default_skill_ids: "[]",
            custom_skill_names: "[]",
            default_disabled_builtin_skill_ids: "[]",
            default_mcps_mode: "auto",
            default_mcp_ids: "[]",
        })
        .await
        .unwrap();
    state_repo
        .upsert_for_user(
            "user-1",
            &UpsertAssistantOverlayParams {
                assistant_definition_id: "asstdef_preset_legacy_seed",
                enabled: true,
                sort_order: 0,
                agent_id_override: Some("codex"),
                last_used_at: None,
            },
        )
        .await
        .unwrap();
    preference_repo
        .upsert_for_user(
            "user-1",
            &UpsertAssistantPreferenceParams {
                assistant_definition_id: "asstdef_preset_legacy_seed",
                last_model_id: Some("preferred-model"),
                last_permission_value: Some("workspace-write"),
                last_thought_level_value: Some("medium"),
                last_skill_ids: r#"["legacy-skill"]"#,
                last_disabled_builtin_skill_ids: r#"["legacy-disabled"]"#,
                last_mcp_ids: r#"["legacy-mcp"]"#,
            },
        )
        .await
        .unwrap();

    let req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "acp",
        "name": "t",
        "assistant": {
            "id": "preset-1",
            "locale": "zh-CN",
            "conversation_overrides": {
                "model": "override-model"
            }
        },
        "extra": {
            "workspace": workspace,
            "backend": "claude",
            "current_model_id": "legacy-model",
            "session_mode": "legacy-mode",
            "current_mode_id": "legacy-mode"
        },
    }))
    .unwrap();
    let resp = svc.create("user-1", req).await.unwrap();

    assert_eq!(resp.extra["current_model_id"], json!("override-model"));
    assert_eq!(resp.extra["session_mode"], json!("workspace-write"));
    assert_eq!(resp.extra["current_mode_id"], json!("workspace-write"));

    let snapshot = repo.get_assistant_snapshot("user_1", &resp.id).await.unwrap().unwrap();
    assert_eq!(snapshot.agent_id, "8e1acf31");
    assert_eq!(snapshot.resolved_model_id.as_deref(), Some("override-model"));
    assert_eq!(snapshot.resolved_permission_value.as_deref(), Some("workspace-write"));
}

#[tokio::test]
async fn create_prefers_snapshot_runtime_identity_over_legacy_extra_identity() {
    let resolver = Arc::new(FixedSkillResolver { names: vec![] });
    let dispatcher = Arc::new(StaticAssistantDispatcher {
        rules: std::collections::HashMap::new(),
    });
    let acp_repo = Arc::new(StubAcpSessionRepo::default());
    let (svc, _broadcaster, _repo, definition_repo, overlay_repo, _preference_repo, acp_repo) =
        make_service_with_assistant_support_and_acp_session_repo(resolver, dispatcher, acp_repo).await;

    upsert_test_assistant_definition(
        &definition_repo,
        "asstdef_snapshot_identity",
        "preset-snapshot-identity",
        "codex",
        "auto",
        "auto",
    )
    .await;
    overlay_repo
        .upsert_for_user(
            "user-1",
            &UpsertAssistantOverlayParams {
                assistant_definition_id: "asstdef_snapshot_identity",
                enabled: true,
                sort_order: 0,
                agent_id_override: None,
                last_used_at: None,
            },
        )
        .await
        .unwrap();

    let workspace = ensure_test_workspace_path();
    let req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "acp",
        "assistant": {
            "id": "preset-snapshot-identity",
            "locale": "en-US"
        },
        "extra": {
            "workspace": workspace,
            "backend": "claude",
            "agent_source": "custom",
            "agent_id": "legacy-custom-agent"
        },
    }))
    .unwrap();

    let resp = svc.create("user-1", req).await.unwrap();

    assert_eq!(
        resp.assistant.as_ref().map(|assistant| assistant.backend.as_str()),
        Some("codex")
    );
    assert_eq!(resp.extra["backend"], json!("codex"));
    assert_eq!(resp.extra["agent_id"], json!("8e1acf31"));

    let create_calls = acp_repo.create_calls();
    assert_eq!(create_calls.len(), 1);
    assert_eq!(create_calls[0].user_id, "user-1");
    assert_eq!(create_calls[0].agent_id, "8e1acf31");
    assert_eq!(create_calls[0].agent_source, "builtin");
    assert_eq!(create_calls[0].agent_id, "8e1acf31");
}

#[tokio::test]
async fn create_does_not_overwrite_preferences_for_fixed_skills_and_mcps() {
    let resolver = Arc::new(FixedSkillResolver {
        names: vec!["cron".into(), "todo-tracker".into()],
    });
    let dispatcher = Arc::new(StaticAssistantDispatcher {
        rules: std::collections::HashMap::from([("preset-fixed".to_string(), "assistant rule body".to_string())]),
    });
    let (svc, _broadcaster, _repo, definition_repo, state_repo, preference_repo) =
        make_service_with_assistant_support(resolver, dispatcher).await;
    let workspace = ensure_test_workspace_path();

    definition_repo
        .upsert(&UpsertAssistantDefinitionParams {
            id: "asstdef_preset_fixed",
            assistant_id: "preset-fixed",
            source: "builtin",
            owner_type: "system",
            source_ref: Some("preset-fixed"),
            name: "Preset Fixed",
            name_i18n: "{}",
            description: Some("desc"),
            description_i18n: "{}",
            avatar_type: "emoji",
            avatar_value: Some("🤖"),
            agent_id: "claude",
            rule_resource_type: "builtin_asset",
            rule_resource_ref: Some("preset-fixed"),
            recommended_prompts: "[]",
            recommended_prompts_i18n: "{}",
            default_model_mode: "auto",
            default_model_value: None,
            default_permission_mode: "auto",
            default_permission_value: None,
            default_thought_level_mode: "auto",
            default_thought_level_value: None,
            default_skills_mode: "fixed",
            default_skill_ids: r#"["pdf"]"#,
            custom_skill_names: "[]",
            default_disabled_builtin_skill_ids: r#"["todo-tracker"]"#,
            default_mcps_mode: "fixed",
            default_mcp_ids: r#"["mcp-fixed"]"#,
        })
        .await
        .unwrap();
    state_repo
        .upsert_for_user(
            "user-1",
            &UpsertAssistantOverlayParams {
                assistant_definition_id: "asstdef_preset_fixed",
                enabled: true,
                sort_order: 0,
                agent_id_override: Some("codex"),
                last_used_at: None,
            },
        )
        .await
        .unwrap();
    preference_repo
        .upsert_for_user(
            "user-1",
            &UpsertAssistantPreferenceParams {
                assistant_definition_id: "asstdef_preset_fixed",
                last_model_id: Some("legacy-model"),
                last_permission_value: Some("workspace-write"),
                last_thought_level_value: Some("legacy-thought"),
                last_skill_ids: r#"["legacy-skill"]"#,
                last_disabled_builtin_skill_ids: r#"["legacy-disabled"]"#,
                last_mcp_ids: r#"["legacy-mcp"]"#,
            },
        )
        .await
        .unwrap();

    let req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "acp",
        "name": "t",
        "assistant": {
            "id": "preset-fixed",
            "locale": "zh-CN",
            "conversation_overrides": {
                "model": "new-model",
                "permission": "workspace-read",
                "skill_ids": ["pdf", "cron"],
                "disabled_builtin_skill_ids": [],
                "mcp_ids": ["mcp-temp"]
            }
        },
        "extra": {
            "workspace": workspace,
            "backend": "claude"
        },
    }))
    .unwrap();
    let _resp = svc.create("user-1", req).await.unwrap();

    let updated_pref = preference_repo
        .get_for_user("user-1", "asstdef_preset_fixed")
        .await
        .unwrap()
        .unwrap();
    assert_eq!(updated_pref.last_model_id.as_deref(), Some("new-model"));
    assert_eq!(updated_pref.last_permission_value.as_deref(), Some("workspace-read"));
    assert_eq!(updated_pref.last_skill_ids, r#"["legacy-skill"]"#);
    assert_eq!(updated_pref.last_disabled_builtin_skill_ids, r#"["legacy-disabled"]"#);
    assert_eq!(updated_pref.last_mcp_ids, r#"["legacy-mcp"]"#);
}

#[tokio::test]
async fn create_with_auto_builtin_defaults_without_preferences_keeps_snapshot_values_empty() {
    let resolver = Arc::new(FixedSkillResolver {
        names: vec!["cron".into(), "todo-tracker".into()],
    });
    let dispatcher = Arc::new(StaticAssistantDispatcher {
        rules: std::collections::HashMap::from([("preset-auto".to_string(), "assistant rule body".to_string())]),
    });
    let (svc, _broadcaster, _repo, definition_repo, state_repo, preference_repo) =
        make_service_with_assistant_support(resolver, dispatcher).await;
    let workspace = ensure_test_workspace_path();

    definition_repo
        .upsert(&UpsertAssistantDefinitionParams {
            id: "asstdef_preset_auto",
            assistant_id: "preset-auto",
            source: "builtin",
            owner_type: "system",
            source_ref: Some("preset-auto"),
            name: "Preset Unset",
            name_i18n: "{}",
            description: Some("desc"),
            description_i18n: "{}",
            avatar_type: "emoji",
            avatar_value: Some("🤖"),
            agent_id: "claude",
            rule_resource_type: "builtin_asset",
            rule_resource_ref: Some("preset-auto"),
            recommended_prompts: "[]",
            recommended_prompts_i18n: "{}",
            default_model_mode: "auto",
            default_model_value: None,
            default_permission_mode: "auto",
            default_permission_value: None,
            default_thought_level_mode: "auto",
            default_thought_level_value: None,
            default_skills_mode: "fixed",
            default_skill_ids: r#"["pdf"]"#,
            custom_skill_names: "[]",
            default_disabled_builtin_skill_ids: "[]",
            default_mcps_mode: "auto",
            default_mcp_ids: "[]",
        })
        .await
        .unwrap();
    state_repo
        .upsert_for_user(
            "user-1",
            &UpsertAssistantOverlayParams {
                assistant_definition_id: "asstdef_preset_auto",
                enabled: true,
                sort_order: 0,
                agent_id_override: Some("codex"),
                last_used_at: None,
            },
        )
        .await
        .unwrap();
    preference_repo
        .upsert_for_user(
            "user-1",
            &UpsertAssistantPreferenceParams {
                assistant_definition_id: "asstdef_preset_auto",
                last_model_id: None,
                last_permission_value: None,
                last_thought_level_value: None,
                last_skill_ids: "[]",
                last_disabled_builtin_skill_ids: "[]",
                last_mcp_ids: "[]",
            },
        )
        .await
        .unwrap();

    let req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "acp",
        "name": "t",
        "assistant": {
            "id": "preset-auto",
            "locale": "zh-CN"
        },
        "extra": {
            "workspace": workspace,
            "backend": "claude"
        },
    }))
    .unwrap();
    let resp = svc.create("user-1", req).await.unwrap();

    assert!(resp.extra.get("current_model_id").is_none());
    assert!(resp.extra.get("permission_mode").is_none());
    assert!(resp.extra.get("assistant_snapshot").is_none());

    let updated_pref = preference_repo
        .get_for_user("user-1", "asstdef_preset_auto")
        .await
        .unwrap()
        .unwrap();
    assert_eq!(updated_pref.last_model_id, None);
    assert_eq!(updated_pref.last_permission_value, None);
    assert_eq!(updated_pref.last_mcp_ids, "[]");
}

#[tokio::test]
async fn create_writes_empty_skills_when_no_auto_inject_and_no_preset() {
    let resolver = Arc::new(FixedSkillResolver { names: vec![] });
    let (svc, _broadcaster, _repo, _task_mgr) = make_service_with_resolver(resolver);
    let workspace = ensure_test_workspace_path();

    let req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "acp",
        "extra": { "workspace": workspace, "backend": "claude" },
    }))
    .unwrap();
    let resp = svc.create("user-1", req).await.unwrap();

    assert_eq!(resp.extra["skills"], json!([]));
}

/// Rewritten from `create_links_skills_into_custom_workspace_for_native_acp_agent`.
/// The old assertion (`workspace.join(".claude/skills/cron").is_dir()`) encoded
/// exactly the behaviour this refactor removes, so the SAME scenario now asserts
/// its replacement: nothing in the workspace, everything in the view.
#[tokio::test]
async fn create_puts_skills_in_the_view_not_in_a_custom_workspace() {
    let resolver = Arc::new(RecordingSkillResolver::new(vec!["cron".into()]));
    let views = resolver.views.clone();
    let (svc, _broadcaster, _repo, _task_mgr) =
        make_service_with_resolver_and_agent_metadata_repo(resolver, Arc::new(ClaudeNativeSkillMetadataRepo));
    let workspace = unique_test_workspace_path("custom-create");

    let req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "acp",
        "extra": {
            "workspace": workspace,
            "backend": "claude"
        },
    }))
    .unwrap();
    let resp = svc.create("user-1", req).await.unwrap();

    assert_eq!(
        resp.extra["skills"],
        json!(["cron"]),
        "snapshot semantics are unchanged"
    );
    assert!(
        !workspace.join(".claude").exists(),
        "G1: skill delivery must create nothing in a user-selected workspace"
    );
    let calls = views.lock().unwrap();
    assert_eq!(calls.len(), 1);
    assert_eq!(calls[0].skill_names, vec!["cron"]);
}

/// Rewritten from `warmup_restores_skill_links_for_recreated_auto_workspace`.
/// The recovery property is preserved -- it now recovers the VIEW.
#[tokio::test]
async fn warmup_rebuilds_the_skill_view_for_a_recreated_auto_workspace() {
    let resolver = Arc::new(RecordingSkillResolver::new(vec!["cron".into()]));
    let views = resolver.views.clone();
    let (svc, _broadcaster, _repo, _task_mgr) = make_service_with_resolver(resolver);

    let req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "qianjirs",
        "extra": {},
    }))
    .unwrap();
    let resp = svc.create("user-1", req).await.unwrap();
    let workspace = PathBuf::from(resp.extra["workspace"].as_str().unwrap());
    assert!(
        !workspace.join(".qianjirs").exists(),
        "G1 holds for auto-provisioned workspaces too, not only user-selected ones"
    );

    std::fs::remove_dir_all(&workspace).unwrap();
    views.lock().unwrap().clear();

    let task_mgr: Arc<dyn IWorkerTaskManager> =
        Arc::new(MockTaskManagerWithWorkspace::new(workspace.to_str().unwrap()));
    svc.warmup("user-1", &resp.id, &task_mgr).await.unwrap();

    let calls = views.lock().unwrap();
    assert_eq!(calls.len(), 1, "warmup re-syncs the view");
    assert_eq!(calls[0].skill_names, vec!["cron"]);
    assert!(!workspace.join(".qianjirs").exists(), "and still writes nothing there");
}

/// Rewritten from `warmup_restores_skill_links_for_custom_workspace`.
#[tokio::test]
async fn warmup_rebuilds_the_skill_view_for_a_custom_workspace() {
    let resolver = Arc::new(RecordingSkillResolver::new(vec!["cron".into()]));
    let views = resolver.views.clone();
    let (svc, _broadcaster, _repo, _task_mgr) =
        make_service_with_resolver_and_agent_metadata_repo(resolver, Arc::new(ClaudeNativeSkillMetadataRepo));
    let workspace = unique_test_workspace_path("custom-warmup");

    let req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "acp",
        "extra": {
            "workspace": workspace,
            "backend": "claude"
        },
    }))
    .unwrap();
    let resp = svc.create("user-1", req).await.unwrap();
    views.lock().unwrap().clear();

    let task_mgr: Arc<dyn IWorkerTaskManager> =
        Arc::new(MockTaskManagerWithWorkspace::new(workspace.to_str().unwrap()));
    svc.warmup("user-1", &resp.id, &task_mgr).await.unwrap();

    let calls = views.lock().unwrap();
    assert_eq!(calls.len(), 1);
    assert_eq!(calls[0].skill_names, vec!["cron"]);
    assert!(
        !workspace.join(".claude").exists(),
        "G1: still nothing in the workspace"
    );
}

// ── G1 regression: the workspace is never written to ────────────────
//
// The single most important assertion in this refactor. Qianji's skill delivery
// used to symlink into `{workspace}/.claude/skills` and friends -- for BOTH
// temp and user-selected workspaces, the latter frequently being a git
// repository. The directories were never cleaned up, a manual delete was
// re-created on the next build, and a failed symlink degraded into copying real
// files in.
//
// Scope: the SKILL DELIVERY path. There is exactly one acknowledged exception,
// `.agents/hooks.json`, written by `qianji-ai-agent`'s antigravity hook -- it is
// agy's PreToolUse permission gate and load-bearing, so removing it would
// silently downgrade agy's security. It is whitelisted BY NAME below, so any
// OTHER new workspace write still fails these tests.

const G1_ALLOWED_WORKSPACE_PATHS: &[&str] = &[".agents", ".agents/hooks.json"];

fn workspace_snapshot(root: &Path) -> std::collections::BTreeSet<String> {
    fn walk(root: &Path, dir: &Path, out: &mut std::collections::BTreeSet<String>) {
        let Ok(entries) = std::fs::read_dir(dir) else { return };
        for entry in entries.flatten() {
            let path = entry.path();
            let rel = path.strip_prefix(root).unwrap().to_string_lossy().replace('\\', "/");
            out.insert(rel);
            // `symlink_metadata`, never `metadata`: descending THROUGH a link
            // would pull a linked skill's own files into the snapshot and make
            // this test report changes that are not the workspace's.
            if path.symlink_metadata().map(|m| m.is_dir()).unwrap_or(false) {
                walk(root, &path, out);
            }
        }
    }
    let mut out = std::collections::BTreeSet::new();
    walk(root, root, &mut out);
    out
}

fn assert_workspace_unchanged(before: &std::collections::BTreeSet<String>, after: &std::collections::BTreeSet<String>) {
    let added: Vec<&String> = after
        .difference(before)
        .filter(|path| !G1_ALLOWED_WORKSPACE_PATHS.contains(&path.as_str()))
        .collect();
    let removed: Vec<&String> = before.difference(after).collect();
    assert!(added.is_empty(), "Qianji created files in the workspace: {added:?}");
    assert!(
        removed.is_empty(),
        "Qianji removed files from the workspace: {removed:?}"
    );
}

/// A USER-SELECTED workspace with pre-existing content, including the user's OWN
/// `.claude/skills/` -- the git-repository case that motivated G1.
#[tokio::test]
async fn workspace_is_untouched_for_a_user_selected_workspace() {
    let resolver = Arc::new(RecordingSkillResolver::new(vec!["cron".into(), "officecli".into()]));
    let (svc, _broadcaster, _repo, _task_mgr) =
        make_service_with_resolver_and_agent_metadata_repo(resolver, Arc::new(ClaudeNativeSkillMetadataRepo));
    let workspace = unique_test_workspace_path("g1-user-selected");
    for rel in [
        "src/main.rs",
        ".claude/skills/my-own-skill/SKILL.md",
        "references/workflows.md",
    ] {
        let target = workspace.join(rel);
        std::fs::create_dir_all(target.parent().unwrap()).unwrap();
        std::fs::write(&target, "user content").unwrap();
    }
    let before = workspace_snapshot(&workspace);

    let req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "acp",
        "extra": { "workspace": workspace, "backend": "claude" },
    }))
    .unwrap();
    let resp = svc.create("user-1", req).await.unwrap();
    let task_mgr: Arc<dyn IWorkerTaskManager> =
        Arc::new(MockTaskManagerWithWorkspace::new(workspace.to_str().unwrap()));
    svc.warmup("user-1", &resp.id, &task_mgr).await.unwrap();

    assert_workspace_unchanged(&before, &workspace_snapshot(&workspace));
}

/// The AUTO-PROVISIONED workspace must be covered too. The removed code took it
/// as licence to write ("applies to both temp and user-selected workspaces"), so
/// testing only the user-selected case would miss half the defect.
#[tokio::test]
async fn workspace_is_untouched_for_an_auto_provisioned_workspace() {
    let resolver = Arc::new(RecordingSkillResolver::new(vec!["cron".into()]));
    let (svc, _broadcaster, _repo, _task_mgr) = make_service_with_resolver(resolver);

    let req: CreateConversationRequest = serde_json::from_value(json!({ "type": "qianjirs", "extra": {} })).unwrap();
    let resp = svc.create("user-1", req).await.unwrap();
    let workspace = PathBuf::from(resp.extra["workspace"].as_str().unwrap());
    let before = workspace_snapshot(&workspace);

    let task_mgr: Arc<dyn IWorkerTaskManager> =
        Arc::new(MockTaskManagerWithWorkspace::new(workspace.to_str().unwrap()));
    svc.warmup("user-1", &resp.id, &task_mgr).await.unwrap();

    assert_workspace_unchanged(&before, &workspace_snapshot(&workspace));
}

/// Team members share ONE workspace (the leader's), and the removed code stacked
/// a directory per member per vendor into it. Five conversations of different
/// vendors over one directory is the shape that used to accumulate.
#[tokio::test]
async fn workspace_is_untouched_when_five_vendors_share_one_workspace() {
    let resolver = Arc::new(RecordingSkillResolver::new(vec!["cron".into()]));
    let (svc, _broadcaster, _repo, _task_mgr) =
        make_service_with_resolver_and_agent_metadata_repo(resolver, Arc::new(ClaudeNativeSkillMetadataRepo));
    let workspace = unique_test_workspace_path("g1-team-shared");
    std::fs::write(workspace.join("shared.txt"), "leader content").unwrap();
    let before = workspace_snapshot(&workspace);

    for backend in ["claude", "codex", "codebuddy", "antigravity", "opencode"] {
        let req: CreateConversationRequest = serde_json::from_value(json!({
            "type": "acp",
            "extra": { "workspace": workspace, "backend": backend },
        }))
        .unwrap();
        let resp = svc.create("user-1", req).await.unwrap();
        let task_mgr: Arc<dyn IWorkerTaskManager> =
            Arc::new(MockTaskManagerWithWorkspace::new(workspace.to_str().unwrap()));
        svc.warmup("user-1", &resp.id, &task_mgr).await.unwrap();
    }

    assert_workspace_unchanged(&before, &workspace_snapshot(&workspace));
}

/// A second build must not resurrect the links either: the removed code ran on
/// every build-task, which is why deleting the directories by hand never stuck.
#[tokio::test]
async fn workspace_is_untouched_on_a_second_build() {
    let resolver = Arc::new(RecordingSkillResolver::new(vec!["cron".into()]));
    let (svc, _broadcaster, _repo, _task_mgr) =
        make_service_with_resolver_and_agent_metadata_repo(resolver, Arc::new(ClaudeNativeSkillMetadataRepo));
    let workspace = unique_test_workspace_path("g1-second-build");

    let req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "acp",
        "extra": { "workspace": workspace, "backend": "claude" },
    }))
    .unwrap();
    let resp = svc.create("user-1", req).await.unwrap();
    let task_mgr: Arc<dyn IWorkerTaskManager> =
        Arc::new(MockTaskManagerWithWorkspace::new(workspace.to_str().unwrap()));
    svc.warmup("user-1", &resp.id, &task_mgr).await.unwrap();
    let before = workspace_snapshot(&workspace);

    svc.warmup("user-1", &resp.id, &task_mgr).await.unwrap();

    assert_workspace_unchanged(&before, &workspace_snapshot(&workspace));
}

/// The view directory is the new landing site. This asserts it is built from the
/// snapshot; it says nothing about the workspace yet -- both paths coexist
/// deliberately until the workspace delivery is removed.
#[tokio::test]
async fn create_builds_the_session_skill_view_from_the_snapshot() {
    let resolver = Arc::new(RecordingSkillResolver::new(vec!["cron".into()]));
    let views = resolver.views.clone();
    let (svc, _broadcaster, _repo, _task_mgr) =
        make_service_with_resolver_and_agent_metadata_repo(resolver, Arc::new(ClaudeNativeSkillMetadataRepo));

    let req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "acp",
        "extra": { "workspace": ensure_test_workspace_path(), "backend": "claude" },
    }))
    .unwrap();
    let resp = svc.create("user-1", req).await.unwrap();

    let calls = views.lock().unwrap();
    assert_eq!(calls.len(), 1, "exactly one view rebuild per created conversation");
    assert_eq!(calls[0].user_id, "user-1");
    assert_eq!(calls[0].conversation_id, resp.id);
    assert_eq!(calls[0].skill_names, vec!["cron"]);
}

/// The view is built for EVERY agent, not only for vendors that consume it, so
/// flipping a delivery mode in the registry needs no per-conversation backfill.
/// This agent has no `native_skills_dirs` at all, which used to mean "no skill
/// wiring happens".
#[tokio::test]
async fn create_builds_the_view_even_for_an_agent_without_native_skill_dirs() {
    let resolver = Arc::new(RecordingSkillResolver::new(vec!["cron".into()]));
    let views = resolver.views.clone();
    let (svc, _broadcaster, _repo, _task_mgr) = make_service_with_resolver(resolver);

    let req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "acp",
        "extra": { "workspace": ensure_test_workspace_path(), "backend": "opencode" },
    }))
    .unwrap();
    svc.create("user-1", req).await.unwrap();

    assert_eq!(views.lock().unwrap().len(), 1);
}

/// An empty snapshot must not produce a view rebuild: there is nothing to link,
/// and an empty plugin root would still cost the agent an always-on token line.
#[tokio::test]
async fn create_with_no_skills_does_not_build_a_view() {
    let resolver = Arc::new(RecordingSkillResolver::new(Vec::new()));
    let views = resolver.views.clone();
    let (svc, _broadcaster, _repo, _task_mgr) =
        make_service_with_resolver_and_agent_metadata_repo(resolver, Arc::new(ClaudeNativeSkillMetadataRepo));

    let req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "acp",
        "extra": { "workspace": ensure_test_workspace_path(), "backend": "claude" },
    }))
    .unwrap();
    svc.create("user-1", req).await.unwrap();

    assert!(views.lock().unwrap().is_empty());
}

/// Deleting a conversation must drop its view -- nothing else will, and the
/// owner is only knowable while the row still exists.
#[tokio::test]
async fn deleting_a_conversation_removes_its_skill_view() {
    let resolver = Arc::new(RecordingSkillResolver::new(vec!["cron".into()]));
    let removals = resolver.view_removals.clone();
    let (svc, _broadcaster, _repo, _task_mgr) =
        make_service_with_resolver_and_agent_metadata_repo(resolver, Arc::new(ClaudeNativeSkillMetadataRepo));

    let req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "acp",
        "extra": { "workspace": ensure_test_workspace_path(), "backend": "claude" },
    }))
    .unwrap();
    let resp = svc.create("user-1", req).await.unwrap();
    svc.delete("user-1", &resp.id).await.unwrap();

    let calls = removals.lock().unwrap();
    assert_eq!(calls.len(), 1);
    assert_eq!(calls[0], ("user-1".to_owned(), resp.id.clone()));
}

/// Warmup re-syncs the view idempotently: build-task runs on every session open,
/// and a view removed out-of-band must come back.
#[tokio::test]
async fn warmup_resyncs_the_skill_view() {
    let resolver = Arc::new(RecordingSkillResolver::new(vec!["cron".into()]));
    let views = resolver.views.clone();
    let (svc, _broadcaster, _repo, _task_mgr) =
        make_service_with_resolver_and_agent_metadata_repo(resolver, Arc::new(ClaudeNativeSkillMetadataRepo));
    let workspace = unique_test_workspace_path("view-warmup");

    let req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "acp",
        "extra": { "workspace": workspace, "backend": "claude" },
    }))
    .unwrap();
    let resp = svc.create("user-1", req).await.unwrap();
    views.lock().unwrap().clear();

    let task_mgr: Arc<dyn IWorkerTaskManager> =
        Arc::new(MockTaskManagerWithWorkspace::new(workspace.to_str().unwrap()));
    svc.warmup("user-1", &resp.id, &task_mgr).await.unwrap();

    let calls = views.lock().unwrap();
    assert_eq!(calls.len(), 1);
    assert_eq!(calls[0].conversation_id, resp.id);
    assert_eq!(calls[0].skill_names, vec!["cron"]);
}

#[tokio::test]
async fn update_rejects_extra_skills() {
    let (svc, _broadcaster, _repo, task_mgr) = make_service();
    let workspace = ensure_test_workspace_path();

    let req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "acp",
        "extra": { "workspace": workspace, "backend": "claude" },
    }))
    .unwrap();
    let resp = svc.create("u", req).await.unwrap();

    let update_req: UpdateConversationRequest = serde_json::from_value(json!({
        "extra": { "skills": ["cron"] },
    }))
    .unwrap();
    let err = svc.update("u", &resp.id, update_req, &task_mgr).await.unwrap_err();

    match err {
        ConversationError::BadRequest { reason: msg } => assert!(msg.contains("skills"), "msg = {msg:?}"),
        other => panic!("expected BadRequest, got {other:?}"),
    }
}

#[tokio::test]
async fn update_rejects_acp_runtime_current_extra_fields() {
    let (svc, _broadcaster, _repo, task_mgr) = make_service();
    let workspace = ensure_test_workspace_path();

    let req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "acp",
        "extra": { "workspace": workspace, "backend": "claude" },
    }))
    .unwrap();
    let resp = svc.create("u", req).await.unwrap();

    let update_req: UpdateConversationRequest = serde_json::from_value(json!({
        "extra": { "current_model_id": "claude-3-5-sonnet", "current_mode_id": "default" },
    }))
    .unwrap();
    let err = svc.update("u", &resp.id, update_req, &task_mgr).await.unwrap_err();

    match err {
        ConversationError::BadRequest { reason: msg } => {
            assert!(msg.contains("/config-options"), "msg = {msg:?}")
        }
        other => panic!("expected BadRequest, got {other:?}"),
    }
}

#[tokio::test]
async fn update_allows_other_extra_fields() {
    let (svc, _broadcaster, _repo, task_mgr) = make_service();
    let workspace = ensure_test_workspace_path();

    let req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "acp",
        "extra": { "workspace": workspace, "backend": "claude" },
    }))
    .unwrap();
    let resp = svc.create("u", req).await.unwrap();

    let update_req: UpdateConversationRequest = serde_json::from_value(json!({
        "extra": { "display_density": "compact" },
    }))
    .unwrap();
    let updated = svc.update("u", &resp.id, update_req, &task_mgr).await.unwrap();

    assert_eq!(updated.extra["display_density"], "compact");
}

#[tokio::test]
async fn get_backfills_legacy_row_and_persists() {
    let resolver = Arc::new(FixedSkillResolver {
        names: vec!["cron".into(), "todo-tracker".into()],
    });
    let (svc, _broadcaster, repo, _task_mgr) = make_service_with_resolver(resolver);

    // Seed a legacy row directly via the repo — simulates a pre-migration
    // conversation that the service has never touched.
    let legacy_row = ConversationRow {
        id: "legacy-1".into(),
        user_id: "user-1".into(),
        name: "legacy".into(),
        r#type: "acp".into(),
        extra: serde_json::to_string(&json!({
            "workspace": "/tmp/x",
            "enabled_skills": ["pdf"],
            "exclude_builtin_skills": ["todo-tracker"],
            "loaded_skills": [{"name": "cron", "description": "stale"}],
        }))
        .unwrap(),
        model: None,
        status: Some("finished".into()),
        source: Some("qianji".into()),
        channel_chat_id: None,
        pinned: false,
        pinned_at: None,
        created_at: 0,
        updated_at: 0,
        project_id: None,
        folder_id: None,
        name_source: None,
    };
    repo.create(&legacy_row).await.unwrap();

    let resp = svc.get("user-1", "legacy-1").await.unwrap();
    assert_eq!(resp.extra["skills"], json!(["cron", "pdf"]));
    assert!(resp.extra.get("enabled_skills").is_none());
    assert!(resp.extra.get("exclude_builtin_skills").is_none());
    assert!(resp.extra.get("loaded_skills").is_none());

    // Second read returns the same result.
    let resp2 = svc.get("user-1", "legacy-1").await.unwrap();
    assert_eq!(resp2.extra["skills"], json!(["cron", "pdf"]));

    // Verify the row on disk was persisted with the new shape.
    let persisted = repo.get("user-1", "legacy-1").await.unwrap().unwrap();
    let persisted_extra: serde_json::Value = serde_json::from_str(&persisted.extra).unwrap();
    assert_eq!(persisted_extra["skills"], json!(["cron", "pdf"]));
    assert!(persisted_extra.get("enabled_skills").is_none());
    assert!(persisted_extra.get("exclude_builtin_skills").is_none());
    assert!(persisted_extra.get("loaded_skills").is_none());
}

#[tokio::test]
async fn list_backfills_mixed_rows() {
    let resolver = Arc::new(FixedSkillResolver {
        names: vec!["cron".into()],
    });
    let (svc, _broadcaster, repo, _task_mgr) = make_service_with_resolver(resolver);

    // Row 1: legacy (needs backfill).
    let legacy = ConversationRow {
        id: "a".into(),
        user_id: "u".into(),
        name: "a".into(),
        r#type: "acp".into(),
        extra: serde_json::to_string(&json!({
            "workspace": "/tmp/a",
            "enabled_skills": ["pdf"],
        }))
        .unwrap(),
        model: None,
        status: None,
        source: None,
        channel_chat_id: None,
        pinned: false,
        pinned_at: None,
        created_at: 1,
        updated_at: 1,
        project_id: None,
        folder_id: None,
        name_source: None,
    };
    // Row 2: already migrated.
    let modern = ConversationRow {
        id: "b".into(),
        user_id: "u".into(),
        name: "b".into(),
        r#type: "acp".into(),
        extra: serde_json::to_string(&json!({
            "workspace": "/tmp/b",
            "skills": ["cron", "pdf"],
        }))
        .unwrap(),
        model: None,
        status: None,
        source: None,
        channel_chat_id: None,
        pinned: false,
        pinned_at: None,
        created_at: 2,
        updated_at: 2,
        project_id: None,
        folder_id: None,
        name_source: None,
    };
    repo.create(&legacy).await.unwrap();
    repo.create(&modern).await.unwrap();

    let resp = svc.list("u", ListConversationsQuery::default()).await.unwrap();
    let extras: Vec<_> = resp.items.iter().map(|c| c.extra.clone()).collect();
    assert!(extras.iter().any(|e| e["skills"] == json!(["cron", "pdf"])));
}

#[tokio::test]
async fn create_honors_legacy_alias_fields_from_clone_merge() {
    let resolver = Arc::new(FixedSkillResolver {
        names: vec!["cron".into()],
    });
    let (svc, _broadcaster, _repo, _task_mgr) = make_service_with_resolver(resolver);

    // Legacy-shaped extra — what clone_create might merge in from an
    // unmigrated source conversation.
    let workspace = ensure_test_workspace_path();
    let req: CreateConversationRequest = serde_json::from_value(json!({
        "type": "acp",
        "extra": {
            "workspace": workspace,
            "backend": "claude",
            "enabled_skills": ["pdf"],
            "exclude_builtin_skills": ["cron"],
            "loaded_skills": [{"name": "cron", "description": "stale"}],
        },
    }))
    .unwrap();
    let resp = svc.create("u", req).await.unwrap();

    // Legacy enabled_skills ["pdf"] surfaces as preset; legacy exclude drops
    // cron; snapshot = {} ∪ ["pdf"] = ["pdf"].
    assert_eq!(resp.extra["skills"], json!(["pdf"]));
    assert!(resp.extra.get("enabled_skills").is_none());
    assert!(resp.extra.get("exclude_builtin_skills").is_none());
    assert!(resp.extra.get("loaded_skills").is_none());
}

// ── insert_raw_message ────────────────────────────────────────────
// Exercised by the team wake path (mirroring non-user mailbox rows into
// the target agent's conversation so the UI shows who spoke). Covers both
// the DB write and the live `message.stream` broadcast.

#[tokio::test]
async fn insert_raw_message_persists_row_and_broadcasts_stream() {
    let (svc, broadcaster, repo, _task_mgr) = make_service();
    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    // Clear the create event so our assertion sees only the insert broadcast.
    let _ = broadcaster.take_events();

    let row = MessageRow {
        id: "msg-mirror-1".into(),
        conversation_id: conv.id.clone(),
        msg_id: Some("msg-mirror-1".into()),
        r#type: "text".into(),
        content: serde_json::json!({
            "content": "from teammate",
            "teammate_message": true,
            "sender_name": "Lead",
        })
        .to_string(),
        position: Some("left".into()),
        status: Some("finish".into()),
        hidden: false,
        created_at: 1234,
        backend_turn_id: None,
    };

    svc.insert_raw_message("user_1", &row).await.unwrap();

    let stored = repo.messages.lock().unwrap().clone();
    assert_eq!(stored.len(), 1, "row must be persisted via repo.insert_message");
    assert_eq!(stored[0].id, "msg-mirror-1");
    assert_eq!(stored[0].position.as_deref(), Some("left"));

    let events = broadcaster.take_events();
    let stream_events: Vec<_> = events.iter().filter(|e| e.name == "message.stream").collect();
    assert_eq!(stream_events.len(), 1, "expected exactly one message.stream event");
    let data = &stream_events[0].data;
    assert_eq!(data["conversation_id"], conv.id);
    assert_eq!(data["msg_id"], "msg-mirror-1");
    assert_eq!(data["type"], "text");
    assert_eq!(data["position"], "left");
    assert_eq!(data["data"]["content"], "from teammate");
    assert_eq!(data["data"]["teammate_message"], true);
}

// ── qianjirs rebuild permission seed (Sentry 135525584) ──────────────

/// Inserts an qianjirs conversation whose `extra.session_mode` is the create-time
/// value and persists an assistant snapshot carrying the runtime permission
/// gate inputs (`default_permission_mode` / `resolved_permission_value`).
async fn seed_qianjirs_conversation_with_snapshot(
    repo: &Arc<MockRepo>,
    session_mode: &str,
    default_permission_mode: &str,
    resolved_permission_value: Option<&str>,
) -> ConversationRow {
    let row = ConversationRow {
        id: format!("qianjirs-seed-{}", qianji_common::generate_short_id()),
        user_id: "user_1".into(),
        name: "qianjirs seed".into(),
        r#type: "qianjirs".into(),
        extra: json!({
            "session_mode": session_mode,
            "workspace": ensure_test_workspace_path()
        })
        .to_string(),
        model: None,
        status: Some("finished".into()),
        source: Some("qianji".into()),
        channel_chat_id: None,
        pinned: false,
        pinned_at: None,
        created_at: 1,
        updated_at: 1,
        project_id: None,
        folder_id: None,
        name_source: None,
    };
    repo.create(&row).await.unwrap();
    repo.upsert_assistant_snapshot(
        &row.user_id,
        &UpsertConversationAssistantSnapshotParams {
            conversation_id: &row.id,
            assistant_definition_id: "asstdef-seed",
            assistant_id: "assistant-seed",
            assistant_source: "builtin",
            agent_id: "agent-seed",
            rules_content: "",
            default_model_mode: "auto",
            resolved_model_id: None,
            default_permission_mode,
            resolved_permission_value,
            default_thought_level_mode: "auto",
            resolved_thought_level_value: None,
            default_skills_mode: "auto",
            resolved_skill_ids: "[]",
            resolved_disabled_builtin_skill_ids: "[]",
            default_mcps_mode: "auto",
            resolved_mcp_ids: "[]",
        },
    )
    .await
    .unwrap();
    row
}

fn qianjirs_session_mode(options: &BuildTaskOptions) -> Option<String> {
    match &options.context.kind {
        AgentSessionKind::Qianjirs(ctx) => ctx.config.session_mode.clone(),
        AgentSessionKind::Acp(_) | AgentSessionKind::Antigravity(_) => panic!("expected Qianjirs build options"),
    }
}

#[tokio::test]
async fn qianjirs_rebuild_auto_mode_preserves_runtime_yolo() {
    // AC#1: an `auto` qianjirs session that was switched to yolo at runtime must
    // keep yolo after a rebuild (model switch / agent restart).
    let (svc, _broadcaster, repo, _task_mgr) = make_service();
    let row = seed_qianjirs_conversation_with_snapshot(&repo, "default", "auto", Some("yolo")).await;

    let options = svc.build_task_options(&row).await.unwrap();

    assert_eq!(qianjirs_session_mode(&options).as_deref(), Some("yolo"));
}

#[tokio::test]
async fn qianjirs_rebuild_existing_data_auto_overrides_create_time_seed() {
    // AC#2: existing data — create-time non-yolo seed is overridden by the
    // authoritative resolved runtime value.
    let (svc, _broadcaster, repo, _task_mgr) = make_service();
    let row = seed_qianjirs_conversation_with_snapshot(&repo, "auto_edit", "auto", Some("yolo")).await;

    let options = svc.build_task_options(&row).await.unwrap();

    assert_eq!(qianjirs_session_mode(&options).as_deref(), Some("yolo"));
}

#[tokio::test]
async fn qianjirs_rebuild_fixed_mode_blocks_runtime_escalation() {
    // AC#3 (hard safety gate): a `fixed` assistant must NOT adopt the runtime
    // residue, even if `resolved_permission_value` was written to yolo.
    let (svc, _broadcaster, repo, _task_mgr) = make_service();
    let row = seed_qianjirs_conversation_with_snapshot(&repo, "default", "fixed", Some("yolo")).await;

    let options = svc.build_task_options(&row).await.unwrap();

    assert_eq!(qianjirs_session_mode(&options).as_deref(), Some("default"));
}

#[tokio::test]
async fn cron_required_runtime_mode_wins_over_resolved_permission_seed() {
    // AC#5 (hard): the per-turn `required_runtime_mode` override runs AFTER
    // rebuild and MUST keep priority over the rebuild permission seed. Even for
    // an `auto` qianjirs session whose snapshot resolved value is yolo, a cron
    // turn pinned to "default" applies "default" to the agent — the seed must
    // not bypass or reorder this override.
    let task_mgr = Arc::new(MockTaskManager::new());
    let (svc, broadcaster, repo) = make_service_with_mock_task_manager(task_mgr.clone());
    let row = seed_qianjirs_conversation_with_snapshot(&repo, "default", "auto", Some("yolo")).await;
    broadcaster.take_events();

    let agent = Arc::new(
        MockAgent::new(&row.id)
            .with_mode("yolo")
            .with_config_options(vec![AcpConfigOptionDto {
                id: "mode".to_owned(),
                name: Some("Mode".to_owned()),
                label: None,
                description: None,
                category: Some("mode".to_owned()),
                option_type: "select".to_owned(),
                current_value: Some("yolo".to_owned()),
                options: Vec::new(),
            }]),
    );
    task_mgr.insert_agent(&row.id, AgentInstance::Mock(agent.clone()));

    let outcome = svc
        .run_agent_turn(ConversationAgentTurnRequest {
            user_id: "user_1".to_owned(),
            conversation_id: row.id.clone(),
            content: "run scheduled task".to_owned(),
            files: Vec::new(),
            inject_skills: Vec::new(),
            required_runtime_mode: Some("default".to_owned()),
            persist_user_message: true,
            user_message_hidden: true,
            on_started: None,
        })
        .await
        .unwrap();

    assert_eq!(outcome.status, ConversationAgentTurnStatus::Completed);
    assert_eq!(
        agent.set_config_option_calls.lock().unwrap().as_slice(),
        &[("mode".to_owned(), "default".to_owned())],
        "cron required-runtime-mode must override the rebuild permission seed"
    );
}

#[tokio::test]
async fn get_usage_reads_the_persisted_snapshot_when_no_task_is_live() {
    // The usage indicator has to survive switching away from a conversation and
    // back. The task is reaped when the session goes idle, and requiring a live
    // one here made the figure vanish exactly then — the snapshot is durable in
    // `acp_session.session_config.runtime.context_usage` precisely so a cold
    // read can serve it.
    let acp_repo = Arc::new(StubAcpSessionRepo::default());
    *acp_repo.runtime_state.lock().unwrap() = Some(PersistedSessionState {
        context_usage_json: Some(r#"{"used":10465}"#.to_owned()),
        ..Default::default()
    });
    let (svc, _broadcaster, repo, _task_mgr) =
        make_service_with_resolver_and_acp_session_repo(Arc::new(FixedSkillResolver { names: vec![] }), acp_repo);
    // No task is ever registered for this conversation — the cold path.
    let conv = insert_conversation_with_type(&repo, "user_1", AgentType::Acp).await;

    let usage = svc.get_usage("user_1", &conv.id).await.expect("cold read failed");
    assert_eq!(
        usage.and_then(|v| v.get("used").and_then(|u| u.as_i64())),
        Some(10465),
        "a reaped task must not blank the usage indicator"
    );
}

#[tokio::test]
async fn cancel_during_the_build_is_recorded_instead_of_dropped() {
    // The turn is live — its id matches — but the agent has not registered yet,
    // because building one runs real work first (an Antigravity build probes
    // models, checks the CLI version, installs its permission hook). Returning a
    // bare runtime summary here loses the request: the turn runs to completion
    // while the UI has already reported it as stopped. See #746.
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let slow = Arc::new(SlowBuildTaskManager::new(Duration::from_millis(1_500)));
    let task_mgr: Arc<dyn IWorkerTaskManager> = slow.clone();

    let conv = svc.create("user_1", make_create_req()).await.unwrap();
    let send = svc
        .send_message("user_1", &conv.id, make_send_req(), &task_mgr)
        .await
        .unwrap();

    // No task is registered yet: this is the window the bug lived in.
    assert!(
        task_mgr.get_task(&conv.id).is_none(),
        "test needs the pre-registration window"
    );

    svc.cancel("user_1", &conv.id, &send.turn_id, &task_mgr).await.unwrap();

    assert!(
        svc.runtime_state().take_deferred_cancel(&conv.id, &send.turn_id),
        "the cancel must be remembered so the orchestrator can apply it when the task appears"
    );
    assert!(
        !svc.runtime_state().is_cancelling(&conv.id),
        "it must NOT reuse the ordinary cancelling flag: that one is also set when the \
         agent was handed the cancel directly, and the orchestrator would then abort turns \
         whose cancel is already being handled"
    );
}

/// Remembering the cancel is only half of it — the client has to be told.
///
/// The turn ends on the server, but every terminal frame on the send path comes
/// from the `StreamRelay`, which the deferred-cancel branch returns before
/// building. So the server settled and the UI kept spinning until the 15s
/// watchdog. Live symptom (agy 1.1.12, 2026-08-12): the conversation produced no
/// stream frames at all, not even `start`, and the live cancel test failed 4/4;
/// with the frame it settles in ~200ms.
///
/// The sibling test above asserts only that the request is recorded, which is
/// why it stayed green through all of that.
#[tokio::test]
async fn a_turn_cancelled_before_its_agent_exists_tells_the_client_it_ended() {
    let (svc, broadcaster, _repo, _task_mgr) = make_service();

    svc.broadcast_turn_settled_without_relay("user_1", "conv_1", "turn_1", "msg_1");

    let events = broadcaster.take_events();
    let finish = events
        .iter()
        .find(|e| e.name == "message.stream" && e.data["type"] == "finish")
        .expect("a turn that ends before its relay exists must still emit a terminal frame");

    assert_eq!(finish.data["conversation_id"], "conv_1");
    assert_eq!(finish.data["turn_id"], "turn_1");
    assert_eq!(
        finish.data["msg_id"], "msg_1",
        "the frame has to name the message the client is spinning on"
    );
    assert_eq!(
        finish.data["hidden"], false,
        "a hidden terminal would settle nothing the user can see"
    );
}

#[tokio::test]
async fn a_deferred_cancel_does_not_leak_into_a_later_turn() {
    // The record is keyed by turn: one left behind must never abort the next
    // turn the user starts.
    let (svc, _broadcaster, _repo, _task_mgr) = make_service();
    let conv = svc.create("user_1", make_create_req()).await.unwrap();

    svc.runtime_state().defer_cancel(&conv.id, "turn_old");
    assert!(!svc.runtime_state().take_deferred_cancel(&conv.id, "turn_new"));
    assert!(svc.runtime_state().take_deferred_cancel(&conv.id, "turn_old"));
    // Consumed exactly once.
    assert!(!svc.runtime_state().take_deferred_cancel(&conv.id, "turn_old"));
}

/// The agent has declared the persisted id dead, so it MUST be dropped. Keeping
/// it made the failure permanent: every later turn replayed the same dead id and
/// failed at warmup with `Session not found`, before the prompt was ever sent —
/// so the real cause (a missing provider API key, reported exactly once) became
/// unreachable and no amount of retrying could clear it.
#[tokio::test]
async fn session_not_found_clears_the_persisted_session_id() {
    let acp_repo = Arc::new(StubAcpSessionRepo::with_session_id("df6f811c-dead-session"));
    let (svc, _broadcaster, _repo, task_mgr) = make_service_with_resolver_and_acp_session_repo(
        Arc::new(RecordingSkillResolver::new(Vec::new())),
        acp_repo.clone(),
    );

    let outcome = crate::stream_relay::RelayOutcome {
        system_responses: Vec::new(),
        terminal: crate::stream_relay::RelayTerminal::Error {
            code: Some(AgentErrorCode::UserAgentSessionNotFound),
            retryable: Some(true),
        },
        attempt: Default::default(),
    };

    let evicted = svc
        .evict_acp_task_after_terminal_error("user-1", "conv-1", AgentType::Acp, &outcome, &task_mgr)
        .await;

    assert!(evicted, "an ACP terminal error must evict the task");
    assert!(
        acp_repo.session_id.lock().unwrap().is_none(),
        "an id the agent no longer recognises must not survive"
    );
}

/// The clear is deliberately NOT unconditional. A retryable failure triggers an
/// auto-replay rebuild that carries the session id forward on purpose, so the
/// replay resumes the same session rather than losing the conversation context.
#[tokio::test]
async fn other_terminal_errors_keep_the_session_id_for_replay() {
    for code in [
        AgentErrorCode::UserLlmProviderAuthFailed,
        AgentErrorCode::UnknownUpstreamError,
    ] {
        let acp_repo = Arc::new(StubAcpSessionRepo::with_session_id("sess-live"));
        let (svc, _b, _r, task_mgr) = make_service_with_resolver_and_acp_session_repo(
            Arc::new(RecordingSkillResolver::new(Vec::new())),
            acp_repo.clone(),
        );

        let outcome = crate::stream_relay::RelayOutcome {
            system_responses: Vec::new(),
            terminal: crate::stream_relay::RelayTerminal::Error {
                code: Some(code),
                retryable: Some(true),
            },
            attempt: Default::default(),
        };
        svc.evict_acp_task_after_terminal_error("user-1", "conv-1", AgentType::Acp, &outcome, &task_mgr)
            .await;

        assert_eq!(
            acp_repo.session_id.lock().unwrap().as_deref(),
            Some("sess-live"),
            "session id must survive {code:?} so auto-replay can resume it"
        );
    }
}

/// A clean finish must not evict or touch anything.
#[tokio::test]
async fn a_clean_finish_leaves_the_session_id_alone() {
    let acp_repo = Arc::new(StubAcpSessionRepo::with_session_id("live-session"));
    let (svc, _b, _r, task_mgr) = make_service_with_resolver_and_acp_session_repo(
        Arc::new(RecordingSkillResolver::new(Vec::new())),
        acp_repo.clone(),
    );

    let outcome = crate::stream_relay::RelayOutcome {
        system_responses: Vec::new(),
        terminal: crate::stream_relay::RelayTerminal::Finish,
        attempt: Default::default(),
    };

    let evicted = svc
        .evict_acp_task_after_terminal_error("user-1", "conv-1", AgentType::Acp, &outcome, &task_mgr)
        .await;

    assert!(!evicted, "a clean finish must not evict");
    assert_eq!(
        acp_repo.session_id.lock().unwrap().as_deref(),
        Some("live-session"),
        "a live session must survive a clean turn"
    );
}

/// The BUILD path is where the reported loop actually lived: warmup fails, so the
/// terminal-error eviction never runs. This calls the shared helper directly with
/// the code that path reports, pinning that a disowned id is dropped there too.
#[tokio::test]
async fn session_not_found_during_task_build_clears_the_persisted_session_id() {
    let acp_repo = Arc::new(StubAcpSessionRepo::with_session_id("deb7c49d-dead"));
    let (svc, _b, _r, _task_mgr) = make_service_with_resolver_and_acp_session_repo(
        Arc::new(RecordingSkillResolver::new(Vec::new())),
        acp_repo.clone(),
    );

    svc.clear_persisted_acp_session_after_disown("user-1", "conv-1", Some(AgentErrorCode::UserAgentSessionNotFound))
        .await;

    assert!(
        acp_repo.session_id.lock().unwrap().is_none(),
        "a build failure that disowns the session must clear the id"
    );
}

/// A build failure for any other reason keeps the id — the session may still be
/// resumable and dropping it would lose the conversation's context.
#[tokio::test]
async fn other_build_failures_keep_the_persisted_session_id() {
    let acp_repo = Arc::new(StubAcpSessionRepo::with_session_id("sess-live"));
    let (svc, _b, _r, _task_mgr) = make_service_with_resolver_and_acp_session_repo(
        Arc::new(RecordingSkillResolver::new(Vec::new())),
        acp_repo.clone(),
    );

    svc.clear_persisted_acp_session_after_disown("user-1", "conv-1", Some(AgentErrorCode::UnknownUpstreamError))
        .await;

    assert_eq!(
        acp_repo.session_id.lock().unwrap().as_deref(),
        Some("sess-live"),
        "an unrelated build failure must not drop a resumable session"
    );
}

// ── `@@` session mentions at the send boundary ──────────────────────
//
// Lives here rather than beside `session_mentions.rs` because `MockRepo` and
// the service builders are private to this module. The nested module name
// keeps `cargo test session_mentions` matching.
mod session_mentions_integration {
    use super::*;
    use qianji_api_types::SessionRef;

    /// Insert a conversation row directly so the test controls name, workspace
    /// and `extra` (team marker) exactly.
    async fn insert_conv(repo: &Arc<MockRepo>, user_id: &str, id: &str, name: &str, extra: serde_json::Value) {
        let row = ConversationRow {
            id: id.to_owned(),
            user_id: user_id.to_owned(),
            name: name.to_owned(),
            r#type: AgentType::Acp.serde_name().to_owned(),
            extra: extra.to_string(),
            model: None,
            status: Some("finished".into()),
            source: Some("qianji".into()),
            channel_chat_id: None,
            pinned: false,
            pinned_at: None,
            created_at: 1,
            updated_at: 1,
            project_id: None,
            folder_id: None,
            name_source: None,
        };
        repo.create(&row).await.unwrap();
    }

    #[tokio::test]
    async fn a_session_reference_appends_the_block_with_the_name_from_the_row() {
        let (svc, _b, repo, _t) = make_service();
        insert_conv(
            &repo,
            "user_1",
            "conv_target",
            "重构-鉴权模块",
            json!({"workspace": "/w/a"}),
        )
        .await;

        let resolved = svc
            .resolve_session_mentions(
                "user_1",
                "问下他那边接口定完了没",
                &[SessionRef {
                    id: "conv_target".to_owned(),
                }],
                Some("/w/a"),
            )
            .await
            .expect("resolution succeeds");

        assert!(resolved.starts_with("问下他那边接口定完了没"), "{resolved}");
        assert!(
            resolved.contains("重构-鉴权模块\tconv_target\tworkspace: same"),
            "the name must come from the row, not the client: {resolved}"
        );
        assert!(resolved.trim_end().ends_with("[[/QIANJI_SESSIONS]]"), "{resolved}");
    }

    #[tokio::test]
    async fn a_cross_workspace_reference_states_the_target_path_and_the_warning() {
        let (svc, _b, repo, _t) = make_service();
        insert_conv(
            &repo,
            "user_1",
            "conv_docs",
            "文档站改版",
            json!({"workspace": "/w/docs"}),
        )
        .await;

        let resolved = svc
            .resolve_session_mentions(
                "user_1",
                "hi",
                &[SessionRef {
                    id: "conv_docs".to_owned(),
                }],
                Some("/w/a"),
            )
            .await
            .unwrap();

        assert!(
            resolved.contains("文档站改版\tconv_docs\tworkspace: /w/docs (differs from yours)"),
            "{resolved}"
        );
    }

    #[tokio::test]
    async fn empty_session_list_leaves_content_byte_identical() {
        let (svc, _b, _repo, _t) = make_service();
        let resolved = svc
            .resolve_session_mentions("user_1", "no mentions here", &[], Some("/w/a"))
            .await
            .unwrap();
        assert_eq!(resolved, "no mentions here");
    }

    #[tokio::test]
    async fn a_reference_to_another_users_conversation_fails_the_whole_message() {
        let (svc, _b, repo, _t) = make_service();
        insert_conv(&repo, "user_2", "conv_theirs", "theirs", json!({"workspace": "/w/b"})).await;

        let err = svc
            .resolve_session_mentions(
                "user_1",
                "hi",
                &[SessionRef {
                    id: "conv_theirs".to_owned(),
                }],
                Some("/w/a"),
            )
            .await
            .expect_err("must fail atomically");

        // 404, not 403 — do not leak that the id exists (spec §9.1).
        assert!(matches!(err, ConversationError::NotFound { .. }), "{err:?}");
    }

    #[tokio::test]
    async fn a_reference_to_a_missing_conversation_fails_the_whole_message() {
        let (svc, _b, _repo, _t) = make_service();
        let err = svc
            .resolve_session_mentions(
                "user_1",
                "hi",
                &[SessionRef {
                    id: "conv_does_not_exist".to_owned(),
                }],
                Some("/w/a"),
            )
            .await
            .expect_err("must fail atomically");
        assert!(matches!(err, ConversationError::NotFound { .. }), "{err:?}");
    }

    #[tokio::test]
    async fn a_reference_to_a_team_conversation_is_rejected() {
        let (svc, _b, repo, _t) = make_service();
        insert_conv(&repo, "user_1", "conv_team", "team chat", json!({"teamId": "team_1"})).await;

        let err = svc
            .resolve_session_mentions(
                "user_1",
                "hi",
                &[SessionRef {
                    id: "conv_team".to_owned(),
                }],
                Some("/w/a"),
            )
            .await
            .expect_err("team conversations are not valid @@ targets");
        assert!(matches!(err, ConversationError::Forbidden { .. }), "{err:?}");
    }

    #[tokio::test]
    async fn one_bad_reference_fails_the_send_even_when_another_is_valid() {
        let (svc, _b, repo, _t) = make_service();
        insert_conv(&repo, "user_1", "conv_ok", "ok", json!({"workspace": "/w/a"})).await;

        let err = svc
            .resolve_session_mentions(
                "user_1",
                "hi",
                &[
                    SessionRef {
                        id: "conv_ok".to_owned(),
                    },
                    SessionRef {
                        id: "conv_missing".to_owned(),
                    },
                ],
                Some("/w/a"),
            )
            .await
            .expect_err("atomicity: one bad reference fails the whole message");
        assert!(matches!(err, ConversationError::NotFound { .. }), "{err:?}");
    }

    #[tokio::test]
    async fn send_message_persists_and_broadcasts_the_block_inline() {
        let (svc, broadcaster, repo, task_mgr) = make_service();
        let sender = svc.create("user_1", make_create_req()).await.unwrap();
        insert_conv(
            &repo,
            "user_1",
            "conv_target",
            "重构-鉴权模块",
            json!({"workspace": "/w/a"}),
        )
        .await;
        broadcaster.take_events();

        let request: SendMessageRequest = serde_json::from_value(json!({
            "content": "问下他",
            "sessions": [{ "id": "conv_target" }]
        }))
        .unwrap();

        let response = svc
            .send_message("user_1", &sender.id, request, &task_mgr)
            .await
            .expect("send succeeds");

        let rows: Vec<_> = repo
            .messages
            .lock()
            .unwrap()
            .iter()
            .filter(|m| m.msg_id.as_deref() == Some(response.msg_id.as_str()))
            .cloned()
            .collect();
        assert_eq!(rows.len(), 1, "persisted exactly once");
        // The `content` column stores a JSON envelope, so read the text back
        // out rather than matching against escaped tabs.
        let envelope: serde_json::Value = serde_json::from_str(&rows[0].content).expect("content is a JSON envelope");
        let persisted = envelope["content"].as_str().expect("content text").to_owned();
        assert!(
            persisted.contains("重构-鉴权模块\tconv_target\tworkspace:"),
            "the block must be persisted verbatim: {persisted}"
        );
        assert!(persisted.starts_with("问下他\n\n[[QIANJI_SESSIONS]]"), "{persisted}");
    }

    /// The ordering constraint the plan calls a hard requirement: the block is
    /// appended BEFORE the mid-turn branch consumes `resolved`. Hooking it
    /// after would leave every other test green while silently dropping `@@`
    /// context on the mid-turn path.
    #[tokio::test]
    async fn a_midturn_delivery_still_carries_the_sessions_block() {
        let (svc, _b, repo, _t) = make_service();
        let sender = svc.create("user_1", make_create_req()).await.unwrap();
        insert_conv(
            &repo,
            "user_1",
            "conv_target",
            "重构-鉴权模块",
            json!({"workspace": "/w/a"}),
        )
        .await;
        let _claim = svc
            .runtime_state()
            .try_claim_turn(&sender.id, "turn_active")
            .expect("claim the active turn");
        let agent = Arc::new(MidturnMockAgent::new(&sender.id));
        let task_mgr = Arc::new(MockTaskManager::new());
        task_mgr.insert_agent(&sender.id, AgentInstance::Mock(agent.clone()));
        let task_mgr_dyn: Arc<dyn IWorkerTaskManager> = task_mgr;

        let request: SendMessageRequest = serde_json::from_value(json!({
            "content": "问下他",
            "sessions": [{ "id": "conv_target" }]
        }))
        .unwrap();

        let response = svc
            .send_message("user_1", &sender.id, request, &task_mgr_dyn)
            .await
            .expect("mid-turn send must not 409");
        assert!(response.delivered_midturn, "this test must exercise the mid-turn path");

        let delivered = agent.delivered.lock().unwrap().clone();
        assert_eq!(delivered.len(), 1);
        assert!(
            delivered[0].content.contains("[[QIANJI_SESSIONS]]"),
            "mid-turn delivery must not drop the @@ block: {}",
            delivered[0].content
        );
        assert!(
            delivered[0].content.contains("重构-鉴权模块\tconv_target\tworkspace:"),
            "{}",
            delivered[0].content
        );
    }

    /// `[[QIANJI_FILES]]` MUST remain the last block in the content.
    ///
    /// The front-end's file-chip parser reads every non-empty line after the
    /// `[[QIANJI_FILES]]` marker as a path and abandons the whole parse if any of
    /// them is not one (`MessageText.tsx`, `parseFileMarker`). While the
    /// sessions block was appended after the files block, a message carrying
    /// BOTH `@` and `@@` lost its file chips and rendered the raw marker plus
    /// the absolute path as plain text. Only a message with both kinds of
    /// reference reproduces it, which is why no earlier test caught it.
    #[tokio::test]
    async fn the_files_block_stays_last_when_a_message_carries_both_a_file_and_a_session() {
        let work_root = tempfile::tempdir().unwrap();
        let (svc, _bc, repo, task_mgr) = make_service_with_workspace_root(work_root.path().to_path_buf());
        svc.with_project_service(make_injected_project_service(work_root.path()).await);

        let sender = svc.create("user_1", make_create_req()).await.unwrap();
        insert_conv(
            &repo,
            "user_1",
            "conv_target",
            "重构-鉴权模块",
            json!({"workspace": "/w/a"}),
        )
        .await;

        // A `Local` ref only has to be an existing regular file, so it needs no
        // upload root and no project binding.
        let attachment = work_root.path().join("auth.rs");
        std::fs::write(&attachment, "fn main() {}").unwrap();

        let request: SendMessageRequest = serde_json::from_value(json!({
            "content": "看下这个文件，然后问下他",
            "files": [{ "kind": "local", "path": attachment.to_string_lossy() }],
            "sessions": [{ "id": "conv_target" }]
        }))
        .unwrap();

        let response = svc
            .send_message("user_1", &sender.id, request, &task_mgr)
            .await
            .expect("send succeeds");

        let rows: Vec<_> = repo
            .messages
            .lock()
            .unwrap()
            .iter()
            .filter(|m| m.msg_id.as_deref() == Some(response.msg_id.as_str()))
            .cloned()
            .collect();
        assert_eq!(rows.len(), 1);
        let envelope: serde_json::Value = serde_json::from_str(&rows[0].content).expect("content is a JSON envelope");
        let persisted = envelope["content"].as_str().expect("content text");

        let sessions_at = persisted
            .find("[[QIANJI_SESSIONS]]")
            .unwrap_or_else(|| panic!("sessions block missing: {persisted}"));
        let files_at = persisted
            .find("[[QIANJI_FILES]]")
            .unwrap_or_else(|| panic!("files block missing: {persisted}"));
        assert!(
            sessions_at < files_at,
            "the files block must come last so every line after its marker is a path: {persisted}"
        );

        // The concrete property the front-end depends on: nothing but paths
        // follows the marker.
        let after_marker = &persisted[files_at + "[[QIANJI_FILES]]".len()..];
        for line in after_marker.lines().map(str::trim).filter(|l| !l.is_empty()) {
            assert!(
                line.starts_with('/') || line.starts_with('\\') || line.contains(":\\"),
                "only absolute paths may follow the files marker, found {line:?} in {persisted}"
            );
        }
    }
}
