//! Cross-platform cache directory resolution for managed runtimes.

use std::path::{Path, PathBuf};
use std::sync::OnceLock;

/// Override for [`runtime_root`], set by [`init`] from the backend startup
/// path so managed runtime artifacts land under `AppConfig.data_dir`.
///
/// Lifecycle: written once by `qianji-app`'s `main()` before
/// managed runtimes are resolved, and read every time [`runtime_root`] is
/// queried thereafter. Callers that miss the init window transparently
/// fall back to `dirs::cache_dir()`.
static RUNTIME_ROOT_OVERRIDE: OnceLock<PathBuf> = OnceLock::new();

/// Anchor the runtime root to a caller-supplied data directory — typically
/// the backend's `AppConfig.data_dir`. Idempotent on repeat calls (only
/// the first value wins); a warning is logged if a second path is
/// attempted so unexpected double-inits are visible.
pub fn init(data_dir: impl AsRef<Path>) {
    let path = data_dir.as_ref().join("runtime");
    if let Err(existing) = RUNTIME_ROOT_OVERRIDE.set(path.clone())
        && existing != path
    {
        tracing::warn!(
            attempted = %path.display(),
            existing = %existing.display(),
            "qianji_runtime::init called twice with different paths; keeping first"
        );
    }
}

/// Returns the root cache directory used for all qianji runtime artifacts.
///
/// Priority:
/// 1. Path supplied via [`init`] (`{data_dir}/runtime`) when the backend
///    started with `--data-dir`.
/// 2. Platform cache dir (via `dirs::cache_dir()`):
///    - macOS:   `~/Library/Caches/qianji/runtime`
///    - Linux:   `$XDG_CACHE_HOME/qianji/runtime` (fallback `~/.cache/qianji/runtime`)
///    - Windows: `%LOCALAPPDATA%\qianji\runtime`
///
/// Returns `None` only when neither [`init`] has run nor a platform cache
/// dir is determinable (exotic envs).
pub fn runtime_root() -> Option<PathBuf> {
    if let Some(p) = RUNTIME_ROOT_OVERRIDE.get() {
        return Some(p.clone());
    }
    dirs::cache_dir().map(|d| d.join("qianji").join("runtime"))
}

pub fn node_runtime_root() -> Option<PathBuf> {
    runtime_root().map(|root| root.join("node"))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn runtime_root_ends_with_expected_suffix() {
        let root = runtime_root().expect("cache dir available in test env");
        let tail: Vec<_> = root
            .components()
            .rev()
            .take(2)
            .map(|c| c.as_os_str().to_string_lossy().into_owned())
            .collect();
        assert_eq!(tail, vec!["runtime".to_string(), "qianji".to_string()]);
    }

    #[test]
    fn node_runtime_root_appends_node_directory() {
        let dir = node_runtime_root().expect("cache available");
        let tail: Vec<_> = dir
            .components()
            .rev()
            .take(3)
            .map(|c| c.as_os_str().to_string_lossy().into_owned())
            .collect();
        assert_eq!(
            tail,
            vec!["node".to_string(), "runtime".to_string(), "qianji".to_string()]
        );
    }
}
